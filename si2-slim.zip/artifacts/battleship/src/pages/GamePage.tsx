import { useState } from "react";
import { Board } from "@/components/Board";
import {
  Board as BoardType,
  PlacedShip,
  AdvisorState,
  createAdvisor,
  advisorRecordShot,
  getBestShot,
  computeProbabilityMap_combined,
  markSurroundingAsMiss,
  createBoard,
  cellLabel,
  SHIPS,
  SHIP_NAMES,
  SIZE,
} from "@/lib/gameLogic";
import { cn } from "@/lib/utils";
import {
  Target,
  Eye,
  EyeOff,
  AlertCircle,
  XCircle,
  Crosshair,
  Undo2,
  Anchor,
} from "lucide-react";

type ShotResult = "hit" | "miss" | "sunk";

interface ShotLog {
  cell: [number, number];
  result: ShotResult;
  sunkSize?: number;
  suggested: boolean;
  autoSunk?: boolean;
}

interface OpponentShotLog {
  cell: [number, number];
  result: "hit" | "miss";
}

interface Snapshot {
  advisor: AdvisorState;
  enemyBoard: BoardType;
  myBoard: BoardType;
  shotLog: ShotLog[];
  opponentLog: OpponentShotLog[];
  suggestion: [number, number] | null;
  gameOver: "won" | "lost" | null;
}

interface GamePageProps {
  myBoard: BoardType;
  myShips: PlacedShip[];
  onRestart: () => void;
}

function deepCloneBoard(b: BoardType): BoardType {
  return b.map(r => [...r]) as BoardType;
}

function cloneAdvisor(a: AdvisorState): AdvisorState {
  return {
    radar: deepCloneBoard(a.radar),
    hits: [...a.hits],
    remainingShips: [...a.remainingShips],
  };
}

export function GamePage({ myBoard: initialMyBoard, onRestart }: GamePageProps) {
  const [advisor, setAdvisor] = useState<AdvisorState>(createAdvisor);
  const [enemyBoard, setEnemyBoard] = useState<BoardType>(createBoard);
  const [myBoard, setMyBoard] = useState<BoardType>(initialMyBoard.map(r => [...r]) as BoardType);
  const [suggestion, setSuggestion] = useState<[number, number] | null>(() => getBestShot(createAdvisor()));
  const [showProb, setShowProb] = useState(false);
  const [shotLog, setShotLog] = useState<ShotLog[]>([]);
  const [opponentLog, setOpponentLog] = useState<OpponentShotLog[]>([]);
  const [pendingShot, setPendingShot] = useState<[number, number] | null>(null);
  const [opponentPendingCell, setOpponentPendingCell] = useState<[number, number] | null>(null);
  const [activeTab, setActiveTab] = useState<"enemy" | "mine">("enemy");
  const [gameOver, setGameOver] = useState<"won" | "lost" | null>(null);
  const [lastShot, setLastShot] = useState<[number, number] | null>(null);
  const [history, setHistory] = useState<Snapshot[]>([]);

  // ── Sunk placement mode ──────────────────────────────────────────────────
  const [sunkMode, setSunkMode] = useState(false);
  const [sunkSize, setSunkSize] = useState(2);
  const [sunkHorizontal, setSunkHorizontal] = useState(true);
  const [sunkHoverCell, setSunkHoverCell] = useState<[number, number] | null>(null);

  const probMap = computeProbabilityMap_combined(advisor);

  // Compute sunk preview cells
  const sunkPreviewCells: [number, number][] = sunkMode && sunkHoverCell
    ? (() => {
        const [r, c] = sunkHoverCell;
        const cells: [number, number][] = [];
        for (let i = 0; i < sunkSize; i++) {
          const nr = r + (sunkHorizontal ? 0 : i);
          const nc = c + (sunkHorizontal ? i : 0);
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE) cells.push([nr, nc]);
        }
        return cells;
      })()
    : [];

  const sunkPreviewValid =
    sunkPreviewCells.length === sunkSize &&
    sunkPreviewCells.every(([r, c]) => enemyBoard[r][c] === "empty" || enemyBoard[r][c] === "hit") &&
    sunkPreviewCells.every(([r, c]) => {
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          const nr = r + dr, nc = c + dc;
          if (nr < 0 || nr >= SIZE || nc < 0 || nc >= SIZE) continue;
          const insidePreview = sunkPreviewCells.some(([pr, pc]) => pr === nr && pc === nc);
          if (!insidePreview && enemyBoard[nr][nc] === "sunk") return false;
        }
      }
      return true;
    });

  // ── Snapshot helpers ─────────────────────────────────────────────────────
  function takeSnapshot(): Snapshot {
    return {
      advisor: cloneAdvisor(advisor),
      enemyBoard: deepCloneBoard(enemyBoard),
      myBoard: deepCloneBoard(myBoard),
      shotLog: [...shotLog],
      opponentLog: [...opponentLog],
      suggestion,
      gameOver,
    };
  }

  function pushHistory() {
    setHistory(h => [...h, takeSnapshot()]);
  }

  function handleUndo() {
    if (history.length === 0) return;
    const prev = history[history.length - 1];
    setHistory(h => h.slice(0, -1));
    setAdvisor(prev.advisor);
    setEnemyBoard(prev.enemyBoard);
    setMyBoard(prev.myBoard);
    setShotLog(prev.shotLog);
    setOpponentLog(prev.opponentLog);
    setSuggestion(prev.suggestion);
    setGameOver(prev.gameOver);
    setPendingShot(null);
    setOpponentPendingCell(null);
    setSunkMode(false);
    setSunkHoverCell(null);
  }

  // ── Enemy board cell click ────────────────────────────────────────────────
  function handleEnemyCellClick(row: number, col: number) {
    if (gameOver) return;

    if (sunkMode) {
      // Place sunk ship
      if (!sunkPreviewValid || sunkPreviewCells.length < sunkSize) return;
      pushHistory();

      // Build display board: mark sunk cells
      const newEnemy = deepCloneBoard(enemyBoard);
      for (const [r, c] of sunkPreviewCells) newEnemy[r][c] = "sunk";

      // Update advisor: inject all preview cells as "hit", then sink with size
      let newAdv = cloneAdvisor(advisor);
      for (const [cr, cc] of sunkPreviewCells) {
        if (newAdv.radar[cr][cc] === "empty") {
          const res = advisorRecordShot(newAdv, cr, cc, "hit");
          newAdv = res.advisor;
        }
      }
      // Sink the cluster with explicit size, collect surrounding misses
      const [lr, lc] = sunkPreviewCells[sunkPreviewCells.length - 1];
      const res = advisorRecordShot(newAdv, lr, lc, "sunk", sunkSize);
      newAdv = res.advisor;

      // Force-sync advisor radar sunk cells and apply surrounding misses to display
      for (const [r, c] of sunkPreviewCells) newAdv.radar[r][c] = "sunk";
      const surroundingMisses = markSurroundingAsMiss(newAdv.radar, sunkPreviewCells);
      for (const [mr, mc] of surroundingMisses) {
        if (newEnemy[mr][mc] === "empty") newEnemy[mr][mc] = "miss";
      }
      // Also apply any newMisses returned from the final advisorRecordShot
      for (const [mr, mc] of res.newMisses) {
        if (newEnemy[mr][mc] === "empty") newEnemy[mr][mc] = "miss";
      }

      setEnemyBoard(newEnemy);
      setAdvisor(newAdv);
      setShotLog(prev => [{
        cell: sunkPreviewCells[0],
        result: "sunk",
        sunkSize,
        suggested: false,
      }, ...prev]);
      setSuggestion(getBestShot(newAdv));
      setSunkMode(false);
      setSunkHoverCell(null);
      if (newAdv.remainingShips.length === 0) setGameOver("won");
      return;
    }

    // Normal shot selection
    if (enemyBoard[row][col] !== "empty") return;
    setPendingShot([row, col]);
  }

  function confirmShot(result: ShotResult) {
    if (!pendingShot) return;
    const [r, c] = pendingShot;
    const wasSuggested = suggestion ? suggestion[0] === r && suggestion[1] === c : false;

    pushHistory();

    const newEnemy = deepCloneBoard(enemyBoard);
    if (result === "miss") {
      newEnemy[r][c] = "miss";
    } else if (result === "hit") {
      newEnemy[r][c] = "hit";
    } else if (result === "sunk") {
      // Switch to sunk placement mode instead
      setPendingShot(null);
      setSunkMode(true);
      setSunkHoverCell(null);
      return;
    }

    setLastShot([r, c]);

    const { advisor: newAdvisor, autoSunkClusters, newMisses } = advisorRecordShot(advisor, r, c, result);
    let finalAdvisor = newAdvisor;

    // Apply auto-sunk clusters to display board
    if (autoSunkClusters.length > 0) {
      for (const cluster of autoSunkClusters) {
        for (const [cx, cy] of cluster) newEnemy[cx][cy] = "sunk";
      }
    }
    // Apply surrounding misses from the advisor to display board
    for (const [mr, mc] of newMisses) {
      if (newEnemy[mr][mc] === "empty") newEnemy[mr][mc] = "miss";
    }

    setEnemyBoard([...newEnemy]);
    setAdvisor(finalAdvisor);

    const newLogs: ShotLog[] = [{ cell: [r, c], result, suggested: wasSuggested }];
    for (const cluster of autoSunkClusters) {
      newLogs.push({ cell: cluster[0], result: "sunk", sunkSize: cluster.length, suggested: false, autoSunk: true });
    }
    setShotLog(prev => [...newLogs, ...prev]);

    if (finalAdvisor.remainingShips.length === 0) {
      setGameOver("won");
      setSuggestion(null);
    } else {
      setSuggestion(getBestShot(finalAdvisor));
    }
    setPendingShot(null);
  }

  // ── My board ─────────────────────────────────────────────────────────────
  function handleMyBoardClick(row: number, col: number) {
    if (gameOver) return;
    setOpponentPendingCell([row, col]);
  }

  function confirmOpponentShot(result: "hit" | "miss") {
    if (!opponentPendingCell) return;
    const [r, c] = opponentPendingCell;
    pushHistory();
    const newMyBoard = deepCloneBoard(myBoard);
    newMyBoard[r][c] = result === "hit" ? "hit" : "miss";
    setMyBoard(newMyBoard);
    setOpponentLog(prev => [{ cell: [r, c], result }, ...prev]);
    setOpponentPendingCell(null);
    const totalShipCells = SHIPS.reduce((a, b) => a + b, 0);
    if (newMyBoard.flat().filter(c => c === "hit").length >= totalShipCells) setGameOver("lost");
  }

  return (
    <div className="flex flex-col gap-4 w-full max-w-[1100px] mx-auto px-4 pb-8">
      {/* Header bar */}
      <div className="flex items-center justify-between py-3 border-b border-border/30">
        <div className="flex items-center gap-3">
          <Target className="w-5 h-5 text-cyan-400" />
          <span className="font-display text-sm uppercase tracking-widest text-cyan-400 text-glow">Battle Active</span>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleUndo}
            disabled={history.length === 0}
            data-testid="btn-undo"
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-display uppercase tracking-wider transition-all border",
              history.length > 0
                ? "border-border text-muted-foreground hover:border-cyan-500/40 hover:text-cyan-300"
                : "border-border/30 text-muted-foreground/30 cursor-not-allowed"
            )}
          >
            <Undo2 className="w-3.5 h-3.5" />
            Undo
          </button>
          <button
            onClick={() => setShowProb(p => !p)}
            data-testid="btn-toggle-prob"
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-display uppercase tracking-wider transition-all border",
              showProb ? "border-cyan-500/60 text-cyan-300 bg-cyan-500/10" : "border-border text-muted-foreground hover:border-border/60"
            )}
          >
            {showProb ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            Heatmap
          </button>
          <button onClick={onRestart} data-testid="btn-restart" className="px-3 py-1.5 rounded text-xs font-display uppercase tracking-wider border border-border text-muted-foreground hover:text-destructive hover:border-destructive/40 transition-all">
            New Game
          </button>
        </div>
      </div>

      {/* Game Over */}
      {gameOver && (
        <div className={cn("rounded-xl p-5 text-center animate-slide-up border", gameOver === "won" ? "bg-green-500/10 border-green-500/40" : "bg-destructive/10 border-destructive/40")}>
          <div className={cn("font-display text-3xl uppercase tracking-widest mb-1", gameOver === "won" ? "text-green-400 text-glow" : "text-red-400 text-glow-red")}>
            {gameOver === "won" ? "Victory!" : "Defeated"}
          </div>
          <p className="text-sm text-muted-foreground">{gameOver === "won" ? "All enemy ships sunk!" : "All your ships have been sunk."}</p>
          <button onClick={onRestart} className="mt-4 px-6 py-2 rounded-lg bg-cyan-500/20 border border-cyan-500/60 text-cyan-300 font-display text-sm uppercase tracking-wider hover:bg-cyan-500/30 transition-all">Play Again</button>
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_340px] gap-6">
        {/* Left — Boards */}
        <div className="flex flex-col gap-4">
          <div className="flex gap-2 border-b border-border/30 pb-3">
            <button onClick={() => { setActiveTab("enemy"); setSunkMode(false); }} data-testid="tab-enemy" className={cn("px-4 py-2 rounded-t text-sm font-display uppercase tracking-widest transition-all", activeTab === "enemy" ? "text-cyan-300 border-b-2 border-cyan-400" : "text-muted-foreground hover:text-foreground")}>Enemy Waters</button>
            <button onClick={() => { setActiveTab("mine"); setSunkMode(false); }} data-testid="tab-mine" className={cn("px-4 py-2 rounded-t text-sm font-display uppercase tracking-widest transition-all", activeTab === "mine" ? "text-cyan-300 border-b-2 border-cyan-400" : "text-muted-foreground hover:text-foreground")}>My Waters</button>
          </div>

          {activeTab === "enemy" ? (
            <div className="flex flex-col gap-4">
              {/* AI Suggestion */}
              {suggestion && !gameOver && !sunkMode && (
                <div className="panel-glow rounded-xl p-4 bg-card flex items-start gap-3 animate-slide-up">
                  <div className="w-9 h-9 rounded-lg bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center flex-shrink-0">
                    <Crosshair className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div className="flex-1">
                    <div className="text-xs font-display text-muted-foreground uppercase tracking-widest mb-0.5">AI Recommendation</div>
                    <div className="flex items-center gap-2">
                      <span className="font-display text-xl text-cyan-300 text-glow">{cellLabel(suggestion[0], suggestion[1])}</span>
                      <span className="text-xs text-muted-foreground">{advisor.hits.length > 0 ? "— Finishing active hit cluster" : "— Highest probability zone"}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {advisor.hits.length > 0 ? `${advisor.hits.length} unresolved hit${advisor.hits.length > 1 ? "s" : ""} in cluster` : `${advisor.remainingShips.length} enemy ships remaining`}
                    </p>
                  </div>
                  <button onClick={() => setPendingShot(suggestion)} data-testid="btn-use-suggestion" className="flex-shrink-0 px-3 py-1.5 rounded bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 text-xs font-display uppercase tracking-wider hover:bg-cyan-500/30 transition-all">Use</button>
                </div>
              )}

              {/* Sunk placement mode UI */}
              {sunkMode && !gameOver && (
                <div className="panel-glow rounded-xl p-4 bg-card animate-slide-up border border-red-500/30">
                  <div className="flex items-center gap-2 mb-3">
                    <Anchor className="w-4 h-4 text-red-400" />
                    <span className="text-xs font-display text-red-300 uppercase tracking-widest">Place Sunk Ship</span>
                    <button onClick={() => { setSunkMode(false); setSunkHoverCell(null); }} className="ml-auto text-xs text-muted-foreground hover:text-foreground font-display uppercase tracking-wider">Cancel</button>
                  </div>

                  <div className="flex flex-wrap gap-3 items-center">
                    {/* Size picker */}
                    <div className="flex flex-col gap-1">
                      <span className="text-[10px] text-muted-foreground font-display uppercase tracking-widest">Ship Size</span>
                      <div className="flex gap-1.5">
                        {[1, 2, 3, 4].map(s => (
                          <button
                            key={s}
                            onClick={() => setSunkSize(s)}
                            data-testid={`sunk-size-${s}`}
                            className={cn(
                              "w-9 h-9 rounded font-display text-sm transition-all border flex flex-col items-center justify-center gap-0.5",
                              sunkSize === s
                                ? "bg-red-500/20 border-red-500/60 text-red-300"
                                : "bg-secondary border-border text-muted-foreground hover:border-red-500/30 hover:text-red-300"
                            )}
                          >
                            <span>{s}</span>
                            <div className="flex gap-0.5">
                              {Array.from({ length: s }).map((_, i) => (
                                <div key={i} className={cn("w-1 h-1 rounded-sm", sunkSize === s ? "bg-red-400" : "bg-muted-foreground/40")} />
                              ))}
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Orientation */}
                    <div className="flex flex-col gap-1">
                      <span className="text-[10px] text-muted-foreground font-display uppercase tracking-widest">Direction</span>
                      <div className="flex gap-1.5">
                        <button
                          onClick={() => setSunkHorizontal(true)}
                          data-testid="sunk-horizontal"
                          className={cn("px-3 py-2 rounded text-xs font-display uppercase tracking-wider border transition-all", sunkHorizontal ? "bg-red-500/20 border-red-500/60 text-red-300" : "bg-secondary border-border text-muted-foreground hover:border-red-500/30")}
                        >
                          →
                        </button>
                        <button
                          onClick={() => setSunkHorizontal(false)}
                          data-testid="sunk-vertical"
                          className={cn("px-3 py-2 rounded text-xs font-display uppercase tracking-wider border transition-all", !sunkHorizontal ? "bg-red-500/20 border-red-500/60 text-red-300" : "bg-secondary border-border text-muted-foreground hover:border-red-500/30")}
                        >
                          ↓
                        </button>
                      </div>
                    </div>

                    <div className="text-xs text-muted-foreground mt-4 ml-2">
                      Hover the board below and click to place the sunk ship.
                    </div>
                  </div>
                </div>
              )}

              {/* Enemy board */}
              <div className="flex justify-center">
                <Board
                  board={enemyBoard}
                  probMap={probMap}
                  showProb={showProb && !sunkMode}
                  onCellClick={handleEnemyCellClick}
                  onCellHover={sunkMode ? (r, c) => setSunkHoverCell([r, c]) : undefined}
                  onBoardLeave={sunkMode ? () => setSunkHoverCell(null) : undefined}
                  interactive={!gameOver && !sunkMode}
                  highlightCell={!sunkMode ? suggestion : null}
                  lastShot={lastShot}
                  previewCells={sunkPreviewCells}
                  previewValid={sunkPreviewValid}
                  label={sunkMode ? "Click to place sunk ship" : "Enemy Board — Click to select a shot"}
                />
              </div>

              {/* Shot confirmation (when not in sunk mode) */}
              {pendingShot && !gameOver && !sunkMode && (
                <div className="panel-glow rounded-xl p-4 bg-card animate-slide-up">
                  <div className="text-xs font-display text-muted-foreground uppercase tracking-widest mb-3">
                    You shot <span className="text-cyan-300 font-display">{cellLabel(pendingShot[0], pendingShot[1])}</span> — What happened?
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    <button onClick={() => confirmShot("miss")} data-testid="btn-result-miss" className="flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary border border-border text-sm font-display uppercase tracking-wider hover:border-cyan-500/40 hover:text-cyan-300 transition-all">
                      <XCircle className="w-4 h-4 text-muted-foreground" /> Miss
                    </button>
                    <button onClick={() => confirmShot("hit")} data-testid="btn-result-hit" className="flex items-center gap-2 px-4 py-2 rounded-lg bg-orange-500/10 border border-orange-500/40 text-sm font-display uppercase tracking-wider text-orange-300 hover:bg-orange-500/20 transition-all">
                      <AlertCircle className="w-4 h-4" /> Hit
                    </button>
                    <button
                      onClick={() => confirmShot("sunk")}
                      data-testid="btn-result-sunk"
                      className="flex items-center gap-2 px-4 py-2 rounded-lg bg-red-500/10 border border-red-500/40 text-sm font-display uppercase tracking-wider text-red-300 hover:bg-red-500/20 transition-all"
                    >
                      <Anchor className="w-4 h-4" /> Sunk — Place Ship
                    </button>
                  </div>
                </div>
              )}

              {/* "Mark sunk" button always available */}
              {!pendingShot && !sunkMode && !gameOver && (
                <div className="flex justify-end">
                  <button
                    onClick={() => { setSunkMode(true); setSunkHoverCell(null); }}
                    data-testid="btn-mark-sunk"
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-display uppercase tracking-wider border border-red-500/30 text-red-400 hover:bg-red-500/10 transition-all"
                  >
                    <Anchor className="w-3.5 h-3.5" />
                    Mark Sunk Ship
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              <div className="flex justify-center">
                <Board
                  board={myBoard}
                  interactive={!gameOver && !opponentPendingCell}
                  onCellClick={handleMyBoardClick}
                  label="Your Board — Click where opponent shot"
                  lastShot={opponentLog[0]?.cell ?? null}
                />
              </div>

              {opponentPendingCell && !gameOver && (
                <div className="panel-glow rounded-xl p-4 bg-card animate-slide-up">
                  <div className="text-xs font-display text-muted-foreground uppercase tracking-widest mb-3">
                    Opponent shot <span className="text-cyan-300 font-display">{cellLabel(opponentPendingCell[0], opponentPendingCell[1])}</span> — Result?
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => confirmOpponentShot("miss")} data-testid="btn-opp-miss" className="flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary border border-border text-sm font-display uppercase tracking-wider hover:border-cyan-500/40 hover:text-cyan-300 transition-all">
                      <XCircle className="w-4 h-4 text-muted-foreground" /> Miss
                    </button>
                    <button onClick={() => confirmOpponentShot("hit")} data-testid="btn-opp-hit" className="flex items-center gap-2 px-4 py-2 rounded-lg bg-destructive/10 border border-destructive/40 text-sm font-display uppercase tracking-wider text-red-300 hover:bg-destructive/20 transition-all">
                      <AlertCircle className="w-4 h-4" /> Hit
                    </button>
                  </div>
                </div>
              )}

              {!opponentPendingCell && !gameOver && (
                <div className="text-center text-sm text-muted-foreground panel-glow rounded-xl p-4 bg-card">
                  When your opponent shoots at you, click that cell above to record the result.
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right — Info panels */}
        <div className="flex flex-col gap-4">
          <div className="panel-glow rounded-xl p-4 bg-card">
            <div className="text-xs font-display text-muted-foreground uppercase tracking-widest mb-3">Enemy Fleet</div>
            <div className="flex flex-col gap-1.5">
              {[4, 3, 2, 1].map(size => {
                const total = SHIPS.filter(s => s === size).length;
                const sunk = total - advisor.remainingShips.filter(s => s === size).length;
                return (
                  <div key={size} className="flex items-center gap-2">
                    <div className="flex gap-0.5">
                      {Array.from({ length: size }).map((_, i) => (
                        <div key={i} className={cn("w-4 h-3 rounded-sm border", sunk === total ? "bg-red-900/40 border-red-800/40" : "bg-cyan-500/20 border-cyan-500/40")} />
                      ))}
                    </div>
                    <span className={cn("text-xs font-display", sunk === total ? "text-muted-foreground line-through" : "text-foreground")}>{SHIP_NAMES[size]}</span>
                    <span className="ml-auto text-xs text-muted-foreground">{sunk}/{total}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {showProb && (
            <div className="panel-glow rounded-xl p-4 bg-card">
              <div className="text-xs font-display text-muted-foreground uppercase tracking-widest mb-2">Probability Heatmap</div>
              <div className="h-3 rounded" style={{ background: "linear-gradient(to right, transparent, rgba(34,211,238,0.55))" }} />
              <div className="flex justify-between text-[10px] text-muted-foreground mt-1"><span>Low</span><span>High</span></div>
            </div>
          )}

          <div className="panel-glow rounded-xl p-4 bg-card flex-1">
            <div className="text-xs font-display text-muted-foreground uppercase tracking-widest mb-3">Your Shots</div>
            {shotLog.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-4">No shots yet.</p>
            ) : (
              <div className="flex flex-col gap-1.5 max-h-64 overflow-y-auto pr-1">
                {shotLog.map((log, i) => (
                  <div key={i} className={cn("flex items-center gap-2 px-2 py-1.5 rounded text-xs", log.result === "miss" ? "bg-secondary/50" : log.result === "hit" ? "bg-orange-500/10" : "bg-red-500/10")}>
                    <span className="font-display text-cyan-300 w-8 flex-shrink-0">{cellLabel(log.cell[0], log.cell[1])}</span>
                    <span className={cn("uppercase tracking-wider font-display", log.result === "miss" ? "text-muted-foreground" : log.result === "hit" ? "text-orange-300" : "text-red-300")}>
                      {log.result === "sunk" ? `Sunk (${log.sunkSize ?? "?"})` : log.result}
                    </span>
                    {log.autoSunk && <span className="text-[10px] text-muted-foreground">auto</span>}
                    {log.suggested && !log.autoSunk && <span className="ml-auto text-cyan-500/60 text-[10px]">AI</span>}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="panel-glow rounded-xl p-4 bg-card">
            <div className="text-xs font-display text-muted-foreground uppercase tracking-widest mb-3">Incoming Shots</div>
            {opponentLog.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-2">Switch to "My Waters" to log opponent shots.</p>
            ) : (
              <div className="flex flex-col gap-1.5 max-h-40 overflow-y-auto">
                {opponentLog.map((log, i) => (
                  <div key={i} className={cn("flex items-center gap-2 px-2 py-1.5 rounded text-xs", log.result === "miss" ? "bg-secondary/50" : "bg-destructive/10")}>
                    <span className="font-display text-cyan-300 w-8">{cellLabel(log.cell[0], log.cell[1])}</span>
                    <span className={cn("uppercase tracking-wider font-display", log.result === "miss" ? "text-muted-foreground" : "text-red-300")}>{log.result}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
