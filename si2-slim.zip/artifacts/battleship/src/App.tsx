import { useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ShipPlacer } from "@/components/ShipPlacer";
import { GamePage } from "@/pages/GamePage";
import { Board as BoardType, PlacedShip } from "@/lib/gameLogic";
import { Anchor } from "lucide-react";

const queryClient = new QueryClient();

type Phase = "setup" | "playing";

interface GameState {
  board: BoardType;
  ships: PlacedShip[];
}

function BattleshipApp() {
  const [phase, setPhase] = useState<Phase>("setup");
  const [gameState, setGameState] = useState<GameState | null>(null);

  function handleSetupDone(board: BoardType, ships: PlacedShip[]) {
    setGameState({ board, ships });
    setPhase("playing");
  }

  function handleRestart() {
    setGameState(null);
    setPhase("setup");
  }

  return (
    <div className="min-h-screen bg-background scanline flex flex-col">
      {/* Nav */}
      <header className="border-b border-border/30 px-6 py-3 flex items-center gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center">
            <Anchor className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <div className="font-display text-sm uppercase tracking-widest text-cyan-300 text-glow">
              Battle Advisor
            </div>
            <div className="text-[10px] text-muted-foreground tracking-wider uppercase">
              AI-Powered Battleship Assistant
            </div>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          <span className="text-xs font-display text-muted-foreground uppercase tracking-widest">
            {phase === "setup" ? "Setup Phase" : "Battle Active"}
          </span>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 flex flex-col items-center justify-start py-8 px-4">
        {phase === "setup" && (
          <div className="w-full max-w-5xl">
            {/* Instructions */}
            <div className="mb-8 text-center animate-slide-up">
              <h1 className="font-display text-3xl uppercase tracking-widest text-cyan-300 text-glow mb-3">
                Fleet Setup
              </h1>
              <p className="text-sm text-muted-foreground max-w-lg mx-auto">
                Place your ships to match your real-life board. Once set, the AI advisor will analyze every shot and tell you exactly where to fire next.
              </p>
              <div className="flex items-center justify-center gap-6 mt-4 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-sm bg-cyan-500/30 border border-cyan-500/60" />
                  <span>Your ship</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-sm bg-orange-600/60 border border-orange-500/60" />
                  <span>Hit</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-sm bg-cyan-900/60 border border-cyan-800/40" />
                  <span>Miss</span>
                </div>
              </div>
            </div>
            <ShipPlacer onDone={handleSetupDone} />
          </div>
        )}

        {phase === "playing" && gameState && (
          <>
            {/* How to use hint */}
            <div className="w-full max-w-[1100px] mb-4 px-4">
              <div className="panel-glow rounded-xl p-3 bg-card flex flex-wrap gap-4 text-xs text-muted-foreground animate-slide-up">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 font-display text-[10px]">1</div>
                  <span>AI suggests where to shoot — click "Use This" or pick your own cell</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 font-display text-[10px]">2</div>
                  <span>Report the real result (Miss / Hit / Sunk)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 font-display text-[10px]">3</div>
                  <span>Switch to "My Waters" to log opponent's shots on your board</span>
                </div>
              </div>
            </div>
            <GamePage
              myBoard={gameState.board}
              myShips={gameState.ships}
              onRestart={handleRestart}
            />
          </>
        )}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BattleshipApp />
    </QueryClientProvider>
  );
}
