import { CellState, SIZE, cellLabel } from "@/lib/gameLogic";
import { cn } from "@/lib/utils";

const COL_NUMS = Array.from({ length: SIZE }, (_, i) => String(i + 1));
const ROW_LETTERS = Array.from({ length: SIZE }, (_, i) => String.fromCharCode(65 + i));

interface BoardProps {
  board: CellState[][];
  probMap?: number[][];
  showProb?: boolean;
  onCellClick?: (row: number, col: number) => void;
  onCellHover?: (row: number, col: number) => void;
  onBoardLeave?: () => void;
  highlightCell?: [number, number] | null;
  interactive?: boolean;
  label: string;
  lastShot?: [number, number] | null;
  previewCells?: [number, number][];
  previewValid?: boolean;
}

export function Board({
  board,
  probMap,
  showProb = false,
  onCellClick,
  onCellHover,
  onBoardLeave,
  highlightCell,
  interactive = false,
  label,
  lastShot,
  previewCells = [],
  previewValid = true,
}: BoardProps) {
  const maxProb = probMap ? Math.max(...probMap.flat(), 1) : 1;
  const previewSet = new Set(previewCells.map(([r, c]) => `${r},${c}`));

  function getCellClass(row: number, col: number): string {
    const state = board[row][col];
    const isHighlight = highlightCell && highlightCell[0] === row && highlightCell[1] === col;
    const isPreview = previewSet.has(`${row},${col}`);

    if (isPreview) return previewValid ? "drag-valid" : "drag-invalid";
    if (state === "hit") return "cell-hit";
    if (state === "sunk") return "cell-sunk";
    if (state === "miss") return "cell-miss";
    if (state === "ship") return "cell-ship";
    if (isHighlight) return "bg-cyan-400/30 border-cyan-400 shadow-[inset_0_0_12px_rgba(34,211,238,0.5)] animate-pulse";
    return "cell-water";
  }

  const isPlacementMode = previewCells.length > 0 || !!onCellHover;

  return (
    <div className="flex flex-col gap-1">
      <div className="text-xs font-display text-muted-foreground uppercase tracking-widest mb-1 text-center">
        {label}
      </div>

      <div className="flex">
        {/* Row letter labels A–J */}
        <div className="flex flex-col mr-1">
          <div className="w-5 h-6" />
          {ROW_LETTERS.map((letter) => (
            <div key={letter} className="w-5 h-7 flex items-center justify-center text-[11px] font-display text-muted-foreground">
              {letter}
            </div>
          ))}
        </div>

        <div>
          {/* Column number labels 1–10 */}
          <div className="flex">
            {COL_NUMS.map((num) => (
              <div key={num} className="w-7 h-6 flex items-center justify-center text-[11px] font-display text-muted-foreground">
                {num}
              </div>
            ))}
          </div>

          {/* Grid */}
          <div
            className="border border-border/30 rounded grid-glow"
            onMouseLeave={onBoardLeave}
          >
            {ROW_LETTERS.map((_, row) => (
              <div key={row} className="flex">
                {COL_NUMS.map((_, col) => {
                  const prob = probMap?.[row]?.[col] ?? 0;
                  const probAlpha = showProb && board[row][col] === "empty" ? (prob / maxProb) * 0.55 : 0;
                  const isHighlight = highlightCell && highlightCell[0] === row && highlightCell[1] === col;
                  const isPreview = previewSet.has(`${row},${col}`);
                  const isLast = lastShot && lastShot[0] === row && lastShot[1] === col;

                  return (
                    <div
                      key={col}
                      data-testid={`cell-${row}-${col}`}
                      onClick={() => {
                        if (isPlacementMode) {
                          onCellClick?.(row, col);
                        } else if (interactive) {
                          onCellClick?.(row, col);
                        }
                      }}
                      onMouseEnter={() => onCellHover?.(row, col)}
                      title={interactive || isPlacementMode ? cellLabel(row, col) : undefined}
                      className={cn(
                        "w-7 h-7 relative transition-all duration-100 flex items-center justify-center",
                        getCellClass(row, col),
                        isPlacementMode ? "cursor-crosshair" : (
                          interactive && board[row][col] === "empty" && !isHighlight ? "cursor-pointer" : ""
                        ),
                        interactive && !isPlacementMode && board[row][col] !== "empty" ? "cursor-not-allowed" : "",
                        isLast && board[row][col] === "empty" ? "bg-cyan-500/10 border-cyan-500/40" : ""
                      )}
                      style={
                        showProb && probAlpha > 0 && !isPreview
                          ? { background: `rgba(34, 211, 238, ${probAlpha})`, borderColor: `rgba(34, 211, 238, ${Math.min(probAlpha * 1.5, 0.8)})` }
                          : undefined
                      }
                    >
                      {!isPreview && board[row][col] === "miss" && (
                        <div className="w-1.5 h-1.5 rounded-full bg-cyan-700/70" />
                      )}
                      {!isPreview && (board[row][col] === "hit" || board[row][col] === "sunk") && (
                        <div className="w-2 h-2 rounded-full bg-orange-300/90" />
                      )}
                      {!isPreview && isHighlight && board[row][col] === "empty" && (
                        <div className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
