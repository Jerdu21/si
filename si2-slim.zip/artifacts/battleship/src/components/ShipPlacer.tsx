import { useEffect, useState } from "react";
import { Board } from "@/components/Board";
import { SHIPS, SHIP_NAMES, createBoard, canPlace, placeShipOnBoard, autoPlace, PlacedShip, Board as BoardType } from "@/lib/gameLogic";
import { cn } from "@/lib/utils";
import { RotateCcw, Shuffle, ChevronRight } from "lucide-react";

interface ShipPlacerProps {
  onDone: (board: BoardType, ships: PlacedShip[]) => void;
}

export function ShipPlacer({ onDone }: ShipPlacerProps) {
  const [board, setBoard] = useState<BoardType>(createBoard);
  const [ships, setShips] = useState<PlacedShip[]>([]);
  const [selectedShipIdx, setSelectedShipIdx] = useState<number>(0);
  const [horizontal, setHorizontal] = useState(true);
  const [hoverCell, setHoverCell] = useState<[number, number] | null>(null);

  const placedSizes = ships.map(s => s.size);

  // Build remaining list by comparing counts
  const shipCounts: Record<number, number> = {};
  for (const s of SHIPS) shipCounts[s] = (shipCounts[s] ?? 0) + 1;
  const placedCounts: Record<number, number> = {};
  for (const s of placedSizes) placedCounts[s] = (placedCounts[s] ?? 0) + 1;
  const remaining = SHIPS.filter(s => (placedCounts[s] ?? 0) < (shipCounts[s] ?? 0));
  // deduplicate in order
  const remainingList: number[] = [];
  const tempCounts: Record<number, number> = { ...placedCounts };
  for (const s of SHIPS) {
    if ((tempCounts[s] ?? 0) < (shipCounts[s] ?? 0)) {
      remainingList.push(s);
      tempCounts[s] = (tempCounts[s] ?? 0) + 1;
    }
  }

  const currentShipSize = remainingList[selectedShipIdx < remainingList.length ? selectedShipIdx : 0];

  useEffect(() => {
    function handleKeyDown(event: KeyboardEvent) {
      if (event.key.toLowerCase() === "r") setHorizontal(h => !h);
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  function getHoverCells(): [number, number][] {
    if (!hoverCell || currentShipSize === undefined) return [];
    const [r, c] = hoverCell;
    const cells: [number, number][] = [];
    for (let i = 0; i < currentShipSize; i++) {
      const nr = r + (horizontal ? 0 : i);
      const nc = c + (horizontal ? i : 0);
      if (nr < 10 && nc < 10) cells.push([nr, nc]);
    }
    return cells;
  }

  const hoverCells = getHoverCells();
  const hoverValid = hoverCell
    ? canPlace(board, hoverCell[0], hoverCell[1], currentShipSize, horizontal)
    : false;

  function handleCellClick(row: number, col: number) {
    if (remainingList.length === 0) return;
    const size = currentShipSize;
    if (!canPlace(board, row, col, size, horizontal)) return;
    const newBoard = board.map(r => [...r]) as BoardType;
    const ship = placeShipOnBoard(newBoard, row, col, size, horizontal);
    setBoard(newBoard);
    setShips([...ships, ship]);
    if (selectedShipIdx >= remainingList.length - 1) setSelectedShipIdx(0);
  }

  function handleRandomize() {
    const { board: b, ships: s } = autoPlace();
    setBoard(b);
    setShips(s);
  }

  function handleReset() {
    setBoard(createBoard());
    setShips([]);
    setSelectedShipIdx(0);
  }

  const allPlaced = ships.length === SHIPS.length;

  // Build hover overlay board
  const hoverBoard = board.map(r => [...r]) as BoardType;
  for (const [hr, hc] of hoverCells) {
    if (hoverBoard[hr][hc] === "empty") {
      hoverBoard[hr][hc] = "ship";
    }
  }

  return (
    <div className="flex flex-col items-center gap-6 animate-slide-up">
      <div className="text-center">
        <h2 className="font-display text-xl text-cyan-400 text-glow tracking-widest uppercase">Place Your Fleet</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Position your ships on the grid — the AI will use this to track your game
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-8 items-start">
        {/* Board */}
        <div
          className="relative"
          onMouseLeave={() => setHoverCell(null)}
        >
          <div
            className={cn(
              "transition-all duration-100",
              hoverCell && !hoverValid && "opacity-80"
            )}
          >
            <InteractiveBoard
              board={hoverCells.length > 0 ? hoverBoard : board}
              hoverCells={hoverCells}
              hoverValid={hoverValid}
              onCellClick={handleCellClick}
              onCellHover={setHoverCell}
              label="Your Fleet"
              showShips
            />
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-col gap-4 min-w-[220px]">
          {/* Orientation toggle */}
          <div className="panel-glow rounded-lg p-4 bg-card">
            <div className="text-xs font-display text-muted-foreground uppercase tracking-widest mb-3">Orientation</div>
            <div className="flex gap-2">
              <button
                onClick={() => setHorizontal(true)}
                data-testid="btn-horizontal"
                className={cn(
                  "flex-1 py-2 px-3 rounded text-sm font-display uppercase tracking-wider transition-all",
                  horizontal
                    ? "bg-cyan-500/20 border border-cyan-500/60 text-cyan-300"
                    : "bg-secondary text-muted-foreground border border-transparent hover:border-border"
                )}
              >
                Horizontal
              </button>
              <button
                onClick={() => setHorizontal(false)}
                data-testid="btn-vertical"
                className={cn(
                  "flex-1 py-2 px-3 rounded text-sm font-display uppercase tracking-wider transition-all",
                  !horizontal
                    ? "bg-cyan-500/20 border border-cyan-500/60 text-cyan-300"
                    : "bg-secondary text-muted-foreground border border-transparent hover:border-border"
                )}
              >
                Vertical
              </button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Press R to rotate</p>
          </div>

          {/* Ships to place */}
          <div className="panel-glow rounded-lg p-4 bg-card">
            <div className="text-xs font-display text-muted-foreground uppercase tracking-widest mb-3">
              Fleet Status
            </div>
            <div className="flex flex-col gap-1.5">
              {SHIPS.map((size, i) => {
                const isPlaced = (() => {
                  let c = 0;
                  for (let j = 0; j <= i; j++) {
                    if (SHIPS[j] === size) c++;
                  }
                  return (placedCounts[size] ?? 0) >= c;
                })();
                return (
                  <div key={i} className={cn(
                    "flex items-center gap-2 px-2 py-1 rounded text-sm transition-all",
                    isPlaced ? "opacity-40" : "opacity-100"
                  )}>
                    <div className="flex gap-0.5">
                      {Array.from({ length: size }).map((_, j) => (
                        <div
                          key={j}
                          className={cn(
                            "w-4 h-4 rounded-sm border",
                            isPlaced
                              ? "bg-cyan-900/40 border-cyan-800/40"
                              : "bg-cyan-500/30 border-cyan-500/60"
                          )}
                        />
                      ))}
                    </div>
                    <span className={cn(
                      "font-display text-xs uppercase tracking-wide",
                      isPlaced ? "text-muted-foreground line-through" : "text-cyan-300"
                    )}>
                      {SHIP_NAMES[size]}
                    </span>
                    {isPlaced && <span className="ml-auto text-xs text-green-500">✓</span>}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Buttons */}
          <div className="flex flex-col gap-2">
            <button
              onClick={handleRandomize}
              data-testid="btn-randomize"
              className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-secondary border border-border text-sm font-display uppercase tracking-wider text-foreground hover:border-cyan-500/40 hover:text-cyan-300 transition-all"
            >
              <Shuffle className="w-4 h-4" />
              Auto-Place
            </button>
            <button
              onClick={handleReset}
              data-testid="btn-reset"
              className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg bg-secondary border border-border text-sm font-display uppercase tracking-wider text-muted-foreground hover:text-destructive hover:border-destructive/40 transition-all"
            >
              <RotateCcw className="w-4 h-4" />
              Reset
            </button>
            <button
              onClick={() => allPlaced && onDone(board, ships)}
              disabled={!allPlaced}
              data-testid="btn-start-game"
              className={cn(
                "flex items-center justify-center gap-2 py-3 px-4 rounded-lg text-sm font-display uppercase tracking-wider transition-all",
                allPlaced
                  ? "bg-cyan-500/20 border border-cyan-500/60 text-cyan-300 hover:bg-cyan-500/30 btn-primary-glow cursor-pointer"
                  : "bg-muted border border-border/30 text-muted-foreground cursor-not-allowed opacity-50"
              )}
            >
              <ChevronRight className="w-4 h-4" />
              Start Battle
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Custom interactive board with hover effect
interface InteractiveBoardProps {
  board: BoardType;
  hoverCells: [number, number][];
  hoverValid: boolean;
  onCellClick: (row: number, col: number) => void;
  onCellHover: (cell: [number, number]) => void;
  label: string;
  showShips: boolean;
}

// Columns: 1–10 (top), Rows: A–J (left)
const COL_NUMS_ARR = Array.from({ length: 10 }, (_, i) => String(i + 1));
const ROW_LETTERS_ARR = Array.from({ length: 10 }, (_, i) => String.fromCharCode(65 + i));

function InteractiveBoard({ board, hoverCells, hoverValid, onCellClick, onCellHover, label }: InteractiveBoardProps) {
  function isHoverCell(r: number, c: number) {
    return hoverCells.some(([hr, hc]) => hr === r && hc === c);
  }

  return (
    <div className="flex flex-col gap-1">
      <div className="text-xs font-display text-muted-foreground uppercase tracking-widest mb-1 text-center">{label}</div>
      <div className="flex">
        {/* Row letter labels (A–J) on the left */}
        <div className="flex flex-col mr-1">
          <div className="w-5 h-6" />
          {ROW_LETTERS_ARR.map((letter) => (
            <div key={letter} className="w-5 h-7 flex items-center justify-center text-[11px] text-muted-foreground font-display">{letter}</div>
          ))}
        </div>
        <div>
          {/* Column number labels (1–10) on top */}
          <div className="flex">
            {COL_NUMS_ARR.map((num) => (
              <div key={num} className="w-7 h-6 flex items-center justify-center text-[11px] text-muted-foreground font-display">{num}</div>
            ))}
          </div>
          <div className="border border-border/30 rounded grid-glow">
            {ROW_LETTERS_ARR.map((_, row) => (
              <div key={row} className="flex">
                {COL_NUMS_ARR.map((_, col) => {
                  const state = board[row][col];
                  const hover = isHoverCell(row, col);
                  return (
                    <div
                      key={col}
                      data-testid={`place-cell-${row}-${col}`}
                      onClick={() => onCellClick(row, col)}
                      onMouseEnter={() => onCellHover([row, col])}
                      className={cn(
                        "w-7 h-7 cursor-pointer transition-all duration-100",
                        hover
                          ? hoverValid
                            ? "drag-valid"
                            : "drag-invalid"
                          : state === "ship"
                            ? "cell-ship"
                            : "cell-water hover:bg-cyan-900/30 hover:border-cyan-700/40"
                      )}
                    />
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
