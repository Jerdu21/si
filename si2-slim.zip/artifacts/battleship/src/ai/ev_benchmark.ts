/**
 * ============================================================
 *  EXPECTED-VALUE MODEL BENCHMARK
 *  Run: pnpm --filter @workspace/battleship evtest
 * ============================================================
 *
 * Tests model_expectedValue against the current top models:
 *   - evo_A3    (best overall from final_selection)
 *   - balanced  (the original champion)
 *
 * Runs a full round-robin tournament:
 *   - 5040 total matches (6 ordered pairs × 840 seeds)
 *   - 10 batches of 84 seeds each (for std-dev per batch)
 *   - Alternating first-player via ordered pairs (A→B and B→A both run)
 *
 * Outputs:
 *   - Console: full results table + head-to-head breakdown
 *   - ev_benchmark_results.json
 *   - ev_benchmark_results.csv
 */

import { writeFileSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

import { SIZE, type AdvisorState, computeProbabilityMap } from "@/lib/gameLogic";
import { type BattleshipModel, type Move, type FleetPlacement } from "./modelTypes";
import {
  type MatchResult, type ModelStats,
  buildModelStats, TOTAL_DECKS, computeGameScore,
} from "./metrics";
import {
  placeFleetSafe,
  createLiveFleet, resolveShot, getSunkCluster, isFleetSunk,
  countRemainingDecks, countRemainingShips,
  applyOutcomeToAdvisor, createAdvisor,
} from "./gameEngine";
import { createRNG, deriveSeed, pickRandom, type RNG } from "./randomSeed";
import { model_expectedValue } from "./models/model_expectedValue";

const OUTPUT_DIR = resolve(dirname(fileURLToPath(import.meta.url)), "../..");

// ─────────────────────────────────────────────────────────────────────────────
// evo_A3 model (inline — same params as final_selection.ts)
// ─────────────────────────────────────────────────────────────────────────────

const HUMAN_PRIOR: number[][] = (() => {
  const map = Array.from({ length: SIZE }, () => Array(SIZE).fill(1.0));
  const mid = (SIZE - 1) / 2;
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      let bias = 1.0;
      const dCenter = Math.max(Math.abs(r - mid), Math.abs(c - mid));
      if (dCenter <= 1.5) bias *= 0.80;
      const dEdge = Math.min(r, SIZE - 1 - r, c, SIZE - 1 - c);
      if (dEdge === 1) bias *= 1.30;
      if (dEdge === 0) bias *= 1.12;
      if ((r <= 1 || r >= SIZE - 2) && (c <= 1 || c >= SIZE - 2)) bias *= 1.20;
      map[r][c] = bias;
    }
  }
  return map;
})();

function keyOf(r: number, c: number) { return `${r},${c}`; }

function getHitClusters(radar: AdvisorState["radar"]): [number, number][][] {
  const visited = new Set<string>();
  const clusters: [number, number][][] = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const k = keyOf(r, c);
      if (radar[r][c] !== "hit" || visited.has(k)) continue;
      const cluster: [number, number][] = [];
      const q: [number, number][] = [[r, c]];
      while (q.length) {
        const [cr, cc] = q.shift()!;
        const ck = keyOf(cr, cc);
        if (visited.has(ck) || radar[cr][cc] !== "hit") continue;
        visited.add(ck);
        cluster.push([cr, cc]);
        for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
          const nr = cr+dr, nc = cc+dc;
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE) q.push([nr, nc]);
        }
      }
      if (cluster.length) clusters.push(cluster);
    }
  }
  return clusters;
}

function detectOrientation(cluster: [number, number][]): "h" | "v" | "unknown" {
  if (cluster.length < 2) return "unknown";
  if (new Set(cluster.map(([r]) => r)).size === 1) return "h";
  if (new Set(cluster.map(([, c]) => c)).size === 1) return "v";
  return "unknown";
}

function chooseBest(
  candidates: [number, number][],
  score: number[][],
  rng: RNG,
): [number, number] {
  let best = -Infinity;
  let bestCells: [number, number][] = [];
  for (const [r, c] of candidates) {
    const s = score[r][c];
    if (s > best) { best = s; bestCells = [[r, c]]; }
    else if (s === best) bestCells.push([r, c]);
  }
  return pickRandom(bestCells, rng);
}

function makeBalancedVariant(
  name: string,
  humanBias: number,
  finishBias: number,
  placementTrials: number,
): BattleshipModel {
  return {
    name,
    params: { humanBias, finishBias, placementTrials },
    getNextMove(advisor: AdvisorState, rng: RNG): Move {
      const prob = computeProbabilityMap(advisor);
      if (advisor.hits.length > 0) {
        const clusters = getHitClusters(advisor.radar);
        const sorted = [...clusters].sort((a, b) => b.length - a.length);
        for (const cluster of sorted) {
          const orient = detectOrientation(cluster);
          const seen = new Set<string>();
          const axisExt: [number, number][] = [];
          const crossExt: [number, number][] = [];
          for (const [hr, hc] of cluster) {
            const axisDirs: [number, number][] =
              orient === "h" ? [[0,-1],[0,1]] : orient === "v" ? [[-1,0],[1,0]] : [[-1,0],[1,0],[0,-1],[0,1]];
            const crossDirs: [number, number][] =
              orient === "h" ? [[-1,0],[1,0]] : orient === "v" ? [[0,-1],[0,1]] : [];
            for (const [dr, dc] of axisDirs) {
              const nr = hr+dr, nc = hc+dc;
              const k = keyOf(nr, nc);
              if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE && advisor.radar[nr][nc] === "empty" && !seen.has(k)) {
                seen.add(k); axisExt.push([nr, nc]);
              }
            }
            for (const [dr, dc] of crossDirs) {
              const nr = hr+dr, nc = hc+dc;
              const k = keyOf(nr, nc);
              if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE && advisor.radar[nr][nc] === "empty" && !seen.has(k)) {
                seen.add(k); crossExt.push([nr, nc]);
              }
            }
          }
          if (axisExt.length) {
            const boosted = prob.map(row => [...row]);
            for (const [r, c] of axisExt) boosted[r][c] *= finishBias;
            return chooseBest(axisExt, boosted, rng);
          }
          if (crossExt.length) return chooseBest(crossExt, prob, rng);
        }
      }
      const smallest = advisor.remainingShips.length > 0 ? Math.min(...advisor.remainingShips) : 1;
      const useCheckerboard = smallest > 1;
      const huntScore: number[][] = Array.from({ length: SIZE }, (_, r) =>
        Array.from({ length: SIZE }, (_, c) => {
          if (advisor.radar[r][c] !== "empty") return 0;
          return prob[r][c] * (1 + humanBias * (HUMAN_PRIOR[r][c] - 1));
        })
      );
      const parity: [number, number][] = [];
      const all: [number, number][] = [];
      for (let r = 0; r < SIZE; r++) {
        for (let c = 0; c < SIZE; c++) {
          if (advisor.radar[r][c] !== "empty") continue;
          all.push([r, c]);
          if (!useCheckerboard || (r + c) % 2 === 0) parity.push([r, c]);
        }
      }
      return chooseBest(parity.length ? parity : all, huntScore, rng);
    },
    placeFleet(rng: RNG): FleetPlacement { return placeFleetSafe(rng, placementTrials); },
  };
}

const model_evo_A3 = makeBalancedVariant("evo_A3", 0.25, 4.5, 350);
const model_balanced = makeBalancedVariant("balanced", 0.40, 3.0, 150);

// ─────────────────────────────────────────────────────────────────────────────
// Match runner (identical to final_selection.ts)
// ─────────────────────────────────────────────────────────────────────────────

const MAX_TURNS = 200;

function simulateOne(
  mA: BattleshipModel,
  mB: BattleshipModel,
  idxA: number,
  idxB: number,
  seed: number,
): MatchResult {
  const rngAp = createRNG(deriveSeed(seed, 1));
  const rngBp = createRNG(deriveSeed(seed, 2));
  const rngAs = createRNG(deriveSeed(seed, 3));
  const rngBs = createRNG(deriveSeed(seed, 4));

  const fpA = mA.placeFleet(rngAp);
  const fpB = mB.placeFleet(rngBp);
  const fleetB = createLiveFleet(fpB);
  const fleetA = createLiveFleet(fpA);
  let advA = createAdvisor();
  let advB = createAdvisor();
  let turns = 0;
  let winner: "A" | "B" | "draw" = "draw";

  while (turns < MAX_TURNS) {
    {
      const [row, col] = mA.getNextMove(advA, rngAs);
      const r = Math.max(0, Math.min(9, row));
      const c = Math.max(0, Math.min(9, col));
      const out = resolveShot(fleetB, r, c);
      if (out.result === "sunk" && out.sunkShipIndex !== undefined) {
        advA = applyOutcomeToAdvisor(advA, r, c, out, fleetB);
        for (const [cr, cc] of getSunkCluster(fleetB, out.sunkShipIndex))
          if (advA.radar[cr][cc] !== "sunk") advA.radar[cr][cc] = "sunk";
      } else { advA = applyOutcomeToAdvisor(advA, r, c, out, fleetB); }
      turns++;
      if (isFleetSunk(fleetB)) { winner = "A"; break; }
    }
    {
      const [row, col] = mB.getNextMove(advB, rngBs);
      const r = Math.max(0, Math.min(9, row));
      const c = Math.max(0, Math.min(9, col));
      const out = resolveShot(fleetA, r, c);
      if (out.result === "sunk" && out.sunkShipIndex !== undefined) {
        advB = applyOutcomeToAdvisor(advB, r, c, out, fleetA);
        for (const [cr, cc] of getSunkCluster(fleetA, out.sunkShipIndex))
          if (advB.radar[cr][cc] !== "sunk") advB.radar[cr][cc] = "sunk";
      } else { advB = applyOutcomeToAdvisor(advB, r, c, out, fleetA); }
      turns++;
      if (isFleetSunk(fleetA)) { winner = "B"; break; }
    }
  }

  const aW = winner === "A", bW = winner === "B";
  return {
    winnerId: aW ? idxA : bW ? idxB : -1,
    loserId:  aW ? idxB : bW ? idxA : -1,
    turns,
    winnerRemainingDecks: aW ? countRemainingDecks(fleetA) : bW ? countRemainingDecks(fleetB) : 0,
    winnerRemainingShips: aW ? countRemainingShips(fleetA) : bW ? countRemainingShips(fleetB) : 0,
    winnerEnemyDecksSunk: aW ? TOTAL_DECKS - countRemainingDecks(fleetB) : bW ? TOTAL_DECKS - countRemainingDecks(fleetA) : 0,
    firstPlayerWon: aW,
    seed,
    modelAName: mA.name,
    modelBName: mB.name,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Formatting helpers
// ─────────────────────────────────────────────────────────────────────────────

function pct(v: number) { return (v * 100).toFixed(1) + "%"; }
function fmt(v: number, d = 2) { return v.toFixed(d); }
function pad(s: string | number, n: number, right = false) {
  return right ? String(s).padEnd(n) : String(s).padStart(n);
}

function stdDev(vals: number[]): number {
  if (vals.length < 2) return 0;
  const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
  return Math.sqrt(vals.reduce((a, b) => a + (b - mean) ** 2, 0) / (vals.length - 1));
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────────────────────────────────────

async function main() {
  const t0 = Date.now();

  console.log("╔══════════════════════════════════════════════════════════╗");
  console.log("║       EXPECTED VALUE MODEL BENCHMARK                     ║");
  console.log("╚══════════════════════════════════════════════════════════╝");
  console.log(`  Started: ${new Date().toISOString()}\n`);

  const MODELS: BattleshipModel[] = [model_expectedValue, model_evo_A3, model_balanced];
  const BASE_SEED = 0xE5000001;

  // 6 ordered pairs (no self-play), 840 seeds, 10 batches of 84
  const SEEDS_PER_PAIR = 840;
  const NUM_BATCHES    = 10;
  const BATCH_SIZE     = SEEDS_PER_PAIR / NUM_BATCHES; // 84

  const pairs: [number, number][] = [];
  for (let i = 0; i < MODELS.length; i++)
    for (let j = 0; j < MODELS.length; j++)
      if (i !== j) pairs.push([i, j]);

  const totalMatches = pairs.length * SEEDS_PER_PAIR;
  console.log(`  Models: ${MODELS.map(m => m.name).join(", ")}`);
  console.log(`  Ordered pairs: ${pairs.length}  ×  seeds: ${SEEDS_PER_PAIR}  =  ${totalMatches} matches`);
  console.log(`  Batches: ${NUM_BATCHES} × ${BATCH_SIZE} seeds each (for σ calculation)\n`);

  const allResults: MatchResult[] = [];
  const batchResults: MatchResult[][] = Array.from({ length: NUM_BATCHES }, () => []);
  let completed = 0;
  const reportInterval = Math.max(1, Math.floor(totalMatches / 20));

  for (let b = 0; b < NUM_BATCHES; b++) {
    for (const [ai, bi] of pairs) {
      for (let s = 0; s < BATCH_SIZE; s++) {
        const seed = deriveSeed(BASE_SEED, b * 1000000 + ai * 10000 + bi * 100 + s);
        const result = simulateOne(MODELS[ai], MODELS[bi], ai, bi, seed);
        allResults.push(result);
        batchResults[b].push(result);
        completed++;
        if (completed % reportInterval === 0)
          process.stdout.write(`\r  Progress: ${completed}/${totalMatches} (${Math.round(completed/totalMatches*100)}%)`);
      }
    }
  }
  process.stdout.write(`\r  Progress: ${totalMatches}/${totalMatches} (100%) ✓\n`);

  // ── Aggregate stats ──────────────────────────────────────────────────────
  const stats = MODELS.map((m, i) => buildModelStats(i, m.name, allResults));

  // Per-batch win rates for std-dev
  const batchWRs: Record<string, number[]> = {};
  for (const m of MODELS) batchWRs[m.name] = [];
  for (let b = 0; b < NUM_BATCHES; b++) {
    for (let i = 0; i < MODELS.length; i++) {
      const bs = buildModelStats(i, MODELS[i].name, batchResults[b]);
      batchWRs[MODELS[i].name].push(bs.winRate);
    }
  }

  // ── Print overall table ──────────────────────────────────────────────────
  const sorted = [...stats].sort((a, b) => b.winRate - a.winRate);

  console.log("\n════════════════════════════════════════════════════════════");
  console.log("  OVERALL RESULTS");
  console.log("════════════════════════════════════════════════════════════\n");

  const W = [5, 16, 7, 7, 10, 10, 11, 11, 9, 9];
  const HDRS = ["Rank","Model","Win%","Score","Decks↑","Margin↑","1st-Win%","2nd-Win%","σ(batch)","Turns↓"];
  console.log(HDRS.map((h, i) => pad(h, W[i], i===1)).join(" │ "));
  console.log(W.map(w => "─".repeat(w)).join("─┼─"));

  const maxScore = Math.max(...sorted.map(s => s.avgScore));
  sorted.forEach((s, rank) => {
    const fp = s.firstPlayerGames > 0 ? s.firstPlayerWins / s.firstPlayerGames : 0;
    const sp = s.secondPlayerGames > 0 ? s.secondPlayerWins / s.secondPlayerGames : 0;
    const sd = stdDev(batchWRs[s.name]);
    const isEV = s.name === "expectedValue";
    const row = [
      pad(rank+1, W[0]),
      pad((isEV ? "★ " : "  ") + s.name, W[1], true),
      pad(pct(s.winRate), W[2]),
      pad(fmt(s.avgScore, 1), W[3]),
      pad(fmt(s.avgRemainingDecks), W[4]),
      pad(fmt(s.avgMarginOfVictory), W[5]),
      pad(pct(fp), W[6]),
      pad(pct(sp), W[7]),
      pad(pct(sd), W[8]),
      pad(fmt(s.avgTurns, 1), W[9]),
    ].join(" │ ");
    console.log(row);
  });

  // ── Head-to-head breakdown ───────────────────────────────────────────────
  console.log("\n════════════════════════════════════════════════════════════");
  console.log("  HEAD-TO-HEAD: expectedValue vs each opponent");
  console.log("════════════════════════════════════════════════════════════\n");

  const evIdx = 0; // expectedValue is index 0
  for (let oppIdx = 1; oppIdx < MODELS.length; oppIdx++) {
    const oppName = MODELS[oppIdx].name;

    // EV as first player (A) vs opp as second player (B)
    const asFirst  = allResults.filter(r => r.modelAName === "expectedValue" && r.modelBName === oppName);
    const asSecond = allResults.filter(r => r.modelBName === "expectedValue" && r.modelAName === oppName);

    const winsAsFirst  = asFirst.filter(r => r.winnerId === evIdx).length;
    const winsAsSecond = asSecond.filter(r => r.winnerId === evIdx).length;
    const totalVsOpp   = asFirst.length + asSecond.length;
    const totalWins    = winsAsFirst + winsAsSecond;

    const evDecks  = allResults
      .filter(r => r.winnerId === evIdx && (r.modelAName === oppName || r.modelBName === oppName))
      .map(r => r.winnerRemainingDecks);
    const oppDecks = allResults
      .filter(r => r.loserId === evIdx && (r.modelAName === oppName || r.modelBName === oppName))
      .map(r => r.winnerRemainingDecks);

    const avgEVDecks  = evDecks.length  > 0 ? evDecks.reduce((a,b)=>a+b,0)/evDecks.length  : 0;
    const avgOppDecks = oppDecks.length > 0 ? oppDecks.reduce((a,b)=>a+b,0)/oppDecks.length : 0;

    console.log(`  vs ${oppName}:`);
    console.log(`    Overall:    ${totalWins}/${totalVsOpp} wins = ${pct(totalWins/totalVsOpp)}`);
    console.log(`    As 1st:     ${winsAsFirst}/${asFirst.length} = ${pct(winsAsFirst/(asFirst.length||1))}`);
    console.log(`    As 2nd:     ${winsAsSecond}/${asSecond.length} = ${pct(winsAsSecond/(asSecond.length||1))}`);
    console.log(`    EV decks surviving on win: ${fmt(avgEVDecks)}  vs  opp decks surviving on win: ${fmt(avgOppDecks)}`);
    console.log("");
  }

  // ── EV-specific diagnostics ──────────────────────────────────────────────
  const evStats = stats.find(s => s.name === "expectedValue")!;
  const evo3Stats = stats.find(s => s.name === "evo_A3")!;
  const balStats = stats.find(s => s.name === "balanced")!;

  console.log("════════════════════════════════════════════════════════════");
  console.log("  VERDICT: Does Expected Value beat probability models?");
  console.log("════════════════════════════════════════════════════════════\n");

  const evVsEvo3 = (evStats.winRate - evo3Stats.winRate) * 100;
  const evVsBal  = (evStats.winRate - balStats.winRate) * 100;

  console.log(`  expectedValue win rate:  ${pct(evStats.winRate)}  (avg score ${fmt(evStats.avgScore, 1)}, avg ${fmt(evStats.avgTurns, 1)} turns)`);
  console.log(`  evo_A3        win rate:  ${pct(evo3Stats.winRate)}  (avg score ${fmt(evo3Stats.avgScore, 1)})`);
  console.log(`  balanced      win rate:  ${pct(balStats.winRate)}  (avg score ${fmt(balStats.avgScore, 1)})`);
  console.log("");
  console.log(`  EV vs evo_A3:  ${evVsEvo3 >= 0 ? "+" : ""}${evVsEvo3.toFixed(1)}pp  ${evVsEvo3 >= 0.5 ? "✓ EV WINS" : evVsEvo3 >= -0.5 ? "≈ STATISTICALLY TIED" : "✗ EV LOSES"}`);
  console.log(`  EV vs balanced: ${evVsBal >= 0 ? "+" : ""}${evVsBal.toFixed(1)}pp  ${evVsBal >= 0.5 ? "✓ EV WINS" : evVsBal >= -0.5 ? "≈ STATISTICALLY TIED" : "✗ EV LOSES"}`);
  console.log(`\n  Batch σ: EV=${pct(stdDev(batchWRs.expectedValue))} | evo_A3=${pct(stdDev(batchWRs.evo_A3))} | balanced=${pct(stdDev(batchWRs.balanced))}`);

  const bestRank = sorted.findIndex(s => s.name === "expectedValue") + 1;
  console.log(`\n  Final rank of expectedValue: ${bestRank} / ${MODELS.length}`);

  if (evVsEvo3 >= 1.5) {
    console.log("\n  🏆 RECOMMENDATION: Use expectedValue as the new champion AI.");
  } else if (evVsEvo3 >= 0) {
    console.log("\n  📊 RECOMMENDATION: EV model is competitive with evo_A3. Consider it as primary AI.");
  } else if (evVsEvo3 >= -2.0) {
    console.log("\n  ⚠️  RECOMMENDATION: EV model is close but behind evo_A3. Fine-tune weights or stick with evo_A3.");
  } else {
    console.log("\n  ✗  RECOMMENDATION: evo_A3 remains the stronger model. Keep using it as primary AI.");
  }

  const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
  console.log(`\n  Total matches: ${totalMatches}  |  Elapsed: ${elapsed}s`);

  // ── Save outputs ─────────────────────────────────────────────────────────
  console.log("\n── Saving results ───────────────────────────────────────────");

  const payload = {
    meta: {
      timestamp: new Date().toISOString(),
      totalMatches,
      seedsPerPair: SEEDS_PER_PAIR,
      numBatches: NUM_BATCHES,
      models: MODELS.map(m => m.name),
    },
    results: sorted.map(s => ({
      ...s,
      firstPlayerWinRate: s.firstPlayerGames > 0 ? s.firstPlayerWins / s.firstPlayerGames : 0,
      secondPlayerWinRate: s.secondPlayerGames > 0 ? s.secondPlayerWins / s.secondPlayerGames : 0,
      batchStdDev: stdDev(batchWRs[s.name]),
    })),
    headToHead: MODELS.slice(1).map(opp => {
      const asFirst  = allResults.filter(r => r.modelAName === "expectedValue" && r.modelBName === opp.name);
      const asSecond = allResults.filter(r => r.modelBName === "expectedValue" && r.modelAName === opp.name);
      return {
        opponent: opp.name,
        evWinRate: (asFirst.filter(r => r.winnerId === evIdx).length + asSecond.filter(r => r.winnerId === evIdx).length)
          / (asFirst.length + asSecond.length),
        asFirstWinRate: asFirst.filter(r => r.winnerId === evIdx).length / (asFirst.length || 1),
        asSecondWinRate: asSecond.filter(r => r.winnerId === evIdx).length / (asSecond.length || 1),
      };
    }),
    verdicts: {
      evVsEvoA3pp: evVsEvo3,
      evVsBalancedPP: evVsBal,
      evRank: bestRank,
    },
  };

  const jsonPath = resolve(OUTPUT_DIR, "ev_benchmark_results.json");
  writeFileSync(jsonPath, JSON.stringify(payload, null, 2), "utf-8");
  console.log(`  Saved JSON → ${jsonPath}`);

  const headers = "rank,name,winRate,avgScore,avgTurns,avgRemainingDecks,avgMarginOfVictory,firstPlayerWinRate,secondPlayerWinRate,batchStdDev,totalGames,wins,losses";
  const rows = sorted.map((s, i) => [
    i+1, s.name,
    s.winRate.toFixed(4), s.avgScore.toFixed(2), s.avgTurns.toFixed(2),
    s.avgRemainingDecks.toFixed(2), s.avgMarginOfVictory.toFixed(2),
    (s.firstPlayerGames > 0 ? s.firstPlayerWins / s.firstPlayerGames : 0).toFixed(4),
    (s.secondPlayerGames > 0 ? s.secondPlayerWins / s.secondPlayerGames : 0).toFixed(4),
    stdDev(batchWRs[s.name]).toFixed(4),
    s.totalGames, s.wins, s.losses,
  ].join(",")).join("\n");

  const csvPath = resolve(OUTPUT_DIR, "ev_benchmark_results.csv");
  writeFileSync(csvPath, headers + "\n" + rows, "utf-8");
  console.log(`  Saved CSV  → ${csvPath}`);
  console.log("");
}

main().catch(err => {
  console.error("Benchmark error:", err);
  process.exit(1);
});
