/**
 * Seedable pseudo-random number generator using Mulberry32.
 * Provides fully deterministic, reproducible random sequences given the same seed.
 *
 * Mulberry32 is a fast, high-quality 32-bit PRNG by Tommy Ettinger.
 * See: https://gist.github.com/tommyettinger/46a874533244883189143505d203312c
 */

export type RNG = () => number;

/**
 * Create a Mulberry32 RNG from a numeric seed.
 * Returns a function that produces numbers in [0, 1).
 */
export function createRNG(seed: number): RNG {
  let s = seed >>> 0;
  return function (): number {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Pick a random integer in [0, n).
 */
export function randInt(rng: RNG, n: number): number {
  return Math.floor(rng() * n);
}

/**
 * Pick a random element from an array.
 */
export function pickRandom<T>(arr: T[], rng: RNG): T {
  return arr[randInt(rng, arr.length)];
}

/**
 * Shuffle an array in-place (Fisher-Yates).
 */
export function shuffle<T>(arr: T[], rng: RNG): T[] {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = randInt(rng, i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/**
 * Generate a deterministic seed from a base seed + index.
 */
export function deriveSeed(baseSeed: number, index: number): number {
  return (baseSeed * 1664525 + index * 22695477 + 1013904223) >>> 0;
}
