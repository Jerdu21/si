/**
 * ============================================================
 *  BATTLESHIP AI FINAL SELECTION TOURNAMENT
 *  Run: pnpm --filter @workspace/battleship select
 * ============================================================
 *
 * Determines the single best AI by running three distinct test types:
 *
 *   ATTACK-ONLY  — both models share identical fleet placement (same seed),
 *                  isolating shooting skill alone.
 *
 *   PLACEMENT-ONLY — both models use a shared reference attacker (baseline),
 *                    isolating fleet placement quality alone.
 *
 *   FULL MODEL   — standard match: own placement + own attack,
 *                  run in 10 batches to compute std-dev across batches.
 *
 * After identifying the best attack model and the best placement model
 * separately, if they differ a HYBRID model is constructed and tested
 * against all candidates in a final playoff.
 *
 * Outputs: final_results.json  +  final_results.csv
 */

import { writeFileSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

import { SIZE, type AdvisorState, computeProbabilityMap } from "@/lib/gameLogic";
import { createAdvisor } from "@/lib/gameLogic";
import { type BattleshipModel, type Move, type FleetPlacement } from "./modelTypes";
import {
  type MatchResult, type ModelStats,
  buildModelStats, TOTAL_DECKS,
} from "./metrics";
import {
  placeFleetRandom, placeFleetSafe,
  createLiveFleet, resolveShot, getSunkCluster, isFleetSunk,
  countRemainingDecks, countRemainingShips,
  applyOutcomeToAdvisor,
} from "./gameEngine";
import { createRNG, deriveSeed, pickRandom, type RNG } from "./randomSeed";
import { model_baseline } from "./models/model_baseline";
import { model_safePlacement } from "./models/model_safePlacement";

// ─────────────────────────────────────────────────────────────────────────────
// Constants
// ─────────────────────────────────────────────────────────────────────────────

const BASE_SEED      = 0xf1a1f1a1;   // unique seed for this run
const FULL_SEEDS     = 100;          // per ordered pair in full-model test
const FULL_BATCHES   = 10;           // must divide FULL_SEEDS evenly
const ATTACK_SEEDS   = 60;           // per ordered pair in attack-only test
const PLACE_SEEDS    = 60;           // per ordered pair in placement-only test
const HYBRID_SEEDS   = 80;           // per ordered pair in hybrid playoff

const OUTPUT_DIR = resolve(dirname(fileURLToPath(import.meta.url)), "../..");

// ─────────────────────────────────────────────────────────────────────────────
// Human prior (identical to model_balanced)
// ─────────────────────────────────────────────────────────────────────────────

const HUMAN_PRIOR: number[][] = (() => {
  const map = Array.from({ length: SIZE }, () => Array(SIZE).fill(1.0));
  const mid = (SIZE - 1) / 2;
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      let bias = 1.0;
      const dCenter = Math.max(Math.abs(r - mid), Math.abs(c - mid));
      if (dCenter <= 1.5) bias *= 0.80;
      const dEdge = Math.min(r, SIZE - 1 - r, c, SIZE - 1 - c);
      if (dEdge === 1) bias *= 1.30;
      if (dEdge === 0) bias *= 1.12;
      const isCornerAdj = (r <= 1 || r >= SIZE - 2) && (c <= 1 || c >= SIZE - 2);
      if (isCornerAdj) bias *= 1.20;
      map[r][c] = bias;
    }
  }
  return map;
})();

// ─────────────────────────────────────────────────────────────────────────────
// Shared balanced-variant shooting logic (parameterised)
// ─────────────────────────────────────────────────────────────────────────────

function keyOf(r: number, c: number) { return `${r},${c}`; }

function getHitClusters(radar: AdvisorState["radar"]): [number, number][][] {
  const visited = new Set<string>();
  const clusters: [number, number][][] = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const k = keyOf(r, c);
      if (radar[r][c] !== "hit" || visited.has(k)) continue;
      const cluster: [number, number][] = [];
      const q: [number, number][] = [[r, c]];
      while (q.length) {
        const [cr, cc] = q.shift()!;
        const ck = keyOf(cr, cc);
        if (visited.has(ck) || radar[cr][cc] !== "hit") continue;
        visited.add(ck);
        cluster.push([cr, cc]);
        for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
          const nr = cr+dr, nc = cc+dc;
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE) q.push([nr, nc]);
        }
      }
      if (cluster.length) clusters.push(cluster);
    }
  }
  return clusters;
}

function detectOrientation(cluster: [number, number][]): "h" | "v" | "unknown" {
  if (cluster.length < 2) return "unknown";
  if (new Set(cluster.map(([r]) => r)).size === 1) return "h";
  if (new Set(cluster.map(([, c]) => c)).size === 1) return "v";
  return "unknown";
}

function chooseBest(
  candidates: [number, number][],
  score: number[][],
  rng: RNG,
): [number, number] | null {
  if (!candidates.length) return null;
  let best = -Infinity;
  let bestCells: [number, number][] = [];
  for (const [r, c] of candidates) {
    const s = score[r][c];
    if (s > best) { best = s; bestCells = [[r, c]]; }
    else if (s === best) bestCells.push([r, c]);
  }
  return pickRandom(bestCells, rng);
}

function balancedShoot(
  advisor: AdvisorState,
  rng: RNG,
  humanBias: number,
  finishBias: number,
): Move {
  const prob = computeProbabilityMap(advisor);

  if (advisor.hits.length > 0) {
    const clusters = getHitClusters(advisor.radar);
    const sorted = [...clusters].sort((a, b) => b.length - a.length);

    for (const cluster of sorted) {
      const orient = detectOrientation(cluster);
      const seen = new Set<string>();
      const axisExt: [number, number][] = [];
      const crossExt: [number, number][] = [];

      for (const [hr, hc] of cluster) {
        const axisDirs: [number, number][] =
          orient === "h" ? [[0,-1],[0,1]]
          : orient === "v" ? [[-1,0],[1,0]]
          : [[-1,0],[1,0],[0,-1],[0,1]];
        const crossDirs: [number, number][] =
          orient === "h" ? [[-1,0],[1,0]]
          : orient === "v" ? [[0,-1],[0,1]]
          : [];

        for (const [dr, dc] of axisDirs) {
          const nr = hr+dr, nc = hc+dc;
          const k = keyOf(nr, nc);
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE
            && advisor.radar[nr][nc] === "empty" && !seen.has(k)) {
            seen.add(k); axisExt.push([nr, nc]);
          }
        }
        for (const [dr, dc] of crossDirs) {
          const nr = hr+dr, nc = hc+dc;
          const k = keyOf(nr, nc);
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE
            && advisor.radar[nr][nc] === "empty" && !seen.has(k)) {
            seen.add(k); crossExt.push([nr, nc]);
          }
        }
      }

      if (axisExt.length) {
        const boosted: number[][] = prob.map(row => [...row]);
        for (const [r, c] of axisExt) boosted[r][c] *= finishBias;
        return chooseBest(axisExt, boosted, rng) ?? axisExt[0];
      }
      if (crossExt.length) {
        return chooseBest(crossExt, prob, rng) ?? crossExt[0];
      }
    }
  }

  // Hunt mode: probability × human prior × parity
  const smallest = advisor.remainingShips.length > 0 ? Math.min(...advisor.remainingShips) : 1;
  const useCheckerboard = smallest > 1;

  const huntScore: number[][] = Array.from({ length: SIZE }, (_, r) =>
    Array.from({ length: SIZE }, (_, c) => {
      if (advisor.radar[r][c] !== "empty") return 0;
      const p = prob[r][c];
      const h = 1 + humanBias * (HUMAN_PRIOR[r][c] - 1);
      return p * h;
    })
  );

  const parity: [number, number][] = [];
  const all: [number, number][] = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if (advisor.radar[r][c] !== "empty") continue;
      all.push([r, c]);
      if (!useCheckerboard || (r + c) % 2 === 0) parity.push([r, c]);
    }
  }

  return chooseBest(parity.length ? parity : all, huntScore, rng) ?? [0, 0];
}

// ─────────────────────────────────────────────────────────────────────────────
// Model factory: parameterised balanced variants
// ─────────────────────────────────────────────────────────────────────────────

function makeBalancedVariant(
  name: string,
  humanBias: number,
  finishBias: number,
  placementTrials: number,
): BattleshipModel {
  return {
    name,
    params: { humanBias, finishBias, placementTrials },
    getNextMove(advisor: AdvisorState, rng: RNG): Move {
      return balancedShoot(advisor, rng, humanBias, finishBias);
    },
    placeFleet(rng: RNG): FleetPlacement {
      return placeFleetSafe(rng, placementTrials);
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Candidate lineup
// ─────────────────────────────────────────────────────────────────────────────

const CANDIDATES: BattleshipModel[] = [
  // Previous top-2
  makeBalancedVariant("balanced",       0.40, 3.0, 150),
  model_safePlacement,

  // Proper balanced_evo_A: genuine behavioural change (stronger human-prior,
  // more placement trials) — not just a param label change.
  makeBalancedVariant("evo_A",          0.50, 3.0, 250),

  // evo_A2: stronger finish-lock, same human-prior boost
  makeBalancedVariant("evo_A2",         0.50, 4.0, 250),

  // evo_A3: purer probability (less human-prior), very strong finish-lock,
  // highest placement effort
  makeBalancedVariant("evo_A3",         0.25, 4.5, 350),
];

// ─────────────────────────────────────────────────────────────────────────────
// Low-level match runner (shared core)
// ─────────────────────────────────────────────────────────────────────────────

const MAX_TURNS = 200;

interface MatchSpec {
  attackA: BattleshipModel | null;   // null = shared fixed placement
  attackB: BattleshipModel | null;
  placementA: BattleshipModel | null;
  placementB: BattleshipModel | null;
  idxA: number;
  idxB: number;
  modelAName: string;
  modelBName: string;
  seed: number;
  sharedFleetSeed?: number;   // attack-only: both fleets from this seed
  refAttack?: BattleshipModel; // placement-only: shared attacker
}

function runMatch(spec: MatchSpec): MatchResult {
  const {
    attackA, attackB,
    placementA, placementB,
    idxA, idxB,
    modelAName, modelBName,
    seed,
  } = spec;

  const rngA_place = createRNG(deriveSeed(seed, 1));
  const rngB_place = createRNG(deriveSeed(seed, 2));
  const rngA_shoot = createRNG(deriveSeed(seed, 3));
  const rngB_shoot = createRNG(deriveSeed(seed, 4));

  // Placement: attack-only uses shared seed for both sides
  let fleetPlacementA: FleetPlacement;
  let fleetPlacementB: FleetPlacement;

  if (spec.sharedFleetSeed !== undefined) {
    // Attack-only: both use same fleet layout
    const sharedRng_A = createRNG(deriveSeed(spec.sharedFleetSeed, 99));
    const sharedRng_B = createRNG(deriveSeed(spec.sharedFleetSeed, 99));
    fleetPlacementA = placeFleetRandom(sharedRng_A);
    fleetPlacementB = placeFleetRandom(sharedRng_B);
  } else {
    fleetPlacementA = (placementA ?? spec.refAttack!).placeFleet(rngA_place);
    fleetPlacementB = (placementB ?? spec.refAttack!).placeFleet(rngB_place);
  }

  const fleetB = createLiveFleet(fleetPlacementB);
  const fleetA = createLiveFleet(fleetPlacementA);

  let advisorA = createAdvisor();
  let advisorB = createAdvisor();

  let turns = 0;
  let winner: "A" | "B" | "draw" = "draw";

  const shooterA = attackA ?? spec.refAttack!;
  const shooterB = attackB ?? spec.refAttack!;

  while (turns < MAX_TURNS) {
    {
      const [row, col] = shooterA.getNextMove(advisorA, rngA_shoot);
      const r = Math.max(0, Math.min(9, row));
      const c = Math.max(0, Math.min(9, col));
      const outcome = resolveShot(fleetB, r, c);
      if (outcome.result === "sunk" && outcome.sunkShipIndex !== undefined) {
        advisorA = applyOutcomeToAdvisor(advisorA, r, c, outcome, fleetB);
        const cluster = getSunkCluster(fleetB, outcome.sunkShipIndex);
        for (const [cr, cc] of cluster) {
          if (advisorA.radar[cr][cc] !== "sunk") advisorA.radar[cr][cc] = "sunk";
        }
      } else {
        advisorA = applyOutcomeToAdvisor(advisorA, r, c, outcome, fleetB);
      }
      turns++;
      if (isFleetSunk(fleetB)) { winner = "A"; break; }
    }
    {
      const [row, col] = shooterB.getNextMove(advisorB, rngB_shoot);
      const r = Math.max(0, Math.min(9, row));
      const c = Math.max(0, Math.min(9, col));
      const outcome = resolveShot(fleetA, r, c);
      if (outcome.result === "sunk" && outcome.sunkShipIndex !== undefined) {
        advisorB = applyOutcomeToAdvisor(advisorB, r, c, outcome, fleetA);
        const cluster = getSunkCluster(fleetA, outcome.sunkShipIndex);
        for (const [cr, cc] of cluster) {
          if (advisorB.radar[cr][cc] !== "sunk") advisorB.radar[cr][cc] = "sunk";
        }
      } else {
        advisorB = applyOutcomeToAdvisor(advisorB, r, c, outcome, fleetA);
      }
      turns++;
      if (isFleetSunk(fleetA)) { winner = "B"; break; }
    }
  }

  const aIsWinner = winner === "A";
  const bIsWinner = winner === "B";

  return {
    winnerId: aIsWinner ? idxA : bIsWinner ? idxB : -1,
    loserId:  aIsWinner ? idxB : bIsWinner ? idxA : -1,
    turns,
    winnerRemainingDecks: aIsWinner ? countRemainingDecks(fleetA)
                         : bIsWinner ? countRemainingDecks(fleetB) : 0,
    winnerRemainingShips: aIsWinner ? countRemainingShips(fleetA)
                         : bIsWinner ? countRemainingShips(fleetB) : 0,
    winnerEnemyDecksSunk: aIsWinner ? TOTAL_DECKS - countRemainingDecks(fleetB)
                         : bIsWinner ? TOTAL_DECKS - countRemainingDecks(fleetA) : 0,
    firstPlayerWon: aIsWinner,
    seed,
    modelAName,
    modelBName,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers: ordered pairs (no self-play), stats, formatting
// ─────────────────────────────────────────────────────────────────────────────

function orderedPairs(models: BattleshipModel[]): [number, number][] {
  const pairs: [number, number][] = [];
  for (let i = 0; i < models.length; i++)
    for (let j = 0; j < models.length; j++)
      if (i !== j) pairs.push([i, j]);
  return pairs;
}

function stdDev(values: number[]): number {
  if (values.length < 2) return 0;
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((a, b) => a + (b - mean) ** 2, 0) / (values.length - 1);
  return Math.sqrt(variance);
}

function pct(v: number) { return (v * 100).toFixed(1) + "%"; }
function fmt(v: number, d = 2) { return v.toFixed(d); }
function pad(s: string | number, n: number, right = false) {
  const str = String(s);
  return right ? str.padEnd(n) : str.padStart(n);
}

// ─────────────────────────────────────────────────────────────────────────────
// Phase runner helpers
// ─────────────────────────────────────────────────────────────────────────────

interface PhaseResult {
  stats: ModelStats[];
  batchWinRates?: Record<string, number[]>; // name → per-batch win rates
}

function runAttackPhase(
  models: BattleshipModel[],
  seedsPerPair: number,
  baseSeed: number,
): PhaseResult {
  const pairs = orderedPairs(models);
  const total = pairs.length * seedsPerPair;
  const results: MatchResult[] = [];
  let completed = 0;
  const reportInterval = Math.max(1, Math.floor(total / 10));

  console.log(`  ${pairs.length} ordered pairs × ${seedsPerPair} seeds = ${total} matches`);

  for (const [ai, bi] of pairs) {
    for (let s = 0; s < seedsPerPair; s++) {
      const seed = deriveSeed(baseSeed, ai * 10000 + bi * 100 + s + 0x1000);
      const sharedFleetSeed = deriveSeed(baseSeed, s + 0xAA00);
      results.push(runMatch({
        attackA: models[ai], attackB: models[bi],
        placementA: null, placementB: null,
        idxA: ai, idxB: bi,
        modelAName: models[ai].name,
        modelBName: models[bi].name,
        seed,
        sharedFleetSeed,
      }));
      completed++;
      if (completed % reportInterval === 0)
        process.stdout.write(`\r  Progress: ${completed}/${total} (${Math.round(completed/total*100)}%)`);
    }
  }
  process.stdout.write(`\r  Progress: ${total}/${total} (100%) ✓\n`);
  return { stats: models.map((m, i) => buildModelStats(i, m.name, results)) };
}

function runPlacementPhase(
  models: BattleshipModel[],
  seedsPerPair: number,
  baseSeed: number,
  refAttacker: BattleshipModel,
): PhaseResult {
  const pairs = orderedPairs(models);
  const total = pairs.length * seedsPerPair;
  const results: MatchResult[] = [];
  let completed = 0;
  const reportInterval = Math.max(1, Math.floor(total / 10));

  console.log(`  ${pairs.length} ordered pairs × ${seedsPerPair} seeds = ${total} matches`);
  console.log(`  Reference attacker: ${refAttacker.name}`);

  for (const [ai, bi] of pairs) {
    for (let s = 0; s < seedsPerPair; s++) {
      const seed = deriveSeed(baseSeed, ai * 10000 + bi * 100 + s + 0x2000);
      results.push(runMatch({
        attackA: null, attackB: null,
        placementA: models[ai], placementB: models[bi],
        idxA: ai, idxB: bi,
        modelAName: models[ai].name,
        modelBName: models[bi].name,
        seed,
        refAttack: refAttacker,
      }));
      completed++;
      if (completed % reportInterval === 0)
        process.stdout.write(`\r  Progress: ${completed}/${total} (${Math.round(completed/total*100)}%)`);
    }
  }
  process.stdout.write(`\r  Progress: ${total}/${total} (100%) ✓\n`);
  return { stats: models.map((m, i) => buildModelStats(i, m.name, results)) };
}

function runFullPhase(
  models: BattleshipModel[],
  seedsPerPair: number,
  numBatches: number,
  baseSeed: number,
): PhaseResult {
  const pairs = orderedPairs(models);
  const seedsPerBatch = Math.floor(seedsPerPair / numBatches);
  const totalSeeds = seedsPerBatch * numBatches;
  const total = pairs.length * totalSeeds;
  const results: MatchResult[] = [];
  const batchResults: MatchResult[][] = Array.from({ length: numBatches }, () => []);
  let completed = 0;
  const reportInterval = Math.max(1, Math.floor(total / 20));

  console.log(`  ${pairs.length} ordered pairs × ${totalSeeds} seeds (${numBatches} batches × ${seedsPerBatch}) = ${total} matches`);

  for (let b = 0; b < numBatches; b++) {
    for (const [ai, bi] of pairs) {
      for (let s = 0; s < seedsPerBatch; s++) {
        const seed = deriveSeed(baseSeed, b * 100000 + ai * 10000 + bi * 100 + s);
        const result = runMatch({
          attackA: models[ai], attackB: models[bi],
          placementA: models[ai], placementB: models[bi],
          idxA: ai, idxB: bi,
          modelAName: models[ai].name,
          modelBName: models[bi].name,
          seed,
        });
        results.push(result);
        batchResults[b].push(result);
        completed++;
        if (completed % reportInterval === 0)
          process.stdout.write(`\r  Progress: ${completed}/${total} (${Math.round(completed/total*100)}%)`);
      }
    }
  }
  process.stdout.write(`\r  Progress: ${total}/${total} (100%) ✓\n`);

  const stats = models.map((m, i) => buildModelStats(i, m.name, results));

  // Per-batch win rates for std-dev calculation
  const batchWinRates: Record<string, number[]> = {};
  for (const m of models) batchWinRates[m.name] = [];

  for (let b = 0; b < numBatches; b++) {
    for (let i = 0; i < models.length; i++) {
      const batchStat = buildModelStats(i, models[i].name, batchResults[b]);
      batchWinRates[models[i].name].push(batchStat.winRate);
    }
  }

  return { stats, batchWinRates };
}

// ─────────────────────────────────────────────────────────────────────────────
// Print helpers
// ─────────────────────────────────────────────────────────────────────────────

function printTable(
  stats: ModelStats[],
  label: string,
  batchWinRates?: Record<string, number[]>,
): void {
  const sorted = [...stats].sort((a, b) => b.winRate - a.winRate);
  console.log(`\n── ${label} ─────────────────────────────────────────────────`);

  const W = [5, 18, 7, 7, 7, 10, 11, 11, 11, 10];
  const HEADERS = ["Rank","Model","Win%","Decks↑","Ships↑","Margin↑","1st-Win%","2nd-Win%","StdDev","Score"];
  const header = HEADERS.map((h, i) => pad(h, W[i], i === 1)).join(" │ ");
  const divider = W.map(w => "─".repeat(w)).join("─┼─");
  console.log(header);
  console.log(divider);

  sorted.forEach((s, rank) => {
    const fp = s.firstPlayerGames > 0 ? s.firstPlayerWins / s.firstPlayerGames : 0;
    const sp = s.secondPlayerGames > 0 ? s.secondPlayerWins / s.secondPlayerGames : 0;
    const sd = batchWinRates?.[s.name] ? stdDev(batchWinRates[s.name]) : 0;
    const row = [
      pad(rank+1, W[0]),
      pad(s.name, W[1], true),
      pad(pct(s.winRate), W[2]),
      pad(fmt(s.avgRemainingDecks), W[3]),
      pad(fmt(s.avgRemainingShips), W[4]),
      pad(fmt(s.avgMarginOfVictory), W[5]),
      pad(pct(fp), W[6]),
      pad(pct(sp), W[7]),
      pad(fmt(sd, 3), W[8]),
      pad(fmt(s.avgScore, 1), W[9]),
    ].join(" │ ");
    console.log(row);
  });
  console.log("");
}

// ─────────────────────────────────────────────────────────────────────────────
// Save outputs
// ─────────────────────────────────────────────────────────────────────────────

interface FinalOutput {
  meta: {
    timestamp: string;
    totalMatches: number;
    candidates: string[];
    fullSeeds: number;
    attackSeeds: number;
    placementSeeds: number;
    batches: number;
  };
  full: {
    rankedByWinRate: ReturnType<typeof enrichStats>;
    batchStdDev: Record<string, number>;
  };
  attackOnly: { rankedByWinRate: ReturnType<typeof enrichStats> };
  placementOnly: { rankedByWinRate: ReturnType<typeof enrichStats> };
  hybrid: {
    created: boolean;
    definition: string;
    stats: ReturnType<typeof enrichStats> | null;
  };
  verdicts: {
    bestOverall: string;
    bestAttack: string;
    bestPlacement: string;
    useHybrid: boolean;
    hybridVerdict: string;
    recommendation: string;
  };
}

function enrichStats(stats: ModelStats[]) {
  return [...stats]
    .sort((a, b) => b.winRate - a.winRate)
    .map(s => ({
      ...s,
      firstPlayerWinRate: s.firstPlayerGames > 0 ? s.firstPlayerWins / s.firstPlayerGames : 0,
      secondPlayerWinRate: s.secondPlayerGames > 0 ? s.secondPlayerWins / s.secondPlayerGames : 0,
    }));
}

function saveResults(output: FinalOutput): void {
  const jsonPath = resolve(OUTPUT_DIR, "final_results.json");
  writeFileSync(jsonPath, JSON.stringify(output, null, 2), "utf-8");
  console.log(`  Saved JSON → ${jsonPath}`);

  // Build flat CSV from full stats
  const rows = output.full.rankedByWinRate.map((s, i) => {
    const sd = output.full.batchStdDev[s.name] ?? 0;
    const atkRank = output.attackOnly.rankedByWinRate.findIndex(x => x.name === s.name) + 1;
    const plcRank = output.placementOnly.rankedByWinRate.findIndex(x => x.name === s.name) + 1;
    return [
      i+1, s.name,
      s.winRate.toFixed(4), s.avgRemainingDecks.toFixed(2),
      s.avgRemainingShips.toFixed(2), s.avgMarginOfVictory.toFixed(2),
      s.firstPlayerWinRate.toFixed(4), s.secondPlayerWinRate.toFixed(4),
      sd.toFixed(4), s.avgScore.toFixed(2), s.totalGames,
      s.wins, s.losses, s.draws,
      atkRank, plcRank,
    ].join(",");
  });

  const headers = [
    "rank","name","winRate","avgRemainingDecks","avgRemainingShips",
    "avgMarginOfVictory","firstPlayerWinRate","secondPlayerWinRate",
    "batchStdDev","avgScore","totalGames","wins","losses","draws",
    "attackOnlyRank","placementOnlyRank",
  ].join(",");

  const csvPath = resolve(OUTPUT_DIR, "final_results.csv");
  writeFileSync(csvPath, [headers, ...rows].join("\n"), "utf-8");
  console.log(`  Saved CSV  → ${csvPath}`);
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────────────────────────────────────

async function main() {
  const t0 = Date.now();
  console.log("╔══════════════════════════════════════════════════════════╗");
  console.log("║         BATTLESHIP AI FINAL SELECTION TOURNAMENT         ║");
  console.log("╚══════════════════════════════════════════════════════════╝");
  console.log(`  Started : ${new Date().toISOString()}`);
  console.log(`  Candidates (${CANDIDATES.length}): ${CANDIDATES.map(m => m.name).join(", ")}`);
  console.log("");

  let totalMatches = 0;

  // ── Phase 1: Full model ──────────────────────────────────────────────────
  console.log("═══ PHASE 1: FULL MODEL (own attack + own placement) ═══════");
  const fullPhase = runFullPhase(CANDIDATES, FULL_SEEDS, FULL_BATCHES, BASE_SEED);
  totalMatches += CANDIDATES.length * (CANDIDATES.length - 1) * Math.floor(FULL_SEEDS / FULL_BATCHES) * FULL_BATCHES;

  const fullBatchStdDev: Record<string, number> = {};
  for (const m of CANDIDATES) {
    fullBatchStdDev[m.name] = stdDev(fullPhase.batchWinRates![m.name] ?? []);
  }
  printTable(fullPhase.stats, "FULL MODEL RESULTS", fullPhase.batchWinRates);

  const fullSorted = [...fullPhase.stats].sort((a, b) => b.winRate - a.winRate);
  const bestFullName = fullSorted[0].name;
  console.log(`  ★ Best full model: ${bestFullName}  (${pct(fullSorted[0].winRate)} win rate)`);
  console.log(`    Batch std-dev: ${Object.entries(fullBatchStdDev).map(([k, v]) => `${k}=${fmt(v*100, 2)}%`).join("  ")}`);

  // ── Phase 2: Attack-only ─────────────────────────────────────────────────
  console.log("\n═══ PHASE 2: ATTACK-ONLY (identical shared fleet) ══════════");
  const attackPhase = runAttackPhase(CANDIDATES, ATTACK_SEEDS, BASE_SEED + 0x100);
  totalMatches += CANDIDATES.length * (CANDIDATES.length - 1) * ATTACK_SEEDS;

  printTable(attackPhase.stats, "ATTACK-ONLY RESULTS");
  const attackSorted = [...attackPhase.stats].sort((a, b) => b.winRate - a.winRate);
  const bestAttackName = attackSorted[0].name;
  console.log(`  ★ Best attacker: ${bestAttackName}  (${pct(attackSorted[0].winRate)} win rate)`);

  // ── Phase 3: Placement-only ──────────────────────────────────────────────
  console.log("\n═══ PHASE 3: PLACEMENT-ONLY (shared baseline attacker) ═════");
  const placePhase = runPlacementPhase(CANDIDATES, PLACE_SEEDS, BASE_SEED + 0x200, model_baseline);
  totalMatches += CANDIDATES.length * (CANDIDATES.length - 1) * PLACE_SEEDS;

  printTable(placePhase.stats, "PLACEMENT-ONLY RESULTS");
  const placeSorted = [...placePhase.stats].sort((a, b) => b.winRate - a.winRate);
  const bestPlaceName = placeSorted[0].name;
  console.log(`  ★ Best placement: ${bestPlaceName}  (${pct(placeSorted[0].winRate)} win rate, avg ${fmt(placeSorted[0].avgRemainingDecks)} decks surviving)`);

  // ── Phase 4 (conditional): Hybrid ───────────────────────────────────────
  const attackDiffersFromPlacement = bestAttackName !== bestPlaceName;
  let hybridStats: ModelStats[] | null = null;
  let hybridDef = "N/A";
  let hybridWinRate: number | null = null;

  if (attackDiffersFromPlacement) {
    console.log(`\n═══ PHASE 4: HYBRID (attack=${bestAttackName}, placement=${bestPlaceName}) ═`);

    const bestAttackModel = CANDIDATES.find(m => m.name === bestAttackName)!;
    const bestPlaceModel  = CANDIDATES.find(m => m.name === bestPlaceName)!;

    const hybridModel: BattleshipModel = {
      name: "hybrid_final",
      params: { ...bestAttackModel.params, placementTrials: (bestPlaceModel.params?.placementTrials ?? 150) },
      getNextMove(advisor, rng) { return bestAttackModel.getNextMove(advisor, rng); },
      placeFleet(rng) { return bestPlaceModel.placeFleet(rng); },
    };

    hybridDef = `attack: ${bestAttackName}  +  placement: ${bestPlaceName}`;
    console.log(`  Hybrid composition: ${hybridDef}`);

    const hybridCandidates = [...CANDIDATES, hybridModel];
    const hybridIdx = hybridCandidates.length - 1;

    // Run hybrid vs all others (ordered pairs involving hybrid only)
    const hybridPairs: [number, number][] = [];
    for (let i = 0; i < CANDIDATES.length; i++) {
      hybridPairs.push([hybridIdx, i]);
      hybridPairs.push([i, hybridIdx]);
    }

    const hybridMatchResults: MatchResult[] = [];
    const hybridTotal = hybridPairs.length * HYBRID_SEEDS;
    let hybridCompleted = 0;
    const hybridInterval = Math.max(1, Math.floor(hybridTotal / 10));

    console.log(`  ${hybridPairs.length} ordered pairs × ${HYBRID_SEEDS} seeds = ${hybridTotal} matches`);

    for (const [ai, bi] of hybridPairs) {
      for (let s = 0; s < HYBRID_SEEDS; s++) {
        const seed = deriveSeed(BASE_SEED + 0x300, ai * 10000 + bi * 100 + s);
        hybridMatchResults.push(runMatch({
          attackA: hybridCandidates[ai],
          attackB: hybridCandidates[bi],
          placementA: hybridCandidates[ai],
          placementB: hybridCandidates[bi],
          idxA: ai, idxB: bi,
          modelAName: hybridCandidates[ai].name,
          modelBName: hybridCandidates[bi].name,
          seed,
        }));
        hybridCompleted++;
        if (hybridCompleted % hybridInterval === 0)
          process.stdout.write(`\r  Progress: ${hybridCompleted}/${hybridTotal} (${Math.round(hybridCompleted/hybridTotal*100)}%)`);
      }
    }
    process.stdout.write(`\r  Progress: ${hybridTotal}/${hybridTotal} (100%) ✓\n`);

    hybridStats = hybridCandidates.map((m, i) =>
      buildModelStats(i, m.name, hybridMatchResults)
    );
    totalMatches += hybridTotal;

    printTable(hybridStats, "HYBRID PLAYOFF RESULTS");
    const hybridSorted = [...hybridStats].sort((a, b) => b.winRate - a.winRate);
    const hybridEntry = hybridSorted.find(s => s.name === "hybrid_final");
    hybridWinRate = hybridEntry?.winRate ?? null;
    const hybridRank = hybridSorted.findIndex(s => s.name === "hybrid_final") + 1;
    console.log(`  hybrid_final rank: ${hybridRank} / ${hybridCandidates.length}  (${pct(hybridWinRate ?? 0)} win rate)`);
  } else {
    console.log(`\n  Skipping hybrid phase — best attack and best placement are the same model (${bestAttackName}).`);
  }

  // ── Final verdicts ───────────────────────────────────────────────────────
  const useHybrid = attackDiffersFromPlacement && (hybridWinRate ?? 0) > fullSorted[0].winRate;

  const recommendation = useHybrid
    ? `Use hybrid_final as the main AI (${pct(hybridWinRate!)} win rate vs ${pct(fullSorted[0].winRate)} for ${bestFullName})`
    : `Use ${bestFullName} as the main AI — it already combines best attack and placement`;

  const hybridVerdictText = attackDiffersFromPlacement
    ? (useHybrid
        ? `YES — hybrid_final (${pct(hybridWinRate!)} win rate) outperforms ${bestFullName} (${pct(fullSorted[0].winRate)})`
        : `NO  — hybrid (${pct(hybridWinRate ?? 0)} win rate) does NOT beat ${bestFullName} (${pct(fullSorted[0].winRate)})`)
    : `N/A — best attack and best placement are the same model`;

  console.log("\n" + "━".repeat(60));
  console.log(" FINAL VERDICTS");
  console.log("━".repeat(60));
  console.log(`  🏆 Best full model:   ${bestFullName.padEnd(20)} ${pct(fullSorted[0].winRate)} (batch σ=${fmt(fullBatchStdDev[bestFullName]*100, 2)}%)`);
  console.log(`  ⚔️  Best attacker:     ${bestAttackName.padEnd(20)} ${pct(attackSorted[0].winRate)} (attack-only)`);
  console.log(`  🛡️  Best placement:    ${bestPlaceName.padEnd(20)} ${pct(placeSorted[0].winRate)} (vs shared attacker)`);
  console.log(`  🔀 Use hybrid_final?: ${hybridVerdictText}`);
  console.log(`  📌 Recommendation:    ${recommendation}`);
  console.log(`  ⏱  Total elapsed:     ${((Date.now()-t0)/1000).toFixed(1)}s`);
  console.log(`  🎮 Total matches:     ${totalMatches}`);
  console.log("━".repeat(60));

  // ── Save ─────────────────────────────────────────────────────────────────
  console.log("\n── Saving final results ─────────────────────────────────────");
  const output: FinalOutput = {
    meta: {
      timestamp: new Date().toISOString(),
      totalMatches,
      candidates: CANDIDATES.map(m => m.name),
      fullSeeds: FULL_SEEDS,
      attackSeeds: ATTACK_SEEDS,
      placementSeeds: PLACE_SEEDS,
      batches: FULL_BATCHES,
    },
    full: {
      rankedByWinRate: enrichStats(fullPhase.stats),
      batchStdDev: fullBatchStdDev,
    },
    attackOnly: { rankedByWinRate: enrichStats(attackPhase.stats) },
    placementOnly: { rankedByWinRate: enrichStats(placePhase.stats) },
    hybrid: {
      created: attackDiffersFromPlacement,
      definition: hybridDef,
      stats: hybridStats ? enrichStats(hybridStats) : null,
    },
    verdicts: {
      bestOverall: bestFullName,
      bestAttack: bestAttackName,
      bestPlacement: bestPlaceName,
      useHybrid,
      hybridVerdict: hybridVerdictText,
      recommendation,
    },
  };
  saveResults(output);
}

main().catch(err => {
  console.error("Final selection error:", err);
  process.exit(1);
});
