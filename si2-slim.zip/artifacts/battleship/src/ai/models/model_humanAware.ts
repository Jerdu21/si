/**
 * model_humanAware — Exploits human fleet placement tendencies.
 *
 * Human players tend to:
 *  - Avoid placing ships on the very edge of the board (exposed).
 *  - Or, conversely, hide small ships in corners.
 *  - Avoid the absolute centre (feels too obvious).
 *  - Place ships near the border but not ON it.
 *  - Leave large ships roughly diagonal from each other.
 *
 * This model applies a subtle "human prior" bias on top of the probability map:
 *
 *  - edgeBias:    slight boost for cells on the 2nd row/column from edges.
 *  - cornerBias:  boost for corner-adjacent cells (ships hiding in corners).
 *  - antiCenter:  mild penalty for the 3x3 central zone.
 *  - borderBias:  a small boost for the outermost ring.
 *
 * These biases are only applied in HUNT mode (when no active hits).
 * In TARGET mode, the model uses pure probability-ranked cluster extension.
 *
 * NOTE: The biases are intentionally mild so the model is not over-fitted to
 * any single opponent archetype.
 *
 * Placement: random.
 */

import { SIZE, type AdvisorState, computeProbabilityMap } from "@/lib/gameLogic";
import { pickRandom, type RNG } from "../randomSeed";
import { placeFleetRandom } from "../gameEngine";
import { type BattleshipModel, type Move, type FleetPlacement } from "../modelTypes";

// Human-prior bias map (precomputed, same every game)
const HUMAN_PRIOR: number[][] = (() => {
  const map = Array.from({ length: SIZE }, () => Array(SIZE).fill(1.0));
  const mid = (SIZE - 1) / 2;

  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      let bias = 1.0;

      // Anti-center penalty (innermost 4x4 zone)
      const dCenter = Math.max(Math.abs(r - mid), Math.abs(c - mid));
      if (dCenter <= 1.5) bias *= 0.75;

      // Near-edge boost (2nd row/col from the border)
      const dEdge = Math.min(r, SIZE - 1 - r, c, SIZE - 1 - c);
      if (dEdge === 1) bias *= 1.35;
      if (dEdge === 0) bias *= 1.15; // outermost ring slightly less than 2nd

      // Corner-adjacent boost (corners + their immediate neighbours)
      const isCornerAdj =
        (r <= 1 || r >= SIZE - 2) && (c <= 1 || c >= SIZE - 2);
      if (isCornerAdj) bias *= 1.25;

      map[r][c] = bias;
    }
  }
  return map;
})();

function keyOf(r: number, c: number) { return `${r},${c}`; }

function getHitClusters(radar: AdvisorState["radar"]): [number, number][][] {
  const visited = new Set<string>();
  const clusters: [number, number][][] = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const k = keyOf(r, c);
      if (radar[r][c] !== "hit" || visited.has(k)) continue;
      const cluster: [number, number][] = [];
      const q: [number, number][] = [[r, c]];
      while (q.length) {
        const [cr, cc] = q.shift()!;
        const ck = keyOf(cr, cc);
        if (visited.has(ck) || radar[cr][cc] !== "hit") continue;
        visited.add(ck);
        cluster.push([cr, cc]);
        for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
          const nr = cr+dr, nc = cc+dc;
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE) q.push([nr, nc]);
        }
      }
      if (cluster.length) clusters.push(cluster);
    }
  }
  return clusters;
}

function chooseBest(
  candidates: [number, number][],
  score: number[][],
  rng: RNG,
): [number, number] | null {
  if (!candidates.length) return null;
  let best = -Infinity;
  let bestCells: [number, number][] = [];
  for (const [r, c] of candidates) {
    const s = score[r][c];
    if (s > best) { best = s; bestCells = [[r, c]]; }
    else if (s === best) bestCells.push([r, c]);
  }
  return pickRandom(bestCells, rng);
}

export const model_humanAware: BattleshipModel = {
  name: "humanAware",
  params: {
    edgeBias: 1.35,
    cornerBias: 1.25,
    antiCenter: 0.75,
    parityFilter: 1,
  },

  getNextMove(advisor: AdvisorState, rng: RNG): Move {
    const prob = computeProbabilityMap(advisor);

    if (advisor.hits.length > 0) {
      // Target mode: pure probability, no human-prior bias
      const clusters = getHitClusters(advisor.radar);
      const candidates: [number, number][] = [];
      const seen = new Set<string>();
      for (const cluster of clusters) {
        for (const [hr, hc] of cluster) {
          for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
            const nr = hr+dr, nc = hc+dc;
            const k = keyOf(nr, nc);
            if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE
              && advisor.radar[nr][nc] === "empty" && !seen.has(k)) {
              seen.add(k);
              candidates.push([nr, nc]);
            }
          }
        }
      }
      if (candidates.length) {
        return chooseBest(candidates, prob, rng) ?? candidates[0];
      }
    }

    // Hunt mode: probability × human prior, with parity filter
    const smallest = advisor.remainingShips.length > 0 ? Math.min(...advisor.remainingShips) : 1;
    const useCheckerboard = smallest > 1;

    const biasedScore: number[][] = Array.from({ length: SIZE }, (_, r) =>
      Array.from({ length: SIZE }, (_, c) => {
        if (advisor.radar[r][c] !== "empty") return 0;
        return prob[r][c] * HUMAN_PRIOR[r][c];
      })
    );

    const parity: [number, number][] = [];
    const all: [number, number][] = [];
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (advisor.radar[r][c] !== "empty") continue;
        all.push([r, c]);
        if (!useCheckerboard || (r + c) % 2 === 0) parity.push([r, c]);
      }
    }

    return chooseBest(parity.length ? parity : all, biasedScore, rng) ?? [0, 0];
  },

  placeFleet(rng: RNG): FleetPlacement {
    return placeFleetRandom(rng);
  },
};
