/**
 * model_baseline — Closest re-implementation of the existing AI Advisor.
 *
 * Shooting: probability-map hunt with checkerboard parity filter + target mode
 *           that covers hit clusters. Mirrors the logic in gameLogic.ts getBestShot.
 *           Uses seeded RNG for tie-breaking to ensure reproducibility.
 *
 * NOTE: The original gameLogic.ts getBestShot uses Math.random() for tie-breaking.
 *       This model re-implements the same algorithm with a passed-in RNG so results
 *       are deterministic within the tournament. The strategy is otherwise identical.
 *
 * Placement: random valid placement (no defensive scoring).
 */

import {
  SIZE,
  type AdvisorState,
} from "@/lib/gameLogic";

import {
  computeProbabilityMap,
} from "@/lib/gameLogic";

import { pickRandom, type RNG } from "../randomSeed";
import { placeFleetRandom } from "../gameEngine";
import { type BattleshipModel, type Move, type FleetPlacement } from "../modelTypes";

// ── Internal helpers ──────────────────────────────────────────────────────────

function keyOf(r: number, c: number) { return `${r},${c}`; }

function getHitClusters(radar: AdvisorState["radar"]): [number, number][][] {
  const visited = new Set<string>();
  const clusters: [number, number][][] = [];

  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const k = keyOf(r, c);
      if (radar[r][c] !== "hit" || visited.has(k)) continue;
      const cluster: [number, number][] = [];
      const q: [number, number][] = [[r, c]];
      while (q.length) {
        const [cr, cc] = q.shift()!;
        const ck = keyOf(cr, cc);
        if (visited.has(ck) || radar[cr][cc] !== "hit") continue;
        visited.add(ck);
        cluster.push([cr, cc]);
        for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
          const nr = cr+dr, nc = cc+dc;
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE) q.push([nr, nc]);
        }
      }
      if (cluster.length) clusters.push(cluster);
    }
  }
  return clusters;
}

function chooseBest(
  candidates: [number, number][],
  score: number[][],
  rng: RNG,
): [number, number] | null {
  if (!candidates.length) return null;
  let best = -1;
  let bestCells: [number, number][] = [];
  for (const [r, c] of candidates) {
    const s = score[r][c];
    if (s > best) { best = s; bestCells = [[r, c]]; }
    else if (s === best) bestCells.push([r, c]);
  }
  return pickRandom(bestCells, rng);
}

// ── Shoot logic ───────────────────────────────────────────────────────────────

function huntShot(advisor: AdvisorState, rng: RNG): Move | null {
  const score = computeProbabilityMap(advisor);
  const smallest = advisor.remainingShips.length > 0 ? Math.min(...advisor.remainingShips) : 1;
  const useCheckerboard = smallest > 1;

  const parity: [number, number][] = [];
  const all: [number, number][] = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if (advisor.radar[r][c] !== "empty") continue;
      all.push([r, c]);
      if (!useCheckerboard || (r + c) % 2 === 0) parity.push([r, c]);
    }
  }
  return chooseBest(parity.length ? parity : all, score, rng);
}

function targetShot(advisor: AdvisorState, rng: RNG): Move {
  const score = computeProbabilityMap(advisor);
  const clusters = getHitClusters(advisor.radar);

  // Build candidate cells from each cluster
  let bestCandidates: [number, number][] = [];

  for (const cluster of clusters) {
    const candidates: [number, number][] = [];
    const seen = new Set<string>();
    // Extend in the 4 cardinal directions from each hit cell in the cluster
    for (const [hr, hc] of cluster) {
      for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
        const nr = hr+dr, nc = hc+dc;
        const k = keyOf(nr, nc);
        if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE
          && advisor.radar[nr][nc] === "empty" && !seen.has(k)) {
          seen.add(k);
          candidates.push([nr, nc]);
        }
      }
    }
    if (candidates.length > bestCandidates.length) bestCandidates = candidates;
  }

  if (bestCandidates.length) {
    return chooseBest(bestCandidates, score, rng) ?? bestCandidates[0];
  }

  return huntShot(advisor, rng) ?? advisor.hits[0];
}

// ── Model export ──────────────────────────────────────────────────────────────

export const model_baseline: BattleshipModel = {
  name: "baseline",
  params: { parityFilter: 1, trials: 0 },

  getNextMove(advisor: AdvisorState, rng: RNG): Move {
    if (advisor.hits.length > 0) return targetShot(advisor, rng);
    return huntShot(advisor, rng) ?? [0, 0];
  },

  placeFleet(rng: RNG): FleetPlacement {
    return placeFleetRandom(rng);
  },
};
