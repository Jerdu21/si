/**
 * model_prob — Pure probability density model.
 *
 * Shooting: always shoots the cell with the highest probability count from
 *           computeProbabilityMap(). No checkerboard parity filter.
 *           In target mode: still uses probability to rank extension cells.
 *           Simple but strong — probability alone is a very effective signal.
 *
 * Placement: random.
 */

import { SIZE, type AdvisorState, computeProbabilityMap } from "@/lib/gameLogic";
import { pickRandom, type RNG } from "../randomSeed";
import { placeFleetRandom } from "../gameEngine";
import { type BattleshipModel, type Move, type FleetPlacement } from "../modelTypes";

function keyOf(r: number, c: number) { return `${r},${c}`; }

function chooseBestByProb(
  candidates: [number, number][],
  prob: number[][],
  rng: RNG,
): [number, number] | null {
  if (!candidates.length) return null;
  let best = -Infinity;
  let bestCells: [number, number][] = [];
  for (const [r, c] of candidates) {
    const s = prob[r][c];
    if (s > best) { best = s; bestCells = [[r, c]]; }
    else if (s === best) bestCells.push([r, c]);
  }
  return pickRandom(bestCells, rng);
}

function getHitClusters(radar: AdvisorState["radar"]): [number, number][][] {
  const visited = new Set<string>();
  const clusters: [number, number][][] = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const k = keyOf(r, c);
      if (radar[r][c] !== "hit" || visited.has(k)) continue;
      const cluster: [number, number][] = [];
      const q: [number, number][] = [[r, c]];
      while (q.length) {
        const [cr, cc] = q.shift()!;
        const ck = keyOf(cr, cc);
        if (visited.has(ck) || radar[cr][cc] !== "hit") continue;
        visited.add(ck);
        cluster.push([cr, cc]);
        for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
          const nr = cr+dr, nc = cc+dc;
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE) q.push([nr, nc]);
        }
      }
      if (cluster.length) clusters.push(cluster);
    }
  }
  return clusters;
}

export const model_prob: BattleshipModel = {
  name: "prob",
  params: { parityFilter: 0, targetMode: "cluster" },

  getNextMove(advisor: AdvisorState, rng: RNG): Move {
    const prob = computeProbabilityMap(advisor);

    if (advisor.hits.length > 0) {
      // Target mode: collect neighbours of all active hit clusters
      const clusters = getHitClusters(advisor.radar);
      const candidates: [number, number][] = [];
      const seen = new Set<string>();
      for (const cluster of clusters) {
        for (const [hr, hc] of cluster) {
          for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
            const nr = hr+dr, nc = hc+dc;
            const k = keyOf(nr, nc);
            if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE
              && advisor.radar[nr][nc] === "empty" && !seen.has(k)) {
              seen.add(k);
              candidates.push([nr, nc]);
            }
          }
        }
      }
      if (candidates.length) {
        return chooseBestByProb(candidates, prob, rng) ?? candidates[0];
      }
    }

    // Hunt mode: all empty cells, ranked by pure probability
    const all: [number, number][] = [];
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (advisor.radar[r][c] === "empty") all.push([r, c]);
      }
    }
    return chooseBestByProb(all, prob, rng) ?? [0, 0];
  },

  placeFleet(rng: RNG): FleetPlacement {
    return placeFleetRandom(rng);
  },
};
