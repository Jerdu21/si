/**
 * model_safePlacement — Probability shooting + defensive fleet placement.
 *
 * Shooting: same as model_prob — pure probability-map hunting with
 *           cluster extension in target mode. Solid but not elaborate.
 *
 * Placement: SAFE / OPTIMISED — runs 500 random placement trials and
 *            keeps the one with the highest defensive score.
 *            The defensive score rewards:
 *              - ship cells on off-parity squares (harder to find via checkerboard)
 *              - good spread across all four quadrants
 *              - small ships pushed to edges and corners
 *              - mixed horizontal / vertical orientations
 *
 *            This is equivalent to the existing autoPlace() in gameLogic.ts
 *            but driven by the seeded RNG for reproducibility.
 *
 * The hypothesis: a better placement alone gives a meaningful survival edge,
 * even with an otherwise average shooting strategy.
 */

import { SIZE, type AdvisorState, computeProbabilityMap } from "@/lib/gameLogic";
import { pickRandom, type RNG } from "../randomSeed";
import { placeFleetSafe } from "../gameEngine";
import { type BattleshipModel, type Move, type FleetPlacement } from "../modelTypes";

function keyOf(r: number, c: number) { return `${r},${c}`; }

function getHitClusters(radar: AdvisorState["radar"]): [number, number][][] {
  const visited = new Set<string>();
  const clusters: [number, number][][] = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const k = keyOf(r, c);
      if (radar[r][c] !== "hit" || visited.has(k)) continue;
      const cluster: [number, number][] = [];
      const q: [number, number][] = [[r, c]];
      while (q.length) {
        const [cr, cc] = q.shift()!;
        const ck = keyOf(cr, cc);
        if (visited.has(ck) || radar[cr][cc] !== "hit") continue;
        visited.add(ck);
        cluster.push([cr, cc]);
        for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
          const nr = cr+dr, nc = cc+dc;
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE) q.push([nr, nc]);
        }
      }
      if (cluster.length) clusters.push(cluster);
    }
  }
  return clusters;
}

function chooseBest(
  candidates: [number, number][],
  score: number[][],
  rng: RNG,
): [number, number] | null {
  if (!candidates.length) return null;
  let best = -Infinity;
  let bestCells: [number, number][] = [];
  for (const [r, c] of candidates) {
    const s = score[r][c];
    if (s > best) { best = s; bestCells = [[r, c]]; }
    else if (s === best) bestCells.push([r, c]);
  }
  return pickRandom(bestCells, rng);
}

export const model_safePlacement: BattleshipModel = {
  name: "safePlacement",
  params: { placementTrials: 500, parityFilter: 0 },

  getNextMove(advisor: AdvisorState, rng: RNG): Move {
    const prob = computeProbabilityMap(advisor);

    if (advisor.hits.length > 0) {
      const clusters = getHitClusters(advisor.radar);
      const candidates: [number, number][] = [];
      const seen = new Set<string>();
      for (const cluster of clusters) {
        for (const [hr, hc] of cluster) {
          for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
            const nr = hr+dr, nc = hc+dc;
            const k = keyOf(nr, nc);
            if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE
              && advisor.radar[nr][nc] === "empty" && !seen.has(k)) {
              seen.add(k);
              candidates.push([nr, nc]);
            }
          }
        }
      }
      if (candidates.length) {
        return chooseBest(candidates, prob, rng) ?? candidates[0];
      }
    }

    const all: [number, number][] = [];
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (advisor.radar[r][c] === "empty") all.push([r, c]);
      }
    }
    return chooseBest(all, prob, rng) ?? [0, 0];
  },

  placeFleet(rng: RNG): FleetPlacement {
    // 150 trials of defensive placement (balance quality vs speed)
    return placeFleetSafe(rng, 150);
  },
};
