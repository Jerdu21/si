/**
 * model_balanced — Best-of-all-worlds universal model.
 *
 * This model combines the strongest elements from the other models:
 *
 * SHOOTING:
 *   Hunt mode:
 *     score(r,c) = prob[r][c]
 *                × humanPrior[r][c]         (mild edge/corner bias)
 *                × parityBoost(r,c)          (checkerboard parity when useful)
 *
 *   Target mode:
 *     1. Detect hit cluster orientation (horizontal / vertical / unknown)
 *     2. Strongly prefer extending along the detected axis (finisher logic)
 *     3. Score axis candidates by probability × cluster-coverage weight
 *     4. Fall back to cross-axis only when axis is fully blocked
 *
 * PLACEMENT:
 *   Uses safe/defensive placement (best of 400 random trials).
 *   Mirrors the existing autoPlace() strategy from gameLogic.ts.
 *
 * PARAMS:
 *   humanBias     — how strongly to apply the human-prior map (default 0.4)
 *   finishBias    — multiplier on axis-extension candidates vs cross (default 3.0)
 *   parityFilter  — 1 = use checkerboard in hunt, 0 = skip (default 1)
 *   placementTrials — defensive placement trials (default 400)
 */

import { SIZE, type AdvisorState, computeProbabilityMap } from "@/lib/gameLogic";
import { pickRandom, type RNG } from "../randomSeed";
import { placeFleetSafe } from "../gameEngine";
import { type BattleshipModel, type Move, type FleetPlacement } from "../modelTypes";

// ── Human prior (same as model_humanAware, precomputed) ───────────────────────

const HUMAN_PRIOR: number[][] = (() => {
  const map = Array.from({ length: SIZE }, () => Array(SIZE).fill(1.0));
  const mid = (SIZE - 1) / 2;
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      let bias = 1.0;
      const dCenter = Math.max(Math.abs(r - mid), Math.abs(c - mid));
      if (dCenter <= 1.5) bias *= 0.80;
      const dEdge = Math.min(r, SIZE - 1 - r, c, SIZE - 1 - c);
      if (dEdge === 1) bias *= 1.30;
      if (dEdge === 0) bias *= 1.12;
      const isCornerAdj = (r <= 1 || r >= SIZE - 2) && (c <= 1 || c >= SIZE - 2);
      if (isCornerAdj) bias *= 1.20;
      map[r][c] = bias;
    }
  }
  return map;
})();

// ── Helpers ───────────────────────────────────────────────────────────────────

function keyOf(r: number, c: number) { return `${r},${c}`; }

function getHitClusters(radar: AdvisorState["radar"]): [number, number][][] {
  const visited = new Set<string>();
  const clusters: [number, number][][] = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const k = keyOf(r, c);
      if (radar[r][c] !== "hit" || visited.has(k)) continue;
      const cluster: [number, number][] = [];
      const q: [number, number][] = [[r, c]];
      while (q.length) {
        const [cr, cc] = q.shift()!;
        const ck = keyOf(cr, cc);
        if (visited.has(ck) || radar[cr][cc] !== "hit") continue;
        visited.add(ck);
        cluster.push([cr, cc]);
        for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
          const nr = cr+dr, nc = cc+dc;
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE) q.push([nr, nc]);
        }
      }
      if (cluster.length) clusters.push(cluster);
    }
  }
  return clusters;
}

function detectOrientation(cluster: [number, number][]): "h" | "v" | "unknown" {
  if (cluster.length < 2) return "unknown";
  if (new Set(cluster.map(([r]) => r)).size === 1) return "h";
  if (new Set(cluster.map(([, c]) => c)).size === 1) return "v";
  return "unknown";
}

function chooseBest(
  candidates: [number, number][],
  score: number[][],
  rng: RNG,
): [number, number] | null {
  if (!candidates.length) return null;
  let best = -Infinity;
  let bestCells: [number, number][] = [];
  for (const [r, c] of candidates) {
    const s = score[r][c];
    if (s > best) { best = s; bestCells = [[r, c]]; }
    else if (s === best) bestCells.push([r, c]);
  }
  return pickRandom(bestCells, rng);
}

// ── Model export ──────────────────────────────────────────────────────────────

export const model_balanced: BattleshipModel = {
  name: "balanced",
  params: {
    humanBias: 0.4,
    finishBias: 3.0,
    parityFilter: 1,
    placementTrials: 150,
  },

  getNextMove(advisor: AdvisorState, rng: RNG): Move {
    const prob = computeProbabilityMap(advisor);
    const humanBias = 0.4;

    if (advisor.hits.length > 0) {
      const clusters = getHitClusters(advisor.radar);
      const sorted = [...clusters].sort((a, b) => b.length - a.length);

      for (const cluster of sorted) {
        const orient = detectOrientation(cluster);
        const seen = new Set<string>();
        const axisExt: [number, number][] = [];
        const crossExt: [number, number][] = [];

        for (const [hr, hc] of cluster) {
          const axisDirs: [number, number][] =
            orient === "h" ? [[0,-1],[0,1]]
            : orient === "v" ? [[-1,0],[1,0]]
            : [[-1,0],[1,0],[0,-1],[0,1]];
          const crossDirs: [number, number][] =
            orient === "h" ? [[-1,0],[1,0]]
            : orient === "v" ? [[0,-1],[0,1]]
            : [];

          for (const [dr, dc] of axisDirs) {
            const nr = hr+dr, nc = hc+dc;
            const k = keyOf(nr, nc);
            if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE
              && advisor.radar[nr][nc] === "empty" && !seen.has(k)) {
              seen.add(k); axisExt.push([nr, nc]);
            }
          }
          for (const [dr, dc] of crossDirs) {
            const nr = hr+dr, nc = hc+dc;
            const k = keyOf(nr, nc);
            if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE
              && advisor.radar[nr][nc] === "empty" && !seen.has(k)) {
              seen.add(k); crossExt.push([nr, nc]);
            }
          }
        }

        if (axisExt.length) {
          // Boost axis extensions by finishBias in the score array
          const boosted: number[][] = prob.map(row => [...row]);
          for (const [r, c] of axisExt) boosted[r][c] *= 3.0;
          return chooseBest(axisExt, boosted, rng) ?? axisExt[0];
        }
        if (crossExt.length) {
          return chooseBest(crossExt, prob, rng) ?? crossExt[0];
        }
      }

      // fallback to probability hunt if all clusters are fully blocked
    }

    // Hunt mode: probability × human prior
    const smallest = advisor.remainingShips.length > 0 ? Math.min(...advisor.remainingShips) : 1;
    const useCheckerboard = smallest > 1;

    const huntScore: number[][] = Array.from({ length: SIZE }, (_, r) =>
      Array.from({ length: SIZE }, (_, c) => {
        if (advisor.radar[r][c] !== "empty") return 0;
        const p = prob[r][c];
        const h = 1 + humanBias * (HUMAN_PRIOR[r][c] - 1);
        return p * h;
      })
    );

    const parity: [number, number][] = [];
    const all: [number, number][] = [];
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (advisor.radar[r][c] !== "empty") continue;
        all.push([r, c]);
        if (!useCheckerboard || (r + c) % 2 === 0) parity.push([r, c]);
      }
    }

    return chooseBest(parity.length ? parity : all, huntScore, rng) ?? [0, 0];
  },

  placeFleet(rng: RNG): FleetPlacement {
    return placeFleetSafe(rng, 400);
  },
};
