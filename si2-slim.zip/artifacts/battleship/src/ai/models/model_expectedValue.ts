/**
 * model_expectedValue — Expected-Value (EV) scoring model.
 *
 * Unlike probability-based models that simply pick the cell with the highest
 * P(hit), this model scores each candidate cell by the *expected utility* of
 * shooting it, combining four independent signals:
 *
 *   score(r,c) = P(hit)
 *              + 2.0 × P(kill ship)
 *              + 1.5 × information_gain
 *              + 1.0 × cluster_consistency
 *
 * ── COMPONENTS ───────────────────────────────────────────────────────────
 *
 * P(hit)
 *   Standard Bayesian hit probability from computeProbabilityMap().
 *   Probability that any surviving ship occupies (r,c).
 *
 * P(kill ship)
 *   Probability that this shot sinks an entire ship, not merely hits it.
 *
 *   In TARGET mode (active hit cluster):
 *     Cluster of length k along a detected axis → any cell that extends the
 *     cluster to exactly a remaining ship size s earns full P(kill) = P(hit).
 *     If multiple shots are still needed to complete the cluster, we use a
 *     linearly decaying estimate: P(kill) = P(hit) / shots_still_needed.
 *
 *   In HUNT mode:
 *     No cluster is active.  We estimate P(kill) = P(hit) / E[ship_size],
 *     where E[ship_size] is the probability-weighted mean size of remaining
 *     ships.  Smaller ships → higher P(kill) per hit → more value.
 *
 * Information gain
 *   The expected number of fleet arrangements eliminated by this shot,
 *   normalised to [0, 1].  Derived from the binary entropy of P(hit):
 *
 *     IG(p) = 2 × p × (1 − p)
 *
 *   This is maximised at p = 0.5 — cells with intermediate probability
 *   provide the most diagnostic information on BOTH outcomes (hit and miss).
 *   Pure probability-based models ignore this: they always chase the highest
 *   p even when that provides almost no information on a miss.
 *
 * Cluster consistency
 *   A geometric bonus that rewards axis-aligned shots when an active hit
 *   cluster has a detected orientation.
 *
 *   Axis extensions of a detected H/V cluster:  +1.0
 *   Cross-axis extensions (fallback candidates):  +0.2
 *   Unrelated cells in hunt mode:                  0.0
 *
 * ── PLACEMENT ────────────────────────────────────────────────────────────
 *   Uses 350-trial defensive placement (best-of-350 random layouts scored
 *   by the shared defensive scoring heuristic).  Matches evo_A3's placement
 *   quality so that we isolate the shooting difference in benchmarks.
 *
 * ── PARAMS ───────────────────────────────────────────────────────────────
 *   wHit           — weight on P(hit)            default 1.0
 *   wKill          — weight on P(kill ship)       default 2.0
 *   wInfoGain      — weight on information gain   default 1.5
 *   wConsistency   — weight on cluster alignment  default 1.0
 *   placementTrials — defensive placement trials   default 350
 */

import { SIZE, SHIPS, type AdvisorState, computeProbabilityMap } from "@/lib/gameLogic";
import { pickRandom, type RNG } from "../randomSeed";
import { placeFleetSafe } from "../gameEngine";
import { type BattleshipModel, type Move, type FleetPlacement } from "../modelTypes";

// ─────────────────────────────────────────────────────────────────────────────
// Geometry helpers
// ─────────────────────────────────────────────────────────────────────────────

function keyOf(r: number, c: number) { return `${r},${c}`; }

const DIRS4: [number, number][] = [[-1,0],[1,0],[0,-1],[0,1]];

function getHitClusters(radar: AdvisorState["radar"]): [number, number][][] {
  const visited = new Set<string>();
  const clusters: [number, number][][] = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const k = keyOf(r, c);
      if (radar[r][c] !== "hit" || visited.has(k)) continue;
      const cluster: [number, number][] = [];
      const q: [number, number][] = [[r, c]];
      while (q.length) {
        const [cr, cc] = q.shift()!;
        const ck = keyOf(cr, cc);
        if (visited.has(ck) || radar[cr][cc] !== "hit") continue;
        visited.add(ck);
        cluster.push([cr, cc]);
        for (const [dr, dc] of DIRS4) {
          const nr = cr+dr, nc = cc+dc;
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE) q.push([nr, nc]);
        }
      }
      if (cluster.length) clusters.push(cluster);
    }
  }
  return clusters;
}

function detectOrientation(cluster: [number, number][]): "h" | "v" | "unknown" {
  if (cluster.length < 2) return "unknown";
  if (new Set(cluster.map(([r]) => r)).size === 1) return "h";
  if (new Set(cluster.map(([, c]) => c)).size === 1) return "v";
  return "unknown";
}

function inBounds(r: number, c: number): boolean {
  return r >= 0 && r < SIZE && c >= 0 && c < SIZE;
}

function chooseBest(
  candidates: [number, number][],
  score: number[][],
  rng: RNG,
): [number, number] {
  let best = -Infinity;
  let bestCells: [number, number][] = [];
  for (const [r, c] of candidates) {
    const s = score[r][c];
    if (s > best) { best = s; bestCells = [[r, c]]; }
    else if (s === best) bestCells.push([r, c]);
  }
  return pickRandom(bestCells, rng);
}

// ─────────────────────────────────────────────────────────────────────────────
// EV score builder
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute the EV score grid for every empty cell.
 *
 * Returns a SIZE×SIZE matrix where each entry is:
 *   wHit*P(hit) + wKill*P(kill) + wIG*IG + wCC*cluster_consistency
 *
 * Cells that are not "empty" on the radar get score = -Infinity.
 */
function buildEVScores(
  advisor: AdvisorState,
  prob: number[][],
  params: { wHit: number; wKill: number; wIG: number; wCC: number },
): number[][] {
  const { wHit, wKill, wIG, wCC } = params;

  // Initialise all scores to 0
  const score: number[][] = Array.from({ length: SIZE }, () => Array(SIZE).fill(0));
  const pKill:  number[][] = Array.from({ length: SIZE }, () => Array(SIZE).fill(0));
  const cc:     number[][] = Array.from({ length: SIZE }, () => Array(SIZE).fill(0));

  // ── P(kill) in HUNT mode ────────────────────────────────────────────────
  // Weighted average ship size still remaining: smaller ships → higher P(kill)/hit
  const remaining = advisor.remainingShips;
  const totalWeight = remaining.reduce((a, s) => a + s, 0);
  const meanShipSize = remaining.length > 0 ? totalWeight / remaining.length : 3;

  // ── TARGET MODE — build P(kill) and cluster_consistency ─────────────────
  if (advisor.hits.length > 0) {
    const clusters = getHitClusters(advisor.radar);

    for (const cluster of clusters) {
      const k = cluster.length;
      const orient = detectOrientation(cluster);

      // Minimum remaining ship size that can contain this cluster
      const validSizes = remaining.filter(s => s >= k);
      if (validSizes.length === 0) continue; // orphaned cluster (shouldn't happen)
      const sMin = Math.min(...validSizes);

      // Shots still needed to complete the smallest ship covering this cluster
      // (from one end of the axis)
      const shotsNeeded = sMin - k;

      // Axis directions
      const axisDirs: [number, number][] =
        orient === "h" ? [[0,-1],[0,1]]
        : orient === "v" ? [[-1,0],[1,0]]
        : DIRS4;
      const crossDirs: [number, number][] =
        orient === "h" ? [[-1,0],[1,0]]
        : orient === "v" ? [[0,-1],[0,1]]
        : [];

      const seenAxis  = new Set<string>();
      const seenCross = new Set<string>();

      for (const [hr, hc] of cluster) {
        for (const [dr, dc] of axisDirs) {
          const nr = hr+dr, nc = hc+dc;
          const k2 = keyOf(nr, nc);
          if (!inBounds(nr, nc) || advisor.radar[nr][nc] !== "empty" || seenAxis.has(k2)) continue;
          seenAxis.add(k2);

          // P(kill): if only 1 more shot needed, full probability; else decays
          const pkContrib = shotsNeeded <= 1 ? prob[nr][nc] : prob[nr][nc] / shotsNeeded;
          pKill[nr][nc] = Math.max(pKill[nr][nc], pkContrib);
          cc[nr][nc] = Math.max(cc[nr][nc], 1.0); // strong axis bonus
        }
        for (const [dr, dc] of crossDirs) {
          const nr = hr+dr, nc = hc+dc;
          const k2 = keyOf(nr, nc);
          if (!inBounds(nr, nc) || advisor.radar[nr][nc] !== "empty" || seenCross.has(k2)) continue;
          seenCross.add(k2);
          // Cross-axis: much lower P(kill), moderate consistency bonus
          pKill[nr][nc] = Math.max(pKill[nr][nc], prob[nr][nc] * 0.15);
          cc[nr][nc] = Math.max(cc[nr][nc], 0.2);
        }
      }
    }
  }

  // ── Assemble final scores ────────────────────────────────────────────────
  const useCheckerboard = remaining.length > 0 && Math.min(...remaining) > 1;

  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if (advisor.radar[r][c] !== "empty") {
        score[r][c] = -Infinity;
        continue;
      }

      // Parity filter in hunt mode (skip if checkerboard applies and cell is off-parity)
      if (advisor.hits.length === 0 && useCheckerboard && (r + c) % 2 !== 0) {
        score[r][c] = -Infinity;
        continue;
      }

      const p = prob[r][c];

      // P(kill) — either from target-mode cluster analysis or hunt-mode approximation
      const pkill = advisor.hits.length > 0
        ? pKill[r][c]
        : p / meanShipSize; // hunt mode: smaller remaining ships → higher P(kill)

      // Information gain: 2p(1−p) — maximised at p=0.5
      // Captures the expected diagnostic value of the shot on BOTH hit and miss outcomes
      const ig = 2 * p * (1 - p);

      score[r][c] = wHit * p + wKill * pkill + wIG * ig + wCC * cc[r][c];
    }
  }

  return score;
}

// ─────────────────────────────────────────────────────────────────────────────
// Model export
// ─────────────────────────────────────────────────────────────────────────────

export const model_expectedValue: BattleshipModel = {
  name: "expectedValue",

  params: {
    wHit:           1.0,
    wKill:          2.0,
    wInfoGain:      1.5,
    wConsistency:   1.0,
    placementTrials: 350,
  },

  getNextMove(advisor: AdvisorState, rng: RNG): Move {
    const prob = computeProbabilityMap(advisor);

    const evScore = buildEVScores(advisor, prob, {
      wHit:  1.0,
      wKill: 2.0,
      wIG:   1.5,
      wCC:   1.0,
    });

    // Collect all finite-score cells
    const candidates: [number, number][] = [];
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (evScore[r][c] > -Infinity) candidates.push([r, c]);
      }
    }

    if (candidates.length === 0) {
      // Safety fallback: shoot any empty cell (should never happen in practice)
      for (let r = 0; r < SIZE; r++)
        for (let c = 0; c < SIZE; c++)
          if (advisor.radar[r][c] === "empty") return [r, c];
      return [0, 0];
    }

    return chooseBest(candidates, evScore, rng);
  },

  placeFleet(rng: RNG): FleetPlacement {
    return placeFleetSafe(rng, 350);
  },
};
