/**
 * model_finisher — Aggressive cluster-finishing model.
 *
 * Shooting: In hunt mode, uses probability + checkerboard parity.
 *           In target mode, strongly prioritises FINISHING the detected cluster.
 *           Strategy:
 *             1. Detect the dominant hit orientation (horizontal / vertical / unknown).
 *             2. Lock onto that axis and extend in both directions.
 *             3. Only if no extension is possible, fall back to cross-axis probing.
 *             4. Finally fall back to probability hunting.
 *
 * The "finisher" bias means it almost always sinks a ship before moving on,
 * reducing wasted shots from double-dipping into unrelated clusters.
 *
 * Placement: random.
 */

import { SIZE, type AdvisorState, computeProbabilityMap } from "@/lib/gameLogic";
import { pickRandom, type RNG } from "../randomSeed";
import { placeFleetRandom } from "../gameEngine";
import { type BattleshipModel, type Move, type FleetPlacement } from "../modelTypes";

function keyOf(r: number, c: number) { return `${r},${c}`; }

function getHitClusters(radar: AdvisorState["radar"]): [number, number][][] {
  const visited = new Set<string>();
  const clusters: [number, number][][] = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const k = keyOf(r, c);
      if (radar[r][c] !== "hit" || visited.has(k)) continue;
      const cluster: [number, number][] = [];
      const q: [number, number][] = [[r, c]];
      while (q.length) {
        const [cr, cc] = q.shift()!;
        const ck = keyOf(cr, cc);
        if (visited.has(ck) || radar[cr][cc] !== "hit") continue;
        visited.add(ck);
        cluster.push([cr, cc]);
        for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
          const nr = cr+dr, nc = cc+dc;
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE) q.push([nr, nc]);
        }
      }
      if (cluster.length) clusters.push(cluster);
    }
  }
  return clusters;
}

function detectOrientation(cluster: [number, number][]): "h" | "v" | "unknown" {
  if (cluster.length < 2) return "unknown";
  const rows = cluster.map(([r]) => r);
  const cols = cluster.map(([, c]) => c);
  if (new Set(rows).size === 1) return "h";
  if (new Set(cols).size === 1) return "v";
  return "unknown";
}

function chooseBest(
  candidates: [number, number][],
  score: number[][],
  rng: RNG,
): [number, number] | null {
  if (!candidates.length) return null;
  let best = -Infinity;
  let bestCells: [number, number][] = [];
  for (const [r, c] of candidates) {
    const s = score[r][c];
    if (s > best) { best = s; bestCells = [[r, c]]; }
    else if (s === best) bestCells.push([r, c]);
  }
  return pickRandom(bestCells, rng);
}

function finishCluster(
  cluster: [number, number][],
  radar: AdvisorState["radar"],
  score: number[][],
  rng: RNG,
): Move | null {
  const orient = detectOrientation(cluster);
  const seen = new Set<string>();
  const axisExtensions: [number, number][] = [];
  const crossExtensions: [number, number][] = [];

  for (const [hr, hc] of cluster) {
    const dirs: [number, number][] = orient === "h"
      ? [[0, -1], [0, 1]]
      : orient === "v"
        ? [[-1, 0], [1, 0]]
        : [[-1, 0], [1, 0], [0, -1], [0, 1]];

    const crossDirs: [number, number][] = orient === "h"
      ? [[-1, 0], [1, 0]]
      : orient === "v"
        ? [[0, -1], [0, 1]]
        : [];

    for (const [dr, dc] of dirs) {
      const nr = hr + dr, nc = hc + dc;
      const k = keyOf(nr, nc);
      if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE
        && radar[nr][nc] === "empty" && !seen.has(k)) {
        seen.add(k);
        axisExtensions.push([nr, nc]);
      }
    }

    for (const [dr, dc] of crossDirs) {
      const nr = hr + dr, nc = hc + dc;
      const k = keyOf(nr, nc);
      if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE
        && radar[nr][nc] === "empty" && !seen.has(k)) {
        seen.add(k);
        crossExtensions.push([nr, nc]);
      }
    }
  }

  if (axisExtensions.length) return chooseBest(axisExtensions, score, rng);
  if (crossExtensions.length) return chooseBest(crossExtensions, score, rng);
  return null;
}

export const model_finisher: BattleshipModel = {
  name: "finisher",
  params: { parityFilter: 1, finishBias: 2.0 },

  getNextMove(advisor: AdvisorState, rng: RNG): Move {
    const score = computeProbabilityMap(advisor);

    if (advisor.hits.length > 0) {
      const clusters = getHitClusters(advisor.radar);

      // Pick the largest cluster to finish first
      const sorted = [...clusters].sort((a, b) => b.length - a.length);

      for (const cluster of sorted) {
        const move = finishCluster(cluster, advisor.radar, score, rng);
        if (move) return move;
      }
    }

    // Hunt mode with parity
    const smallest = advisor.remainingShips.length > 0 ? Math.min(...advisor.remainingShips) : 1;
    const useCheckerboard = smallest > 1;
    const parity: [number, number][] = [];
    const all: [number, number][] = [];
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (advisor.radar[r][c] !== "empty") continue;
        all.push([r, c]);
        if (!useCheckerboard || (r + c) % 2 === 0) parity.push([r, c]);
      }
    }
    return chooseBest(parity.length ? parity : all, score, rng) ?? [0, 0];
  },

  placeFleet(rng: RNG): FleetPlacement {
    return placeFleetRandom(rng);
  },
};
