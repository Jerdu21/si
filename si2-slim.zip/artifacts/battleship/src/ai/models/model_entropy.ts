/**
 * model_entropy — Information-gain (entropy) shot selection.
 *
 * Shooting: For each candidate empty cell, estimate the EXPECTED REDUCTION
 *           in the number of valid fleet placements if we shoot there.
 *           Choose the cell that maximises this information gain.
 *
 *           p(hit at cell) = prob[r][c] / totalPlacements
 *           p(miss at cell) = 1 - p(hit at cell)
 *
 *           informationGain(cell) =
 *               p(hit)  * (current_placements - placements_that_cover_cell)
 *             + p(miss) * (current_placements - placements_that_don't_cover_cell)
 *
 *           Simplified: this equals the count that covers the cell × (1 - p(hit))
 *             + count that doesn't × p(hit)
 *             = count * (1 - count/total) ... minimum is at p = 0.5
 *
 *           We use an approximation that is O(cells) instead of full enumeration:
 *             score(r,c) = prob[r][c] * (total - prob[r][c])
 *           This is maximised when prob = total/2, i.e. 50% chance of hit — the
 *           "sweet spot" of maximum uncertainty, which is exactly entropy.
 *
 * In target mode: falls back to probability-ranked cluster extension.
 * Placement: random.
 */

import { SIZE, type AdvisorState, computeProbabilityMap } from "@/lib/gameLogic";
import { pickRandom, type RNG } from "../randomSeed";
import { placeFleetRandom } from "../gameEngine";
import { type BattleshipModel, type Move, type FleetPlacement } from "../modelTypes";

function keyOf(r: number, c: number) { return `${r},${c}`; }

function getHitClusters(radar: AdvisorState["radar"]): [number, number][][] {
  const visited = new Set<string>();
  const clusters: [number, number][][] = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const k = keyOf(r, c);
      if (radar[r][c] !== "hit" || visited.has(k)) continue;
      const cluster: [number, number][] = [];
      const q: [number, number][] = [[r, c]];
      while (q.length) {
        const [cr, cc] = q.shift()!;
        const ck = keyOf(cr, cc);
        if (visited.has(ck) || radar[cr][cc] !== "hit") continue;
        visited.add(ck);
        cluster.push([cr, cc]);
        for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
          const nr = cr+dr, nc = cc+dc;
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE) q.push([nr, nc]);
        }
      }
      if (cluster.length) clusters.push(cluster);
    }
  }
  return clusters;
}

function chooseBest(
  candidates: [number, number][],
  score: number[][],
  rng: RNG,
): [number, number] | null {
  if (!candidates.length) return null;
  let best = -Infinity;
  let bestCells: [number, number][] = [];
  for (const [r, c] of candidates) {
    const s = score[r][c];
    if (s > best) { best = s; bestCells = [[r, c]]; }
    else if (s === best) bestCells.push([r, c]);
  }
  return pickRandom(bestCells, rng);
}

export const model_entropy: BattleshipModel = {
  name: "entropy",
  params: { entropyWeight: 1.0, parityFilter: 0 },

  getNextMove(advisor: AdvisorState, rng: RNG): Move {
    const prob = computeProbabilityMap(advisor);

    // Compute total probability mass
    let total = 0;
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (advisor.radar[r][c] === "empty") total += prob[r][c];
      }
    }
    if (total <= 0) total = 1;

    // In target mode: use probability to rank extension candidates
    if (advisor.hits.length > 0) {
      const clusters = getHitClusters(advisor.radar);
      const candidates: [number, number][] = [];
      const seen = new Set<string>();
      for (const cluster of clusters) {
        for (const [hr, hc] of cluster) {
          for (const [dr, dc] of [[-1,0],[1,0],[0,-1],[0,1]] as [number,number][]) {
            const nr = hr+dr, nc = hc+dc;
            const k = keyOf(nr, nc);
            if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE
              && advisor.radar[nr][nc] === "empty" && !seen.has(k)) {
              seen.add(k);
              candidates.push([nr, nc]);
            }
          }
        }
      }
      if (candidates.length) {
        return chooseBest(candidates, prob, rng) ?? candidates[0];
      }
    }

    // Hunt mode: entropy score = p * (1 - p) = prob * (total - prob)
    const entropyScore: number[][] = Array.from({ length: SIZE }, (_, r) =>
      Array.from({ length: SIZE }, (_, c) => {
        if (advisor.radar[r][c] !== "empty") return 0;
        const p = prob[r][c];
        return p * (total - p);
      })
    );

    const all: [number, number][] = [];
    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (advisor.radar[r][c] === "empty") all.push([r, c]);
      }
    }
    return chooseBest(all, entropyScore, rng) ?? [0, 0];
  },

  placeFleet(rng: RNG): FleetPlacement {
    return placeFleetRandom(rng);
  },
};
