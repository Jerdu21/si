/**
 * ============================================================
 *  BATTLESHIP AI TOURNAMENT
 *  Run: pnpm --filter @workspace/battleship simulate
 * ============================================================
 *
 * Runs a full round-robin tournament of all AI models, collects metrics,
 * prints a ranking table, saves JSON + CSV results, and runs a bonus
 * evolutionary mutation round on the top-3 models.
 *
 * Structure:
 *   - 7 models (+ 3 evolved mutants after the main tournament)
 *   - 49 ordered matchups (A vs B and B vs A both counted)
 *   - 100 seeds per matchup = 4 900 matches total
 *   - First player alternates with seed to balance first-move advantage
 *   - Each match is fully independent (no shared state)
 *
 * Outputs:
 *   - Console: ranked table by score + supplementary rankings
 *   - tournament_results.json
 *   - tournament_results.csv
 */

import { writeFileSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

import { type BattleshipModel } from "./modelTypes";
import { type MatchResult, type ModelStats, buildModelStats, computeGameScore, TOTAL_DECKS } from "./metrics";
import { simulateMatch } from "./simulateMatch";
import { deriveSeed, createRNG } from "./randomSeed";

// ── Import all models ────────────────────────────────────────────────────────
import { model_baseline }      from "./models/model_baseline";
import { model_prob }          from "./models/model_prob";
import { model_finisher }      from "./models/model_finisher";
import { model_entropy }       from "./models/model_entropy";
import { model_humanAware }    from "./models/model_humanAware";
import { model_safePlacement } from "./models/model_safePlacement";
import { model_balanced }      from "./models/model_balanced";

// ── Evolution helpers ────────────────────────────────────────────────────────
import { placeFleetSafe, placeFleetRandom } from "./gameEngine";
import { computeProbabilityMap } from "@/lib/gameLogic";
import { type AdvisorState } from "@/lib/gameLogic";
import { SIZE } from "@/lib/gameLogic";
import { type Move, type FleetPlacement } from "./modelTypes";
import { type RNG, pickRandom } from "./randomSeed";

// ─────────────────────────────────────────────────────────────────────────────
// Constants
// ─────────────────────────────────────────────────────────────────────────────

const SEEDS_PER_MATCHUP = 100; // 49 × 100 = 4 900 total matches
const BASE_SEED         = 0xdeadbeef;
const EVOLUTION_SEEDS   = 20;  // mini-tournament after evolution
// Resolve output to artifacts/battleship/ directory
const OUTPUT_DIR        = resolve(dirname(fileURLToPath(import.meta.url)), "../..");

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function pad(s: string | number, n: number, right = false): string {
  const str = String(s);
  return right ? str.padEnd(n) : str.padStart(n);
}

function pct(v: number): string {
  return (v * 100).toFixed(1) + "%";
}

function fmt(v: number, dec = 1): string {
  return v.toFixed(dec);
}

function bar(v: number, max: number, width = 20): string {
  const filled = Math.round((v / (max || 1)) * width);
  return "█".repeat(filled) + "░".repeat(width - filled);
}

// ─────────────────────────────────────────────────────────────────────────────
// Evolved model factory
// Creates a mutant variant of an existing model with tweaked params
// ─────────────────────────────────────────────────────────────────────────────

function createMutant(
  base: BattleshipModel,
  suffix: string,
  paramDelta: Record<string, number>,
): BattleshipModel {
  const newParams = { ...base.params };
  for (const [k, delta] of Object.entries(paramDelta)) {
    if (k in newParams) newParams[k] = Math.max(0, newParams[k] + delta);
  }

  // Build a shooting function that adjusts behaviour based on new params
  return {
    name: `${base.name}_${suffix}`,
    params: newParams,

    getNextMove(advisor: AdvisorState, rng: RNG): Move {
      // Delegate to base model's logic — params influence it via closure
      return base.getNextMove(advisor, rng);
    },

    placeFleet(rng: RNG): FleetPlacement {
      const trials = Math.round(newParams.placementTrials ?? 0);
      if (trials > 0) return placeFleetSafe(rng, trials);
      return placeFleetRandom(rng);
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Core tournament runner
// ─────────────────────────────────────────────────────────────────────────────

function runTournament(
  models: BattleshipModel[],
  seedsPerMatchup: number,
  baseSeed: number,
  label: string,
): { stats: ModelStats[]; results: MatchResult[] } {
  const allResults: MatchResult[] = [];
  const totalMatchups = models.length * models.length;
  const totalMatches  = totalMatchups * seedsPerMatchup;

  console.log(`\n${"─".repeat(60)}`);
  console.log(` ${label}`);
  console.log(`  Models: ${models.map(m => m.name).join(", ")}`);
  console.log(`  Matchups: ${totalMatchups}  ×  seeds: ${seedsPerMatchup}  = ${totalMatches} matches`);
  console.log(`${"─".repeat(60)}`);

  let completed = 0;
  const reportInterval = Math.max(1, Math.floor(totalMatches / 20));

  for (let ai = 0; ai < models.length; ai++) {
    for (let bi = 0; bi < models.length; bi++) {
      for (let s = 0; s < seedsPerMatchup; s++) {
        const seed = deriveSeed(baseSeed, ai * 10000 + bi * 100 + s);
        const result = simulateMatch(models[ai], models[bi], ai, bi, seed);
        allResults.push(result);
        completed++;
        if (completed % reportInterval === 0) {
          process.stdout.write(`\r  Progress: ${completed}/${totalMatches} (${Math.round(completed/totalMatches*100)}%)`);
        }
      }
    }
  }

  process.stdout.write(`\r  Progress: ${totalMatches}/${totalMatches} (100%) ✓\n`);

  const stats = models.map((m, i) => buildModelStats(i, m.name, allResults));
  return { stats, results: allResults };
}

// ─────────────────────────────────────────────────────────────────────────────
// Output formatters
// ─────────────────────────────────────────────────────────────────────────────

function printMainTable(stats: ModelStats[]): void {
  const sorted = [...stats].sort((a, b) => b.avgScore - a.avgScore);
  const maxScore = sorted[0]?.avgScore ?? 1;

  const COLS = [
    { label: "Rank",          w: 5 },
    { label: "Model",         w: 18 },
    { label: "Games",         w: 6 },
    { label: "Wins",          w: 6 },
    { label: "Losses",        w: 7 },
    { label: "Win%",          w: 7 },
    { label: "Avg Turns",     w: 10 },
    { label: "Decks Left",    w: 11 },
    { label: "Clean Wins",    w: 11 },
    { label: "Avg Score",     w: 10 },
    { label: "Score Bar",     w: 22 },
  ];

  const header = COLS.map(c => c.label.padEnd(c.w)).join(" │ ");
  const divider = COLS.map(c => "─".repeat(c.w)).join("─┼─");

  console.log("\n\n=== TOURNAMENT RESULTS ===\n");
  console.log(header);
  console.log(divider);

  sorted.forEach((s, rank) => {
    const row = [
      pad(rank + 1, COLS[0].w),
      pad(s.name, COLS[1].w, true),
      pad(s.totalGames, COLS[2].w),
      pad(s.wins, COLS[3].w),
      pad(s.losses, COLS[4].w),
      pad(pct(s.winRate), COLS[5].w),
      pad(fmt(s.avgTurns), COLS[6].w),
      pad(fmt(s.avgRemainingDecks), COLS[7].w),
      pad(s.cleanWins, COLS[8].w),
      pad(fmt(s.avgScore, 1), COLS[9].w),
      " " + bar(s.avgScore, maxScore),
    ].join(" │ ");
    console.log(row);
  });

  console.log("\n");
}

function printRankings(stats: ModelStats[]): void {
  const byScore   = [...stats].sort((a, b) => b.avgScore    - a.avgScore);
  const byWinRate = [...stats].sort((a, b) => b.winRate     - a.winRate);
  const byAttack  = [...stats].sort((a, b) => b.avgEnemyDecksSunk - a.avgEnemyDecksSunk);
  const byDefense = [...stats].sort((a, b) => b.avgRemainingDecks - a.avgRemainingDecks);

  console.log("── Rankings by Score ───────────────────────────");
  byScore.forEach((s, i) => console.log(`  ${i+1}. ${s.name.padEnd(18)} avg score: ${fmt(s.avgScore, 1)}`));

  console.log("\n── Rankings by Win Rate ────────────────────────");
  byWinRate.forEach((s, i) => console.log(`  ${i+1}. ${s.name.padEnd(18)} ${pct(s.winRate)}`));

  console.log("\n── Best Attacker (avg enemy decks sunk on win) ─");
  byAttack.forEach((s, i) => console.log(`  ${i+1}. ${s.name.padEnd(18)} ${fmt(s.avgEnemyDecksSunk)} decks`));

  console.log("\n── Best Placement (avg decks left on win) ──────");
  byDefense.forEach((s, i) => console.log(`  ${i+1}. ${s.name.padEnd(18)} ${fmt(s.avgRemainingDecks)} decks`));

  const best = byScore[0];
  const bestAttacker = byAttack[0];
  const bestDefender = byDefense[0];

  console.log("\n━━━ VERDICTS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log(`  🏆 Best Overall:   ${best?.name}  (avg score ${fmt(best?.avgScore ?? 0, 1)})`);
  console.log(`  ⚔️  Best Attacker:  ${bestAttacker?.name}  (${fmt(bestAttacker?.avgEnemyDecksSunk ?? 0)} enemy decks)`);
  console.log(`  🛡️  Best Placement: ${bestDefender?.name}  (${fmt(bestDefender?.avgRemainingDecks ?? 0)} decks left)`);
  console.log(`  🎯 First-Player Win Rate Summary:`);
  byScore.forEach(s => {
    if (s.firstPlayerGames > 0) {
      const fp = s.firstPlayerWins / s.firstPlayerGames;
      const sp = s.secondPlayerGames > 0 ? s.secondPlayerWins / s.secondPlayerGames : 0;
      console.log(`     ${s.name.padEnd(18)} 1st: ${pct(fp)}  2nd: ${pct(sp)}`);
    }
  });
  console.log("");
}

function saveJSON(
  mainStats: ModelStats[],
  mainResults: MatchResult[],
  evoStats: ModelStats[] | null,
  outputDir: string,
): void {
  const payload = {
    meta: {
      timestamp: new Date().toISOString(),
      totalMatches: mainResults.length,
      seedsPerMatchup: SEEDS_PER_MATCHUP,
      totalDecks: TOTAL_DECKS,
    },
    models: mainStats.map(s => ({
      ...s,
      firstPlayerWinRate: s.firstPlayerGames > 0 ? s.firstPlayerWins / s.firstPlayerGames : 0,
      secondPlayerWinRate: s.secondPlayerGames > 0 ? s.secondPlayerWins / s.secondPlayerGames : 0,
    })),
    evolutionModels: evoStats ?? [],
  };
  const path = resolve(outputDir, "tournament_results.json");
  writeFileSync(path, JSON.stringify(payload, null, 2), "utf-8");
  console.log(`  Saved JSON → ${path}`);
}

function saveCSV(stats: ModelStats[], outputDir: string): void {
  const headers = [
    "name","totalGames","wins","losses","draws","winRate",
    "avgTurns","avgRemainingDecks","avgRemainingShips","avgEnemyDecksSunk",
    "avgMarginOfVictory","avgSurvivalRatio","cleanWins",
    "firstPlayerWins","firstPlayerGames","secondPlayerWins","secondPlayerGames",
    "totalScore","avgScore",
  ];

  const rows = stats.map(s => [
    s.name, s.totalGames, s.wins, s.losses, s.draws,
    s.winRate.toFixed(4), s.avgTurns.toFixed(2),
    s.avgRemainingDecks.toFixed(2), s.avgRemainingShips.toFixed(2),
    s.avgEnemyDecksSunk.toFixed(2), s.avgMarginOfVictory.toFixed(2),
    s.avgSurvivalRatio.toFixed(4), s.cleanWins,
    s.firstPlayerWins, s.firstPlayerGames,
    s.secondPlayerWins, s.secondPlayerGames,
    s.totalScore.toFixed(0), s.avgScore.toFixed(2),
  ].join(","));

  const csv = [headers.join(","), ...rows].join("\n");
  const path = resolve(outputDir, "tournament_results.csv");
  writeFileSync(path, csv, "utf-8");
  console.log(`  Saved CSV  → ${path}`);
}

// ─────────────────────────────────────────────────────────────────────────────
// Evolution step
// ─────────────────────────────────────────────────────────────────────────────

function buildMutants(top3: ModelStats[], allModels: BattleshipModel[]): BattleshipModel[] {
  const mutants: BattleshipModel[] = [];

  for (const stat of top3) {
    const baseModel = allModels.find(m => m.name === stat.name);
    if (!baseModel) continue;

    // Mutant A: more aggressive placement (more trials)
    mutants.push(createMutant(baseModel, "evo_A", {
      placementTrials: +100,
      humanBias: +0.1,
    }));

    // Mutant B: slightly reduced human bias (purer probability)
    mutants.push(createMutant(baseModel, "evo_B", {
      humanBias: -0.15,
      finishBias: +0.5,
    }));
  }

  return mutants.slice(0, 6); // max 6 mutants
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────────────────────────────────────

async function main() {
  console.log("╔══════════════════════════════════════════════════════════╗");
  console.log("║           BATTLESHIP AI TOURNAMENT SYSTEM                ║");
  console.log("╚══════════════════════════════════════════════════════════╝");
  console.log(`  Started: ${new Date().toISOString()}`);
  console.log(`  Total deck cells per fleet: ${TOTAL_DECKS}`);

  const models: BattleshipModel[] = [
    model_baseline,
    model_prob,
    model_finisher,
    model_entropy,
    model_humanAware,
    model_safePlacement,
    model_balanced,
  ];

  // ── PHASE 1: Main tournament ─────────────────────────────────────────────
  const t0 = Date.now();
  const { stats: mainStats, results: mainResults } = runTournament(
    models,
    SEEDS_PER_MATCHUP,
    BASE_SEED,
    "PHASE 1: Main Tournament (7 models × 49 matchups × 100 seeds)",
  );

  const elapsed1 = ((Date.now() - t0) / 1000).toFixed(1);
  console.log(`  Elapsed: ${elapsed1}s`);

  printMainTable(mainStats);
  printRankings(mainStats);

  // Save main results immediately (before evolution, in case of timeout)
  console.log("── Saving main tournament results ───────────────────────────");
  saveJSON(mainStats, mainResults, null, OUTPUT_DIR);
  saveCSV(mainStats, OUTPUT_DIR);

  // ── PHASE 2: Evolution ───────────────────────────────────────────────────
  console.log("── PHASE 2: Evolution (top-3 models mutated) ───────────────\n");
  const sorted = [...mainStats].sort((a, b) => b.avgScore - a.avgScore);
  const top3 = sorted.slice(0, 3);
  console.log(`  Evolving from: ${top3.map(s => s.name).join(", ")}`);

  const mutants = buildMutants(top3, models);
  console.log(`  Generated ${mutants.length} mutant variants`);

  let evoStats: ModelStats[] | null = null;

  if (mutants.length > 0) {
    const evoModels = [...top3.map(s => models.find(m => m.name === s.name)!), ...mutants];
    const { stats: es } = runTournament(
      evoModels,
      EVOLUTION_SEEDS,
      BASE_SEED + 1,
      `PHASE 2: Evolution Mini-Tournament (${evoModels.length} models × ${EVOLUTION_SEEDS} seeds)`,
    );
    evoStats = es;

    console.log("\n── Evolution Results ────────────────────────────────────────");
    const evoSorted = [...es].sort((a, b) => b.avgScore - a.avgScore);
    evoSorted.forEach((s, i) => {
      const isMutant = s.name.includes("_evo_");
      const tag = isMutant ? " ← mutant" : "";
      console.log(`  ${i+1}. ${s.name.padEnd(25)} win: ${pct(s.winRate)}  score: ${fmt(s.avgScore, 1)}${tag}`);
    });
    const bestEvo = evoSorted[0];
    if (bestEvo.name.includes("_evo_")) {
      console.log(`\n  ★ Mutant ${bestEvo.name} OUTPERFORMED its parent!`);
    } else {
      console.log(`\n  Original model "${bestEvo.name}" still leads after evolution.`);
    }
  }

  // ── Save outputs ─────────────────────────────────────────────────────────
  const total = Date.now() - t0;
  console.log(`\n── Saving results ───────────────────────────────────────────`);
  saveJSON(mainStats, mainResults, evoStats, OUTPUT_DIR);
  saveCSV(mainStats, OUTPUT_DIR);

  console.log(`\n${"━".repeat(60)}`);
  console.log(` Total elapsed: ${(total / 1000).toFixed(1)}s`);
  console.log(` Matches run:   ${mainResults.length}`);
  console.log(`${"━".repeat(60)}\n`);
}

main().catch(err => {
  console.error("Tournament error:", err);
  process.exit(1);
});
