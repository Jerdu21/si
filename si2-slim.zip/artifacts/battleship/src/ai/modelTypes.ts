/**
 * Shared types and interfaces for the AI tournament system.
 * These are extension types — the original gameLogic.ts is never modified.
 */

import { type AdvisorState, type Board, type PlacedShip } from "@/lib/gameLogic";
import { type RNG } from "./randomSeed";

export type { Board, PlacedShip, AdvisorState };

/** A shot coordinate [row, col] (0-indexed). */
export type Move = [number, number];

/** The result of a fleet placement. */
export interface FleetPlacement {
  board: Board;
  ships: PlacedShip[];
}

/**
 * The unified model interface every AI must implement.
 *
 * @param name      - Human-readable model name (used in output tables).
 * @param params    - Configurable weights / strategy knobs for the model.
 * @param getNextMove - Given the model's current advisor state and an RNG,
 *                      return the next [row, col] to shoot at.
 * @param placeFleet  - Place the full fleet using the provided RNG and return
 *                      the resulting board + ship list.
 */
export interface BattleshipModel {
  name: string;
  params: Record<string, number>;
  getNextMove(advisor: AdvisorState, rng: RNG): Move;
  placeFleet(rng: RNG): FleetPlacement;
}

/** Placement strategy variants that models can share. */
export type PlacementStrategy = "random" | "safe";

/** Shooting strategy label (for ranking analysis). */
export type ShootingStrategy =
  | "baseline"
  | "probability"
  | "finisher"
  | "entropy"
  | "human_aware"
  | "balanced";
