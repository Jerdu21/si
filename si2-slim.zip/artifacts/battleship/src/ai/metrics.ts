/**
 * Metric types and composite score formula for the tournament.
 *
 * Composite score per game (for the winner):
 *
 *   score = 1000 * win
 *         + 20  * remainingDecks          (cells in surviving ships)
 *         + 8   * remainingShips          (count of surviving ships)
 *         + 3   * enemyDecksSunk          (total cells destroyed on enemy)
 *         - 0.15 * turns                  (fewer turns = better)
 *
 * A loss contributes 0 to the score.
 */

// ─────────────────────────────────────────────────────────────────────────────
// Per-game result
// ─────────────────────────────────────────────────────────────────────────────

export interface MatchResult {
  /** Index into the models array of the winner (or -1 for draw). */
  winnerId: number;
  /** Index of the loser (or -1 for draw). */
  loserId: number;
  /** Total half-turns (each player's shot = 1 turn). */
  turns: number;
  /** Remaining decks of the WINNER after the game. */
  winnerRemainingDecks: number;
  /** Remaining ships of the WINNER after the game. */
  winnerRemainingShips: number;
  /** Total deck cells the WINNER sank. */
  winnerEnemyDecksSunk: number;
  /** Whether the first player (index 0 of the pair) won. */
  firstPlayerWon: boolean;
  /** Seed used. */
  seed: number;
  /** Model A name (first to move). */
  modelAName: string;
  /** Model B name. */
  modelBName: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Per-model aggregate stats
// ─────────────────────────────────────────────────────────────────────────────

export interface ModelStats {
  name: string;

  totalGames: number;
  wins: number;
  losses: number;
  draws: number;

  winRate: number;           // wins / totalGames
  avgTurns: number;          // average turns per game (all games)
  avgRemainingDecks: number; // average winner's remaining decks (wins only)
  avgRemainingShips: number; // average winner's remaining ships (wins only)
  avgEnemyDecksSunk: number; // average enemy decks sunk (wins only)
  avgMarginOfVictory: number;// avgRemainingDecks + avgRemainingShips (wins only)
  avgSurvivalRatio: number;  // remainingDecks / totalOwnDecks (wins only)

  cleanWins: number;         // wins where remaining decks >= 50% of own fleet
  firstPlayerWins: number;   // wins as first player
  firstPlayerGames: number;  // games played as first player
  secondPlayerWins: number;  // wins as second player
  secondPlayerGames: number; // games played as second player

  totalScore: number;        // sum of per-game composite scores
  avgScore: number;          // totalScore / totalGames
}

// ─────────────────────────────────────────────────────────────────────────────
// Score formula
// ─────────────────────────────────────────────────────────────────────────────

export const TOTAL_DECKS = 4 + 3 + 3 + 2 + 2 + 2 + 1 + 1 + 1 + 1; // = 20

/**
 * Compute the composite score for a single game for the winner.
 * Losers get 0.
 */
export function computeGameScore(params: {
  win: boolean;
  remainingDecks: number;
  remainingShips: number;
  enemyDecksSunk: number;
  turns: number;
}): number {
  if (!params.win) return 0;
  return (
    1000 +
    20  * params.remainingDecks +
    8   * params.remainingShips +
    3   * params.enemyDecksSunk -
    0.15 * params.turns
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Aggregation
// ─────────────────────────────────────────────────────────────────────────────

export function buildModelStats(
  modelIndex: number,
  modelName: string,
  results: MatchResult[],
): ModelStats {
  // Self-play games (winnerId === loserId) are tracked separately as draws
  const myGames = results.filter(
    r => r.winnerId === modelIndex || r.loserId === modelIndex,
  );

  // A self-play game has winnerId === loserId — exclude from wins/losses
  const selfPlay = myGames.filter(r => r.winnerId === r.loserId);
  const contested = myGames.filter(r => r.winnerId !== r.loserId);

  const wins   = contested.filter(r => r.winnerId === modelIndex);
  const losses = contested.filter(r => r.loserId  === modelIndex);

  const totalGames = myGames.length;
  const winCount   = wins.length;
  const lossCount  = losses.length;
  const drawCount  = selfPlay.length; // self-play counted as draws

  const avg = (arr: number[]) =>
    arr.length === 0 ? 0 : arr.reduce((a, b) => a + b, 0) / arr.length;

  // Turn count: all games (turns is for the whole game, regardless of winner)
  const allTurns = myGames.map(r => r.turns);

  // Win-only metrics
  const winDecks  = wins.map(r => r.winnerRemainingDecks);
  const winShips  = wins.map(r => r.winnerRemainingShips);
  const winSunk   = wins.map(r => r.winnerEnemyDecksSunk);

  // Clean wins: remaining decks >= 50% of total fleet
  const cleanWins = wins.filter(
    r => r.winnerRemainingDecks >= Math.ceil(TOTAL_DECKS * 0.5),
  ).length;

  // First / second player breakdowns
  const firstGames = myGames.filter(r => r.modelAName === modelName);
  const secondGames = myGames.filter(r => r.modelBName === modelName);
  const firstWins  = firstGames.filter(r => r.winnerId === modelIndex).length;
  const secondWins = secondGames.filter(r => r.winnerId === modelIndex).length;

  // Scores
  const scores = myGames.map(r => {
    const isWinner = r.winnerId === modelIndex;
    if (!isWinner) return 0;
    return computeGameScore({
      win: true,
      remainingDecks: r.winnerRemainingDecks,
      remainingShips: r.winnerRemainingShips,
      enemyDecksSunk: r.winnerEnemyDecksSunk,
      turns: r.turns,
    });
  });

  const totalScore = scores.reduce((a, b) => a + b, 0);
  const avgRemainingDecks = avg(winDecks);
  const avgRemainingShips = avg(winShips);

  const contestedGames = winCount + lossCount;

  return {
    name: modelName,
    totalGames,
    wins: winCount,
    losses: lossCount,
    draws: drawCount,
    winRate: contestedGames > 0 ? winCount / contestedGames : 0,
    avgTurns: avg(allTurns),
    avgRemainingDecks,
    avgRemainingShips,
    avgEnemyDecksSunk: avg(winSunk),
    avgMarginOfVictory: avgRemainingDecks + avgRemainingShips,
    avgSurvivalRatio: winCount > 0 ? avgRemainingDecks / TOTAL_DECKS : 0,
    cleanWins,
    firstPlayerWins: firstWins,
    firstPlayerGames: firstGames.length,
    secondPlayerWins: secondWins,
    secondPlayerGames: secondGames.length,
    totalScore,
    avgScore: totalGames > 0 ? totalScore / totalGames : 0,
  };
}
