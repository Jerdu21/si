/**
 * simulateMatch — Runs a single complete Battleship game between two models.
 *
 * Rules enforced:
 *  - No cheating: each model only receives its own AdvisorState (what it has shot).
 *  - Both models place their fleets independently before any shots are fired.
 *  - Turns alternate: modelA shoots first (unless swapped by the caller).
 *  - A model wins when all cells of the opponent's fleet are sunk.
 *  - Maximum turns guard: 10 × 10 × 2 = 200 shots (never reached in practice).
 *
 * The function is pure (no side effects, no I/O) and fully deterministic when
 * given the same seed.
 */

import { createAdvisor } from "@/lib/gameLogic";
import { type BattleshipModel } from "./modelTypes";
import { type MatchResult } from "./metrics";
import { TOTAL_DECKS } from "./metrics";
import {
  createLiveFleet,
  resolveShot,
  getSunkCluster,
  isFleetSunk,
  countRemainingShips,
  countRemainingDecks,
  applyOutcomeToAdvisor,
} from "./gameEngine";
import { createRNG, deriveSeed } from "./randomSeed";

const MAX_TURNS = 200;

/**
 * Simulate a single match.
 *
 * @param modelA      First model (shoots first by default).
 * @param modelB      Second model.
 * @param modelAIdx   Index of modelA in the global models array (for MatchResult).
 * @param modelBIdx   Index of modelB in the global models array.
 * @param seed        Numeric seed for reproducibility.
 * @returns MatchResult with full stats.
 */
export function simulateMatch(
  modelA: BattleshipModel,
  modelB: BattleshipModel,
  modelAIdx: number,
  modelBIdx: number,
  seed: number,
): MatchResult {
  // Create separate RNGs for placement and shooting to prevent cross-contamination
  const rngA_place = createRNG(deriveSeed(seed, 1));
  const rngB_place = createRNG(deriveSeed(seed, 2));
  const rngA_shoot = createRNG(deriveSeed(seed, 3));
  const rngB_shoot = createRNG(deriveSeed(seed, 4));

  // Place fleets
  const placementA = modelA.placeFleet(rngA_place);
  const placementB = modelB.placeFleet(rngB_place);

  // Live tracking of each fleet (actual ship positions + damage)
  const fleetB = createLiveFleet(placementB); // modelA shoots at this
  const fleetA = createLiveFleet(placementA); // modelB shoots at this

  // Each model's knowledge of the opponent (radar view only)
  let advisorA = createAdvisor(); // modelA's view of B
  let advisorB = createAdvisor(); // modelB's view of A

  let turns = 0;
  let winner: "A" | "B" | "draw" = "draw";

  while (turns < MAX_TURNS) {
    // ── Model A's turn ─────────────────────────────────────────────────────
    {
      const [row, col] = modelA.getNextMove(advisorA, rngA_shoot);

      // Safety: clamp to valid range and skip already-shot cells
      const r = Math.max(0, Math.min(9, row));
      const c = Math.max(0, Math.min(9, col));

      const outcome = resolveShot(fleetB, r, c);

      // Get sunk cluster for advisor (needed for surrounding-miss marking)
      if (outcome.result === "sunk" && outcome.sunkShipIndex !== undefined) {
        const cluster = getSunkCluster(fleetB, outcome.sunkShipIndex);
        // We pass the full sunk-cluster info via the outcome object
        advisorA = applyOutcomeToAdvisor(advisorA, r, c, outcome, fleetB);
        // Mark sunk cells on advisor so cluster becomes "sunk" state
        for (const [cr, cc] of cluster) {
          if (advisorA.radar[cr][cc] !== "sunk") {
            advisorA.radar[cr][cc] = "sunk";
          }
        }
      } else {
        advisorA = applyOutcomeToAdvisor(advisorA, r, c, outcome, fleetB);
      }

      turns++;

      if (isFleetSunk(fleetB)) {
        winner = "A";
        break;
      }
    }

    // ── Model B's turn ─────────────────────────────────────────────────────
    {
      const [row, col] = modelB.getNextMove(advisorB, rngB_shoot);

      const r = Math.max(0, Math.min(9, row));
      const c = Math.max(0, Math.min(9, col));

      const outcome = resolveShot(fleetA, r, c);

      if (outcome.result === "sunk" && outcome.sunkShipIndex !== undefined) {
        const cluster = getSunkCluster(fleetA, outcome.sunkShipIndex);
        advisorB = applyOutcomeToAdvisor(advisorB, r, c, outcome, fleetA);
        for (const [cr, cc] of cluster) {
          if (advisorB.radar[cr][cc] !== "sunk") {
            advisorB.radar[cr][cc] = "sunk";
          }
        }
      } else {
        advisorB = applyOutcomeToAdvisor(advisorB, r, c, outcome, fleetA);
      }

      turns++;

      if (isFleetSunk(fleetA)) {
        winner = "B";
        break;
      }
    }
  }

  // Compute result stats
  const aIsWinner = winner === "A";
  const bIsWinner = winner === "B";

  const winnerRemainingDecks = aIsWinner
    ? countRemainingDecks(fleetA)
    : bIsWinner
      ? countRemainingDecks(fleetB)
      : 0;

  const winnerRemainingShips = aIsWinner
    ? countRemainingShips(fleetA)
    : bIsWinner
      ? countRemainingShips(fleetB)
      : 0;

  const winnerEnemyDecksSunk = aIsWinner
    ? TOTAL_DECKS - countRemainingDecks(fleetB)
    : bIsWinner
      ? TOTAL_DECKS - countRemainingDecks(fleetA)
      : 0;

  return {
    winnerId: aIsWinner ? modelAIdx : bIsWinner ? modelBIdx : -1,
    loserId:  aIsWinner ? modelBIdx : bIsWinner ? modelAIdx : -1,
    turns,
    winnerRemainingDecks,
    winnerRemainingShips,
    winnerEnemyDecksSunk,
    firstPlayerWon: aIsWinner,
    seed,
    modelAName: modelA.name,
    modelBName: modelB.name,
  };
}
