/**
 * Pure simulation engine for Battleship.
 * Does NOT use Math.random() — all randomness flows through the seeded RNG.
 * Does NOT import any UI or React code.
 *
 * Wraps the existing gameLogic.ts functions to drive a complete simulated game.
 */

import {
  SIZE,
  SHIPS,
  createBoard,
  canPlace,
  placeShipOnBoard,
  advisorRecordShot,
  createAdvisor,
  type Board,
  type PlacedShip,
  type AdvisorState,
} from "@/lib/gameLogic";

import { type RNG, randInt } from "./randomSeed";
import { type FleetPlacement, type Move } from "./modelTypes";

// ─────────────────────────────────────────────────────────────────────────────
// Fleet placement helpers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Place all SHIPS randomly using the provided RNG.
 * Falls back to a simple sequential scan if random placement fails too many times.
 */
export function placeFleetRandom(rng: RNG): FleetPlacement {
  for (let attempt = 0; attempt < 100; attempt++) {
    const board = createBoard();
    const ships: PlacedShip[] = [];
    let success = true;

    for (const size of SHIPS) {
      let placed = false;
      for (let tries = 0; tries < 200; tries++) {
        const x = randInt(rng, SIZE);
        const y = randInt(rng, SIZE);
        const horiz = rng() < 0.5;
        if (canPlace(board, x, y, size, horiz)) {
          ships.push(placeShipOnBoard(board, x, y, size, horiz));
          placed = true;
          break;
        }
      }
      if (!placed) { success = false; break; }
    }

    if (success) return { board, ships };
  }

  // Deterministic fallback: scan top-left to bottom-right
  return placeFleetSequential();
}

/**
 * Defensive placement: run `trials` random placements and keep the one with
 * the highest scorePlacement() value.  Uses the existing scoring heuristic
 * from gameLogic (re-implemented here to avoid breaking the original).
 */
export function placeFleetSafe(rng: RNG, trials = 500): FleetPlacement {
  let bestFleet: FleetPlacement | null = null;
  let bestScore = -Infinity;

  for (let t = 0; t < trials; t++) {
    const candidate = placeFleetRandom(rng);
    const s = scoreDefensivePlacement(candidate.board, candidate.ships);
    if (s > bestScore) {
      bestScore = s;
      bestFleet = candidate;
    }
  }

  return bestFleet ?? placeFleetRandom(rng);
}

/** Sequential (deterministic) fallback placement — no RNG used. */
function placeFleetSequential(): FleetPlacement {
  const board = createBoard();
  const ships: PlacedShip[] = [];
  for (const size of SHIPS) {
    outer:
    for (let x = 0; x < SIZE; x++) {
      for (let y = 0; y < SIZE; y++) {
        if (canPlace(board, x, y, size, true)) {
          ships.push(placeShipOnBoard(board, x, y, size, true));
          break outer;
        }
      }
    }
  }
  return { board, ships };
}

/**
 * Defensive placement score — mirrors the logic in gameLogic.ts scorePlacement.
 * Kept here so gameEngine is self-contained and gameLogic.ts is never modified.
 */
function scoreDefensivePlacement(board: Board, ships: PlacedShip[]): number {
  let safeParityCount = 0;
  const quadrants = [0, 0, 0, 0];
  const mid = SIZE / 2;
  let edgeBonus = 0;
  let cornerBonus = 0;
  let horizontalCount = 0;
  let verticalCount = 0;

  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if (board[r][c] !== "ship") continue;
      if ((r + c) % 2 === 1) safeParityCount++;
      const q = (r < mid ? 0 : 2) + (c < mid ? 0 : 1);
      quadrants[q]++;
      const onEdge = r === 0 || r === SIZE - 1 || c === 0 || c === SIZE - 1;
      const inCorner = (r === 0 || r === SIZE - 1) && (c === 0 || c === SIZE - 1);
      if (onEdge) edgeBonus += 0.35;
      if (inCorner) cornerBonus += 0.8;
    }
  }

  for (const ship of ships) {
    if (ship.horizontal) horizontalCount++; else verticalCount++;
    if (ship.size <= 2) {
      for (let i = 0; i < ship.size; i++) {
        const r = ship.x + (ship.horizontal ? 0 : i);
        const c = ship.y + (ship.horizontal ? i : 0);
        const onEdge = r === 0 || r === SIZE - 1 || c === 0 || c === SIZE - 1;
        const nearEdge = r <= 1 || r >= SIZE - 2 || c <= 1 || c >= SIZE - 2;
        if (onEdge) edgeBonus += 1.25;
        else if (nearEdge) edgeBonus += 0.45;
      }
    }
  }

  const maxQ = Math.max(...quadrants);
  const spreadBonus = (SIZE * SIZE - maxQ * 4) / SIZE;
  const orientationBalance = Math.min(horizontalCount, verticalCount) * 0.8;
  return safeParityCount * 2 + spreadBonus + edgeBonus + cornerBonus + orientationBalance;
}

// ─────────────────────────────────────────────────────────────────────────────
// Shot-outcome resolution
// ─────────────────────────────────────────────────────────────────────────────

/** Mutable tracking of a fleet during a simulation (ships take damage). */
export interface LiveFleet {
  ships: PlacedShip[];
  /** For each ship, how many cells have been hit so far. */
  hitCounts: number[];
  /** Which board cells have been revealed as ship/hit. */
  actualBoard: Board;
}

export function createLiveFleet(placement: FleetPlacement): LiveFleet {
  return {
    ships: placement.ships.map(s => ({ ...s, sunk: false })),
    hitCounts: placement.ships.map(() => 0),
    actualBoard: placement.board.map(row => [...row]) as Board,
  };
}

/** Outcome of resolving a single shot against a live fleet. */
export interface ShotOutcome {
  result: "hit" | "miss" | "sunk";
  sunkSize?: number;
  sunkShipIndex?: number;
}

/**
 * Resolve a shot at [row, col] against a live fleet.
 * Returns the outcome. Mutates `fleet` (marks hit cells, sinks ships).
 */
export function resolveShot(fleet: LiveFleet, row: number, col: number): ShotOutcome {
  if (fleet.actualBoard[row][col] !== "ship") {
    return { result: "miss" };
  }

  // Find the owning ship
  for (let i = 0; i < fleet.ships.length; i++) {
    const ship = fleet.ships[i];
    if (ship.sunk) continue;

    for (let k = 0; k < ship.size; k++) {
      const sr = ship.x + (ship.horizontal ? 0 : k);
      const sc = ship.y + (ship.horizontal ? k : 0);
      if (sr === row && sc === col) {
        fleet.hitCounts[i]++;
        fleet.actualBoard[row][col] = "hit" as typeof fleet.actualBoard[0][0];

        if (fleet.hitCounts[i] === ship.size) {
          // Sunk
          fleet.ships[i] = { ...ship, sunk: true };
          // Mark all cells as sunk on the actual board
          for (let m = 0; m < ship.size; m++) {
            const mr = ship.x + (ship.horizontal ? 0 : m);
            const mc = ship.y + (ship.horizontal ? m : 0);
            fleet.actualBoard[mr][mc] = "sunk" as typeof fleet.actualBoard[0][0];
          }
          return { result: "sunk", sunkSize: ship.size, sunkShipIndex: i };
        }

        return { result: "hit" };
      }
    }
  }

  // Cell was "ship" but not matched (shouldn't happen)
  return { result: "miss" };
}

/**
 * Get the sunk cluster for a just-sunk ship.
 */
export function getSunkCluster(fleet: LiveFleet, shipIndex: number): [number, number][] {
  const ship = fleet.ships[shipIndex];
  const cluster: [number, number][] = [];
  for (let k = 0; k < ship.size; k++) {
    const r = ship.x + (ship.horizontal ? 0 : k);
    const c = ship.y + (ship.horizontal ? k : 0);
    cluster.push([r, c]);
  }
  return cluster;
}

/**
 * Returns true when all ships in the fleet have been sunk.
 */
export function isFleetSunk(fleet: LiveFleet): boolean {
  return fleet.ships.every(s => s.sunk);
}

/**
 * Count remaining (not-sunk) ships.
 */
export function countRemainingShips(fleet: LiveFleet): number {
  return fleet.ships.filter(s => !s.sunk).length;
}

/**
 * Count remaining (not-sunk) deck cells (total cells in unsunk ships).
 */
export function countRemainingDecks(fleet: LiveFleet): number {
  return fleet.ships.filter(s => !s.sunk).reduce((sum, s) => sum + s.size, 0);
}

// ─────────────────────────────────────────────────────────────────────────────
// Advisor update bridge
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Apply a shot outcome to an advisor state, returning the updated state.
 * Wraps the existing `advisorRecordShot` from gameLogic.ts.
 *
 * When a sunk is reported, we need to pass the sunk cluster so the advisor
 * can mark surrounding cells as miss. The cluster comes from the live fleet.
 */
export function applyOutcomeToAdvisor(
  advisor: AdvisorState,
  row: number,
  col: number,
  outcome: ShotOutcome,
  fleet: LiveFleet,
): AdvisorState {
  let sunkSize: number | undefined;

  if (outcome.result === "sunk" && outcome.sunkShipIndex !== undefined) {
    sunkSize = outcome.sunkSize;

    // For sunk: the advisor needs the result + cluster knowledge.
    // advisorRecordShot handles cluster detection and miss-marking automatically.
    const { advisor: updated } = advisorRecordShot(
      advisor,
      row,
      col,
      "sunk",
      sunkSize,
    );
    return updated;
  }

  const { advisor: updated } = advisorRecordShot(
    advisor,
    row,
    col,
    outcome.result === "hit" ? "hit" : "miss",
  );
  return updated;
}

// Re-export for convenience in models
export { SHIPS, SIZE, createAdvisor };
export type { Move };
