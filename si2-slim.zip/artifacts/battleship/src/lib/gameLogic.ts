// ============================================================
// Battleship AI Advisor — upgraded implementation
// Key improvements over original:
//  1. Monte Carlo simulation (400 valid placements) for probability heatmap
//  2. Analytic probability map combined with MC heatmap (weighted)
//  3. Smarter target mode: orientation locking + backtrack when blocked
//  4. Auto-miss all surrounding cells after any sunk event
//  5. Remaining ship sizes tracked and used in every calculation
// ============================================================

export const SIZE = 10;
export const SHIPS = [4, 3, 3, 2, 2, 2, 1, 1, 1, 1];

export const SHIP_NAMES: Record<number, string> = {
  4: "Battleship",
  3: "Cruiser",
  2: "Destroyer",
  1: "Submarine",
};

export type CellState = "empty" | "ship" | "hit" | "miss" | "sunk";
export type Board = CellState[][];

export interface PlacedShip {
  size: number;
  x: number;
  y: number;
  horizontal: boolean;
  sunk: boolean;
}

export function createBoard(): Board {
  return Array.from({ length: SIZE }, () => Array(SIZE).fill("empty") as CellState[]);
}

// ── Ship placement (setup phase) ─────────────────────────────────────────────

export function canPlace(board: Board, x: number, y: number, size: number, horizontal: boolean): boolean {
  for (let i = 0; i < size; i++) {
    const nx = x + (horizontal ? 0 : i);
    const ny = y + (horizontal ? i : 0);
    if (nx >= SIZE || ny >= SIZE) return false;
    if (board[nx][ny] !== "empty") return false;
    for (let dx = -1; dx <= 1; dx++) {
      for (let dy = -1; dy <= 1; dy++) {
        const tx = nx + dx, ty = ny + dy;
        if (tx >= 0 && tx < SIZE && ty >= 0 && ty < SIZE && board[tx][ty] === "ship") return false;
      }
    }
  }
  return true;
}

export function placeShipOnBoard(board: Board, x: number, y: number, size: number, horizontal: boolean): PlacedShip {
  for (let i = 0; i < size; i++) {
    const nx = x + (horizontal ? 0 : i);
    const ny = y + (horizontal ? i : 0);
    board[nx][ny] = "ship";
  }
  return { size, x, y, horizontal, sunk: false };
}

/**
 * Defensive placement score.
 * We bias towards layouts that are awkward for both human players and common
 * checkerboard/probability bots:
 *  - more ship cells on off-parity squares,
 *  - good spread across quadrants,
 *  - small ships pushed towards edges / corners,
 *  - varied orientations so the fleet is harder to pattern-match.
 */
function scorePlacement(board: Board, ships: PlacedShip[]): number {
  let safeParityCount = 0;
  const quadrants = [0, 0, 0, 0];
  const mid = SIZE / 2;
  let edgeBonus = 0;
  let cornerBonus = 0;
  let horizontalCount = 0;
  let verticalCount = 0;

  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if (board[r][c] !== "ship") continue;
      if ((r + c) % 2 === 1) safeParityCount++;
      const q = (r < mid ? 0 : 2) + (c < mid ? 0 : 1);
      quadrants[q]++;
      const onEdge = r === 0 || r === SIZE - 1 || c === 0 || c === SIZE - 1;
      const inCorner = (r === 0 || r === SIZE - 1) && (c === 0 || c === SIZE - 1);
      if (onEdge) edgeBonus += 0.35;
      if (inCorner) cornerBonus += 0.8;
    }
  }

  for (const ship of ships) {
    if (ship.horizontal) horizontalCount++; else verticalCount++;
    if (ship.size <= 2) {
      for (let i = 0; i < ship.size; i++) {
        const r = ship.x + (ship.horizontal ? 0 : i);
        const c = ship.y + (ship.horizontal ? i : 0);
        const onEdge = r === 0 || r === SIZE - 1 || c === 0 || c === SIZE - 1;
        const nearEdge = r <= 1 || r >= SIZE - 2 || c <= 1 || c >= SIZE - 2;
        if (onEdge) edgeBonus += 1.25;
        else if (nearEdge) edgeBonus += 0.45;
      }
    }
  }

  const maxQ = Math.max(...quadrants);
  const spreadBonus = (SIZE * SIZE - maxQ * 4) / SIZE;
  const orientationBalance = Math.min(horizontalCount, verticalCount) * 0.8;

  return safeParityCount * 2 + spreadBonus + edgeBonus + cornerBonus + orientationBalance;
}

/**
 * Auto-place ships using a best-of-250-trials selection.
 * Each trial is a random valid placement; we keep the one with the
 * highest score (most ship cells on off-parity, most spread).
 * This is the same MC-style optimisation used in the AI advisor.
 */
export function autoPlace(): { board: Board; ships: PlacedShip[] } {
  let bestBoard: Board = createBoard();
  let bestShips: PlacedShip[] = [];
  let bestScore = -Infinity;

  for (let trial = 0; trial < 250; trial++) {
    const board = createBoard();
    const ships: PlacedShip[] = [];
    let success = true;

    for (const size of SHIPS) {
      let placed = false;
      // Up to 200 random attempts per ship per trial
      for (let attempt = 0; attempt < 200; attempt++) {
        const x = Math.floor(Math.random() * SIZE);
        const y = Math.floor(Math.random() * SIZE);
        const horiz = Math.random() < 0.5;
        if (canPlace(board, x, y, size, horiz)) {
          ships.push(placeShipOnBoard(board, x, y, size, horiz));
          placed = true;
          break;
        }
      }
      if (!placed) { success = false; break; }
    }

    if (!success) continue;

    const score = scorePlacement(board, ships);
    if (score > bestScore) {
      bestScore = score;
      bestBoard = board.map(row => [...row]) as Board;
      bestShips = ships;
    }
  }

  // Fallback: if all trials failed (extremely unlikely), use a simple random placement
  if (bestShips.length === 0) {
    const board = createBoard();
    const ships: PlacedShip[] = [];
    for (const size of SHIPS) {
      let placed = false;
      while (!placed) {
        const x = Math.floor(Math.random() * SIZE);
        const y = Math.floor(Math.random() * SIZE);
        const horiz = Math.random() < 0.5;
        if (canPlace(board, x, y, size, horiz)) {
          ships.push(placeShipOnBoard(board, x, y, size, horiz));
          placed = true;
        }
      }
    }
    return { board, ships };
  }

  return { board: bestBoard, ships: bestShips };
}

// ── Coordinate helpers ───────────────────────────────────────────────────────
// Rows = A–J (letters), Columns = 1–10 (numbers)
export function cellLabel(row: number, col: number): string {
  return `${String.fromCharCode(65 + row)}${col + 1}`;
}

// ── Surrounding-cells helper ─────────────────────────────────────────────────

/**
 * After confirming a ship is sunk, mark all cells surrounding the sunk cluster
 * (including diagonals) as miss if they were empty.
 * Returns the list of newly-missed cells.
 */
export function markSurroundingAsMiss(
  radar: Board,
  sunkCluster: [number, number][]
): [number, number][] {
  const newMisses: [number, number][] = [];
  const sunkSet = new Set(sunkCluster.map(([r, c]) => `${r},${c}`));
  for (const [r, c] of sunkCluster) {
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const nr = r + dr, nc = c + dc;
        if (nr < 0 || nr >= SIZE || nc < 0 || nc >= SIZE) continue;
        if (!sunkSet.has(`${nr},${nc}`) && radar[nr][nc] === "empty") {
          radar[nr][nc] = "miss";
          newMisses.push([nr, nc]);
        }
      }
    }
  }
  return newMisses;
}

// ── Cluster helpers ──────────────────────────────────────────────────────────

function getConnectedHits(radar: Board, startX: number, startY: number): [number, number][] {
  const visited = new Set<string>();
  const cluster: [number, number][] = [];
  const queue: [number, number][] = [[startX, startY]];
  while (queue.length > 0) {
    const [x, y] = queue.shift()!;
    const key = `${x},${y}`;
    if (visited.has(key)) continue;
    visited.add(key);
    if (radar[x][y] === "hit") {
      cluster.push([x, y]);
      for (const [dx, dy] of [[-1, 0], [1, 0], [0, -1], [0, 1]] as [number, number][]) {
        const nx = x + dx, ny = y + dy;
        if (nx >= 0 && nx < SIZE && ny >= 0 && ny < SIZE && !visited.has(`${nx},${ny}`)) queue.push([nx, ny]);
      }
    }
  }
  return cluster;
}

function isClusterSurrounded(radar: Board, cluster: [number, number][]): boolean {
  for (const [x, y] of cluster) {
    for (const [dx, dy] of [[-1, 0], [1, 0], [0, -1], [0, 1]] as [number, number][]) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) continue;
      if (radar[nx][ny] === "empty") return false;
    }
  }
  return true;
}

export function detectAutoSunk(radar: Board): [number, number][][] {
  const visited = new Set<string>();
  const sunkClusters: [number, number][][] = [];
  for (let x = 0; x < SIZE; x++) {
    for (let y = 0; y < SIZE; y++) {
      const key = `${x},${y}`;
      if (radar[x][y] === "hit" && !visited.has(key)) {
        const cluster = getConnectedHits(radar, x, y);
        for (const [cx, cy] of cluster) visited.add(`${cx},${cy}`);
        if (isClusterSurrounded(radar, cluster)) sunkClusters.push(cluster);
      }
    }
  }
  return sunkClusters;
}

// ── Advisor state ────────────────────────────────────────────────────────────

export interface AdvisorState {
  radar: Board;
  hits: [number, number][];     // active hit cluster (not yet sunk)
  remainingShips: number[];     // sizes still alive on enemy board
}

export function createAdvisor(): AdvisorState {
  return { radar: createBoard(), hits: [], remainingShips: [...SHIPS] };
}

// ── Exact placement model ───────────────────────────────────────────────────
// We enumerate every legal placement for every remaining ship size while
// respecting misses, sunk ships and unresolved hit-clusters. This gives a much
// cleaner signal than the old “fit anywhere except miss” heuristic because it
// never awards probability to placements that would split a hit cluster across
// multiple ships or place a ship adjacent to already-sunk ships.

interface PlacementCandidate {
  size: number;
  cells: [number, number][];
  cellSet: Set<string>;
  neighbourSet: Set<string>;
}

const PLACEMENTS_BY_SIZE = new Map<number, PlacementCandidate[]>();

function keyOf(r: number, c: number): string {
  return `${r},${c}`;
}

function getPlacementsForSize(size: number): PlacementCandidate[] {
  const cached = PLACEMENTS_BY_SIZE.get(size);
  if (cached) return cached;

  const placements: PlacementCandidate[] = [];
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      for (const horizontal of [true, false]) {
        if ((horizontal && c + size > SIZE) || (!horizontal && r + size > SIZE)) continue;
        const cells: [number, number][] = [];
        const cellSet = new Set<string>();
        const neighbourSet = new Set<string>();

        for (let i = 0; i < size; i++) {
          const nr = r + (horizontal ? 0 : i);
          const nc = c + (horizontal ? i : 0);
          cells.push([nr, nc]);
          cellSet.add(keyOf(nr, nc));
        }

        for (const [nr, nc] of cells) {
          for (let dr = -1; dr <= 1; dr++) {
            for (let dc = -1; dc <= 1; dc++) {
              const ar = nr + dr, ac = nc + dc;
              if (ar < 0 || ar >= SIZE || ac < 0 || ac >= SIZE) continue;
              const k = keyOf(ar, ac);
              if (!cellSet.has(k)) neighbourSet.add(k);
            }
          }
        }

        placements.push({ size, cells, cellSet, neighbourSet });
      }
    }
  }

  PLACEMENTS_BY_SIZE.set(size, placements);
  return placements;
}

function getHitClustersFromRadar(radar: Board): [number, number][][] {
  const visited = new Set<string>();
  const clusters: [number, number][][] = [];

  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if (radar[r][c] !== "hit" || visited.has(keyOf(r, c))) continue;
      const cluster: [number, number][] = [];
      const queue: [number, number][] = [[r, c]];

      while (queue.length > 0) {
        const [cr, cc] = queue.shift()!;
        const k = keyOf(cr, cc);
        if (visited.has(k) || radar[cr][cc] !== "hit") continue;
        visited.add(k);
        cluster.push([cr, cc]);
        for (const [dr, dc] of [[-1, 0], [1, 0], [0, -1], [0, 1]] as [number, number][]) {
          const nr = cr + dr, nc = cc + dc;
          if (nr >= 0 && nr < SIZE && nc >= 0 && nc < SIZE && !visited.has(keyOf(nr, nc))) {
            queue.push([nr, nc]);
          }
        }
      }

      if (cluster.length > 0) clusters.push(cluster);
    }
  }

  return clusters;
}

function getValidPlacements(advisor: AdvisorState, size: number): PlacementCandidate[] {
  const hitClusters = getHitClustersFromRadar(advisor.radar);
  const hitClusterSets = hitClusters.map(cluster => new Set(cluster.map(([r, c]) => keyOf(r, c))));
  const hitSet = new Set<string>(advisor.hits.map(([r, c]) => keyOf(r, c)));
  const sunkSet = new Set<string>();
  const missSet = new Set<string>();

  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const k = keyOf(r, c);
      if (advisor.radar[r][c] === "sunk") sunkSet.add(k);
      if (advisor.radar[r][c] === "miss") missSet.add(k);
    }
  }

  const valid: PlacementCandidate[] = [];

  placementLoop:
  for (const placement of getPlacementsForSize(size)) {
    for (const k of placement.cellSet) {
      if (missSet.has(k) || sunkSet.has(k)) continue placementLoop;
    }
    for (const k of placement.neighbourSet) {
      if (sunkSet.has(k)) continue placementLoop;
    }

    let touchedCluster = -1;
    for (let i = 0; i < hitClusterSets.length; i++) {
      const cluster = hitClusterSets[i];
      let intersects = false;
      for (const k of cluster) {
        if (placement.cellSet.has(k)) {
          intersects = true;
          break;
        }
      }
      if (!intersects) continue;
      if (touchedCluster !== -1) continue placementLoop;
      for (const k of cluster) {
        if (!placement.cellSet.has(k)) continue placementLoop;
      }
      touchedCluster = i;
    }

    for (const k of placement.neighbourSet) {
      if (hitSet.has(k) && !placement.cellSet.has(k)) continue placementLoop;
    }

    valid.push(placement);
  }

  return valid;
}

export function computeProbabilityMap(advisor: AdvisorState): number[][] {
  const prob = Array.from({ length: SIZE }, () => Array(SIZE).fill(0));
  const sizeCounts = new Map<number, number>();
  for (const s of advisor.remainingShips) sizeCounts.set(s, (sizeCounts.get(s) ?? 0) + 1);

  for (const [ship, count] of sizeCounts) {
    const placements = getValidPlacements(advisor, ship);
    for (const placement of placements) {
      for (const [r, c] of placement.cells) {
        if (advisor.radar[r][c] === "empty") prob[r][c] += count;
      }
    }
  }

  return prob;
}

export function computeProbabilityMap_combined(advisor: AdvisorState): number[][] {
  const exact = computeProbabilityMap(advisor);
  let max = 0;
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) max = Math.max(max, exact[r][c]);
  }

  if (max <= 0) return exact;

  return Array.from({ length: SIZE }, (_, r) =>
    Array.from({ length: SIZE }, (_, c) => (advisor.radar[r][c] === "empty" ? exact[r][c] / max : 0))
  );
}

// Keep old name exported for backwards compatibility (used in heatmap display)
export { computeProbabilityMap_combined as computeProbabilityMap_display };

// ── Shot selection ───────────────────────────────────────────────────────────

function getPreferredParityStep(advisor: AdvisorState): number {
  const smallest = advisor.remainingShips.length > 0 ? Math.min(...advisor.remainingShips) : 1;
  return smallest > 1 ? 2 : 1;
}

function chooseBestCell(candidates: [number, number][], score: number[][]): [number, number] | null {
  if (candidates.length === 0) return null;

  let bestScore = -1;
  let bestCells: [number, number][] = [];
  for (const [r, c] of candidates) {
    const s = score[r][c];
    if (s > bestScore) {
      bestScore = s;
      bestCells = [[r, c]];
    } else if (s === bestScore) {
      bestCells.push([r, c]);
    }
  }

  if (bestCells.length === 0) return null;
  return bestCells[Math.floor(Math.random() * bestCells.length)];
}

export function getBestShot(advisor: AdvisorState): [number, number] | null {
  if (advisor.remainingShips.length === 0) return null;

  if (advisor.hits.length > 0) return getTargetShot(advisor);
  return getHuntShot(advisor);
}

function getHuntShot(advisor: AdvisorState): [number, number] | null {
  const score = computeProbabilityMap_combined(advisor);
  const parityStep = getPreferredParityStep(advisor);
  const parityCells: [number, number][] = [];
  const allCells: [number, number][] = [];

  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if (advisor.radar[r][c] !== "empty") continue;
      allCells.push([r, c]);
      if (parityStep === 1 || (r + c) % 2 === 0) parityCells.push([r, c]);
    }
  }

  return chooseBestCell(parityCells.length > 0 ? parityCells : allCells, score);
}

function getTargetShot(advisor: AdvisorState): [number, number] {
  const score = computeProbabilityMap_combined(advisor);
  const clusters = getHitClustersFromRadar(advisor.radar);

  let chosenCluster: [number, number][] = advisor.hits;
  let chosenPlacements: PlacementCandidate[] = [];

  for (const cluster of clusters) {
    const placements: PlacementCandidate[] = [];
    const clusterKeys = new Set(cluster.map(([r, c]) => keyOf(r, c)));
    const seenSizes = new Set<number>();

    for (const size of advisor.remainingShips) {
      if (seenSizes.has(size)) continue;
      seenSizes.add(size);
      for (const placement of getValidPlacements(advisor, size)) {
        let coversCluster = true;
        for (const k of clusterKeys) {
          if (!placement.cellSet.has(k)) {
            coversCluster = false;
            break;
          }
        }
        if (coversCluster) placements.push(placement);
      }
    }

    if (placements.length === 0) continue;
    if (placements.length > chosenPlacements.length || chosenPlacements.length === 0) {
      chosenCluster = cluster;
      chosenPlacements = placements;
    }
  }

  const candidateKeys = new Set<string>();
  const candidates: [number, number][] = [];
  for (const placement of chosenPlacements) {
    for (const [r, c] of placement.cells) {
      if (advisor.radar[r][c] !== "empty") continue;
      const k = keyOf(r, c);
      if (!candidateKeys.has(k)) {
        candidateKeys.add(k);
        candidates.push([r, c]);
      }
    }
  }

  if (candidates.length > 0) return chooseBestCell(candidates, score) ?? candidates[0];

  const fallbackCandidates: [number, number][] = [];
  const seen = new Set<string>();
  for (const [hx, hy] of chosenCluster) {
    for (const [dx, dy] of [[-1, 0], [1, 0], [0, -1], [0, 1]] as [number, number][]) {
      const nx = hx + dx, ny = hy + dy;
      if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) continue;
      if (advisor.radar[nx][ny] !== "empty") continue;
      const k = keyOf(nx, ny);
      if (!seen.has(k)) {
        seen.add(k);
        fallbackCandidates.push([nx, ny]);
      }
    }
  }

  return chooseBestCell(fallbackCandidates, score) ?? getHuntShot(advisor) ?? advisor.hits[0];
}

// ── Shot recording ───────────────────────────────────────────────────────────

export interface AdvisorUpdateResult {
  advisor: AdvisorState;
  autoSunkClusters: [number, number][][];
  newMisses: [number, number][];  // cells auto-marked as miss (surrounding sunk ships)
}

export function advisorRecordShot(
  advisor: AdvisorState,
  x: number,
  y: number,
  result: "hit" | "miss" | "sunk",
  sunkSize?: number
): AdvisorUpdateResult {
  const newRadar = advisor.radar.map(row => [...row]) as Board;
  let newHits = [...advisor.hits] as [number, number][];
  let newRemaining = [...advisor.remainingShips];
  const autoSunkClusters: [number, number][][] = [];
  const newMisses: [number, number][] = [];

  function sinkCluster(cluster: [number, number][], size: number) {
    for (const [cx, cy] of cluster) newRadar[cx][cy] = "sunk";
    // Remove matching ship size from remaining
    const idx = newRemaining.indexOf(size);
    if (idx !== -1) newRemaining.splice(idx, 1);
    else {
      // Closest size fallback
      if (newRemaining.length > 0) {
        const closest = newRemaining.reduce((p, c) => Math.abs(c - size) < Math.abs(p - size) ? c : p);
        const fi = newRemaining.indexOf(closest);
        if (fi !== -1) newRemaining.splice(fi, 1);
      }
    }
    // Remove sunk cells from active hits
    const clusterSet = new Set(cluster.map(([cx, cy]) => `${cx},${cy}`));
    newHits = newHits.filter(([hx, hy]) => !clusterSet.has(`${hx},${hy}`));
    // AUTO-MISS surrounding cells (ships can't be adjacent)
    const surrounding = markSurroundingAsMiss(newRadar, cluster);
    newMisses.push(...surrounding);
  }

  /**
   * Run detectAutoSunk in a loop: sinking a cluster adds surrounding misses,
   * which may surround another cluster → keep going until nothing new found.
   */
  function flushAutoSunk() {
    let found = true;
    while (found) {
      found = false;
      const surrounded = detectAutoSunk(newRadar);
      if (surrounded.length > 0) {
        found = true;
        for (const cluster of surrounded) {
          sinkCluster(cluster, cluster.length);
          autoSunkClusters.push(cluster);
        }
      }
    }
  }

  if (result === "miss") {
    newRadar[x][y] = "miss";
    flushAutoSunk();

  } else if (result === "hit") {
    newRadar[x][y] = "hit";
    newHits.push([x, y]);
    flushAutoSunk();

  } else if (result === "sunk") {
    // Manual sunk: mark this cell + connected hits as sunk
    newRadar[x][y] = "hit"; // temporarily so getConnectedHits finds it
    const cluster = getConnectedHits(newRadar, x, y);
    const fullCluster = cluster.some(([cx, cy]) => cx === x && cy === y)
      ? cluster
      : [...cluster, [x, y] as [number, number]];
    sinkCluster(fullCluster, sunkSize ?? fullCluster.length);
    // Surrounding misses from this sunk may trigger further auto-sunk
    flushAutoSunk();
  }

  return {
    advisor: { radar: newRadar, hits: newHits, remainingShips: newRemaining },
    autoSunkClusters,
    newMisses,
  };
}
