# Workspace

## Overview

Battleship game with a multi-model AI tournament system. pnpm workspace monorepo using TypeScript.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: React 19 + Vite + Tailwind CSS v4 + Shadcn UI
- **State management**: TanStack Query
- **Routing**: Wouter
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod, drizzle-zod
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (backend), Vite (frontend)

## Project Structure

```
artifacts/
  api-server/     # Express backend
  battleship/     # React frontend game app (port 5000 in dev)
    src/ai/       # Tournament system (all new, no existing files modified)
      modelTypes.ts       – shared interfaces
      randomSeed.ts       – Mulberry32 seedable RNG
      gameEngine.ts       – pure simulation engine
      metrics.ts          – metric types + composite score
      simulateMatch.ts    – single match simulation
      tournament.ts       – CLI tournament runner
      models/
        model_baseline.ts
        model_prob.ts
        model_finisher.ts
        model_entropy.ts
        model_humanAware.ts
        model_safePlacement.ts
        model_balanced.ts
  mockup-sandbox/ # Component sandbox/preview
lib/
  api-client-react/  # Generated React Query hooks
  api-spec/          # OpenAPI specification + Orval config
  api-zod/           # Zod schemas generated from API spec
  db/                # Database schema and Drizzle client
scripts/
```

## Environment Variables

- `PORT=5000` - Frontend dev port
- `BASE_PATH=/` - Vite base path
- `DATABASE_URL` - PostgreSQL connection string (auto-provisioned)

## Key Commands

- `pnpm --filter @workspace/battleship run dev` — run frontend (port 5000)
- `pnpm --filter @workspace/battleship simulate` — run AI tournament (4900 matches)
- `pnpm --filter @workspace/api-server run dev` — run backend
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)

## Tournament Output

After running `pnpm --filter @workspace/battleship simulate`:
- `artifacts/battleship/tournament_results.json` — full results with metadata
- `artifacts/battleship/tournament_results.csv` — spreadsheet-ready rankings

## Tournament Results (last run)

| Rank | Model          | Win%  | Avg Score |
|------|----------------|-------|-----------|
| 1    | balanced       | 62.1% | 694.9     |
| 2    | safePlacement  | 62.2% | 691.7     |
| 3    | entropy        | 52.1% | 577.5     |
| 4    | finisher       | 51.5% | 572.5     |
| 5    | baseline       | 51.1% | 566.5     |
| 6    | prob           | 50.1% | 555.4     |
| 7    | humanAware     | 48.0% | 533.4     |

Evolution winner: `balanced_evo_A` (more placement trials + human-bias boost)

## Workflows

- **Start application**: Runs the battleship frontend on port 5000
